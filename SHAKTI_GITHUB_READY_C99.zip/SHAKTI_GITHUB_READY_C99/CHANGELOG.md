# Runnable MVP changelog

## 2026-07-23

- Limited the active curriculum manifest to Foundation, Counting, Alphabet, Colors, and Shapes.
- Deferred Math until the first five levels prove the nine-stage loop and three-stage memory model.
- Defined `<text>` as the source value from the curriculum list.
- Standardized artifact directories to `written_text`, `sound_art`, and `visual_art`.
- Made the runtime reject legacy `name`, `glyph`, and `visual_text` XML channels.
- Added `tools/migrate_curriculum.py` for dry-run, deduplicated, conflict-safe bulk imports.
- Added migration tests, including exact preservation of the Foundation space stone.
- Added GitHub Actions coverage for GCC, Clang, AddressSanitizer, and UndefinedBehaviorSanitizer.
- Fixed file-close paths that could skip `fclose()` after a read error.
- Regenerated the manifest ledger and startup validation for 7 staged and 7 planned tablets.
- Kept Eden status OPEN.

## Earlier runnable work

- Connected the startup self-report to the executable startup path.
- Added `--check` for exact loader and ledger verification.
- Added `--demo` for a Pass 1 observation run.
- Kept deferred Foundation punctuation audio optional.
- Added a full ten-correct-streak School integration test.
- Verified the nine-stage loop, heartbeat, reflection deferrals, interrupt, and resume.
- Preserved every School trial in readable logs.
