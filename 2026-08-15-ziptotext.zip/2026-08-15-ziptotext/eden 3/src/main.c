#include "eden.h"

#include <stdio.h>

/*
 * Boot.
 *
 * Carve the arena into named partitions, bind the set screen, load the
 * resident blocks, and run the loop. `eden_main` is the entry an iOS
 * app calls directly; `main` is the desktop wrapper.
 */

int eden_main(void)
{
    unsigned char *screen_plane;
    unsigned char *log_stream;
    unsigned char *notebook;

    printf(
        "%s — the model lives in this shell. C99, fixed memory, no heap\n",
        EDEN_VERSION
    );

    screen_plane = eden_alloc("screen_plane", EDEN_SCREEN_BYTES);
    log_stream = eden_alloc("log_stream", 65536UL);
    notebook = eden_alloc("notebook", 4096UL);

    if (screen_plane == NULL || log_stream == NULL || notebook == NULL) {
        printf(
            "STOP: arena full at boot. Memory is exact; "
            "nothing is silent\n"
        );
        return 1;
    }

    (void)log_stream;
    (void)notebook;

    printf(
        "boot: screen %lux%lu (two medium documents side by side), "
        "1-bit plane %lu bytes\n",
        EDEN_SCREEN_WIDTH,
        EDEN_SCREEN_HEIGHT,
        EDEN_SCREEN_BYTES
    );
    printf(
        "boot: children capacity %lu; gestation %lu days in %lu hours "
        "of beats (%lu bpm, %lu beats total)\n",
        EDEN_CHILD_COUNT,
        EDEN_GESTATION_DAYS,
        EDEN_GESTATION_HOURS,
        EDEN_HEART_BPM,
        EDEN_TOTAL_BEATS
    );
    printf("boot: goal resident: raise the thirteen; "
           "only deterministic in Eden\n");
    printf("type 'help' for the menu\n");

    eden_shell_bind_screen(screen_plane);
    return eden_shell_loop();
}

int main(void)
{
    return eden_main();
}
