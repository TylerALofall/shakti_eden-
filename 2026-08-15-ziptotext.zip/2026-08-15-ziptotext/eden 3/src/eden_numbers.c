#include "eden.h"

#include <stdio.h>

/*
 * The book of Numbers, dissected.
 *
 * Frozen census tables from the text itself. Every relation the scroll
 * claims is ASSERTED at runtime: tribe sums equal side sums equal the
 * stated totals; the redemption gap, ransom, and wilderness loss carry
 * their factors mechanically. Any failure is an explicit STOP — no
 * gray area.
 *
 * The camp is then SEEN: twelve tribe blocks around Levi at the center,
 * rendered through the same Bayer eye as the palette pattern (one
 * matrix, one comparison per pixel — a transducer, not a model).
 * Intensity is count: channels = base x count / 74600, floor, Judah
 * full. A disclosed proportion applied by uniform rule — the same
 * law as the gate-8 mushroom attack: exact by fiat, printed aloud.
 *
 * Factor strings below are frozen text; each was verified externally
 * (sympy) and each underlying arithmetic relation is re-asserted here
 * at runtime.
 */

#define CAMP_CANVAS 96UL
#define CAMP_BLOCK 16UL
#define CAMP_RGBA (CAMP_CANVAS * CAMP_CANVAS * 4UL)
#define CAMP_BITS ((CAMP_CANVAS * CAMP_CANVAS + 7UL) / 8UL)
#define JUDAH_FULL 74600UL

/* Census order (Numbers 1): as listed in the text. */
static const char * const TRIBE_NAMES[12] = {
    "Reuben", "Simeon", "Gad", "Judah", "Issachar", "Zebulun",
    "Ephraim", "Manasseh", "Benjamin", "Dan", "Asher", "Naphtali"
};

static const unsigned long CENSUS1[12] = {
    46500UL, 59300UL, 45650UL, 74600UL, 54400UL, 57400UL,
    40500UL, 32200UL, 35400UL, 62700UL, 41500UL, 53400UL
};

static const unsigned long CENSUS2[12] = {
    43730UL, 22200UL, 40500UL, 76500UL, 64300UL, 60500UL,
    52700UL, 32500UL, 45600UL, 64400UL, 53400UL, 45400UL
};

/* Camp sides (Numbers 2) as indexes into the census order. */
static const unsigned long SIDE_EAST[3]  = { 3UL, 4UL, 5UL };  /* Judah Issachar Zebulun */
static const unsigned long SIDE_SOUTH[3] = { 0UL, 1UL, 2UL };  /* Reuben Simeon Gad */
static const unsigned long SIDE_WEST[3]  = { 6UL, 7UL, 8UL };  /* Ephraim Manasseh Benjamin */
static const unsigned long SIDE_NORTH[3] = { 9UL, 10UL, 11UL };/* Dan Asher Naphtali */

static const char * const SIDE_NAMES[4] = { "east", "south", "west", "north" };
static const unsigned long SIDE_TOTALS[4] = {
    186400UL, 151450UL, 108100UL, 157600UL
};

/* March order (Numbers 2:9,16,24,31: first, second, third, last) is
 * east, south, west, north — the palette's spoken order rides the march:
 * RED, GREEN, WHITE, GREEN; the center, Levi, is BLUE. */

static unsigned char g_camp_src[CAMP_RGBA];
static unsigned char g_camp_bits[CAMP_BITS];
static unsigned char g_camp_rebuilt[CAMP_RGBA];
static unsigned char g_camp_again[CAMP_BITS];

static int numbers_assert(int condition, const char *what)
{
    if (!condition) {
        printf("STOP: numbers assertion failed: %s. No gray area\n", what);
        return 0;
    }
    return 1;
}

static unsigned long numbers_sum_side(const unsigned long side[3])
{
    return CENSUS1[side[0]] + CENSUS1[side[1]] + CENSUS1[side[2]];
}

static unsigned long numbers_sum_all(const unsigned long census[12])
{
    unsigned long total;
    unsigned long i;

    total = 0UL;
    for (i = 0UL; i < 12UL; ++i) {
        total += census[i];
    }
    return total;
}

static void numbers_draw_block(
    unsigned long x0,
    unsigned long y0,
    const unsigned char *base_rgb,
    unsigned long count
)
{
    unsigned long x;
    unsigned long y;
    unsigned long k;

    /* Intensity is count, by uniform disclosed rule:
     * channel = base x count / 74600 (floor). Judah burns full. */
    for (y = 0UL; y < CAMP_BLOCK; ++y) {
        for (x = 0UL; x < CAMP_BLOCK; ++x) {
            unsigned char *pixel;

            pixel = g_camp_src + ((y0 + y) * CAMP_CANVAS + (x0 + x)) * 4UL;
            for (k = 0UL; k < 3UL; ++k) {
                pixel[k] = (unsigned char)(
                    ((unsigned long)base_rgb[k] * count) / JUDAH_FULL
                );
            }
            pixel[3] = 255U;
        }
    }
}

int eden_numbers_run(unsigned char *screen_plane)
{
    static const unsigned long * const SIDES[4] = {
        SIDE_EAST, SIDE_SOUTH, SIDE_WEST, SIDE_NORTH
    };
    /* Block origins per side: E column x=76, S row y=76,
     * W column x=4, N row y=4; blocks step 20 from 20. */
    unsigned long i;
    unsigned long s;
    unsigned long drift;
    unsigned long long hash;
    const unsigned char *base;

    if (screen_plane == NULL) {
        printf("STOP: no screen plane bound\n");
        return 0;
    }

    /* ---- the ledger, asserted ---------------------------------------- */
    if (!numbers_assert(numbers_sum_all(CENSUS1) == 603550UL,
                        "census 1 sums to 603550 (Numbers 1:46)")) {
        return 0;
    }
    for (s = 0UL; s < 4UL; ++s) {
        if (!numbers_assert(numbers_sum_side(SIDES[s]) == SIDE_TOTALS[s],
                            "camp side sums (Numbers 2)")) {
            return 0;
        }
    }
    if (!numbers_assert(
            numbers_sum_side(SIDE_EAST) + numbers_sum_side(SIDE_SOUTH) +
            numbers_sum_side(SIDE_WEST) + numbers_sum_side(SIDE_NORTH) ==
            603550UL,
            "the four sides sum to the whole camp")) {
        return 0;
    }
    if (!numbers_assert(numbers_sum_all(CENSUS2) == 601730UL,
                        "census 2 sums to 601730 (Numbers 26:51)")) {
        return 0;
    }
    if (!numbers_assert(22273UL - 22000UL == 273UL &&
                        273UL * 5UL == 1365UL &&
                        1365UL * 20UL == 27300UL,
                        "redemption gap, ransom, gerahs (Numbers 3)")) {
        return 0;
    }
    if (!numbers_assert(603550UL - 601730UL == 1820UL,
                        "wilderness loss between censuses")) {
        return 0;
    }
    if (!numbers_assert(273UL == 3UL * 7UL * 13UL &&
                        1365UL == 3UL * 5UL * 7UL * 13UL &&
                        1820UL == 2UL * 2UL * 5UL * 7UL * 13UL,
                        "the factors of gap, ransom, and loss")) {
        return 0;
    }

    /* ---- the dissection, printed ------------------------------------- */
    printf("numbers: the book dissected — census, camp, redemption\n");
    printf(" census 1 (Numbers 1): twelve counts sum 603550 = 1:46 exact\n");
    printf("  ");
    for (i = 0UL; i < 12UL; ++i) {
        printf("%s %lu%s", TRIBE_NAMES[i], CENSUS1[i],
               i == 11UL ? "\n" : (i % 3UL == 2UL ? " | " : ", "));
    }
    for (s = 0UL; s < 4UL; ++s) {
        printf(" camp %s: %s %lu (%lu), %s %lu (%lu), %s %lu (%lu) = %lu\n",
               SIDE_NAMES[s],
               TRIBE_NAMES[SIDES[s][0]], CENSUS1[SIDES[s][0]],
               CENSUS1[SIDES[s][0]] * 255UL / JUDAH_FULL,
               TRIBE_NAMES[SIDES[s][1]], CENSUS1[SIDES[s][1]],
               CENSUS1[SIDES[s][1]] * 255UL / JUDAH_FULL,
               TRIBE_NAMES[SIDES[s][2]], CENSUS1[SIDES[s][2]],
               CENSUS1[SIDES[s][2]] * 255UL / JUDAH_FULL,
               SIDE_TOTALS[s]);
    }
    printf(" march order = palette order: east RED, south GREEN, west WHITE,"
           " north GREEN; Levi at center BLUE\n");
    printf(" census 2 (Numbers 26): sum 601730 = 26:51 exact\n");
    printf(" wilderness loss: 1820 = 2^2 x 5 x 7 x 13\n");
    printf(" redemption (Numbers 3): levites 22000, firstborn 22273 (prime),"
           " gap 273 = 3 x 7 x 13\n");
    printf(" ransom: 273 x 5 = 1365 shekels = 3 x 5 x 7 x 13;"
           " x20 gerahs = 27300 = 273 x 100\n");
    printf(" note: the camp's thirteen is twelve around Levi at center"
           " (Joseph split to Ephraim+Manasseh); eden's thirteen are the"
           " literal children, Dinah included. Declared, not equated.\n");

    /* ---- the camp, seen ---------------------------------------------- */
    for (i = 0UL; i < CAMP_RGBA; ++i) {
        g_camp_src[i] = 0U;
    }
    for (i = 0UL; i < CAMP_CANVAS * CAMP_CANVAS; ++i) {
        g_camp_src[i * 4UL + 3UL] = 255U;
    }

    for (s = 0UL; s < 4UL; ++s) {
        base = eden_sight_palette_entry(s);
        for (i = 0UL; i < 3UL; ++i) {
            unsigned long bx;
            unsigned long by;

            if (s == 0UL) {       /* east: right column */
                bx = 76UL;
                by = 20UL + i * 20UL;
            } else if (s == 1UL) {/* south: bottom row */
                bx = 20UL + i * 20UL;
                by = 76UL;
            } else if (s == 2UL) {/* west: left column */
                bx = 4UL;
                by = 20UL + i * 20UL;
            } else {              /* north: top row */
                bx = 20UL + i * 20UL;
                by = 4UL;
            }

            numbers_draw_block(bx, by, base, CENSUS1[SIDES[s][i]]);
        }
    }

    /* Levi at the center, BLUE, full — the priesthood is not weighed. */
    base = eden_sight_palette_entry(4UL);
    numbers_draw_block(40UL, 40UL, base, JUDAH_FULL);

    eden_sight_pull(g_camp_src, CAMP_CANVAS, CAMP_CANVAS, g_camp_bits);
    eden_sight_rebuild(g_camp_bits, CAMP_CANVAS, CAMP_CANVAS, g_camp_rebuilt);
    eden_sight_pull(g_camp_rebuilt, CAMP_CANVAS, CAMP_CANVAS, g_camp_again);
    drift = eden_sight_drift(g_camp_bits, g_camp_again, CAMP_BITS);
    hash = eden_fnv1a64(EDEN_FNV_INIT, g_camp_bits, CAMP_BITS);

    eden_sight_blit(
        screen_plane, EDEN_ANCHOR_CAMP_X, EDEN_ANCHOR_CAMP_Y,
        CAMP_CANVAS, CAMP_CANVAS, g_camp_bits
    );

    printf(" camp render: %lux%lu rgba, channels = base x count / %lu floor"
           " (Judah full) — disclosed proportion, uniform rule\n",
           CAMP_CANVAS, CAMP_CANVAS, JUDAH_FULL);
    printf(" camp: bayer pull -> rebuild -> re-pull drift=%lu\n", drift);
    printf(" camp: hash=fnv1a64:%016llX\n", hash);
    printf(" camp: moved onto set screen, right page at (1176,480)\n");

    if (drift != 0UL) {
        printf("FAIL: camp rebuild drifted\n");
        return 0;
    }

    printf("numbers: PASS exact dissection, exact camp\n");
    return 1;
}
