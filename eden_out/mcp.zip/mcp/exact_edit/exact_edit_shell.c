/* exact_edit_shell.c — the argument line, and nothing else.
   The internal shell behind /shakti_run/ calls exact_edit_run directly. This
   entry exists so the same function can be driven from a terminal. The run
   stays in this process. */

#include "exact_edit.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void usage(FILE *out)
{
    fprintf(out,
"exact_edit — change one line you can quote exactly\n"
"\n"
"  exact_edit <file> add     \"new line\" | \"line you know\" [before|after] [#n|#all]\n"
"  exact_edit <file> remove  \"line\"     | \"line\"                          [#n|#all]\n"
"  exact_edit <file> replace \"old line\" | \"new line\"                      [#n|#all]\n"
"\n"
"  [--out <dir>]    the temp dir every copy goes to. Default temp\n"
"  [--log <path>]   the working record. Default shakti_edit.log\n"
"  [--caller <who>] who asked. Default shell\n"
"\n"
"  Column one and column two are separated by a literal | argument.\n"
"  A line matches when its bytes match, trailing whitespace excluded.\n"
"  Capitalization and the spaces inside a line are part of the line.\n"
"  add puts your line after the anchor unless you say before.\n"
"  The changed copy lands in the temp dir. The file you named stays\n"
"  where it is and as it is.\n"
"  Exit 0 changed, 1 stopped, 2 nothing changed.\n");
}

int main(int argc, char **argv)
{
    shakti_tick_clock_t clock_state;
    ee_request_t request;
    const char *columns[2];
    int column_count = 0;
    int saw_bar = 0;
    int i;

    memset(&request, 0, sizeof request);
    request.selector = EE_SEL_NONE;
    request.side = EE_SIDE_AFTER;
    request.log_path = "shakti_edit.log";
    request.out_dir = "temp";
    request.caller = "shell";
    columns[0] = NULL;
    columns[1] = NULL;

    if (argc < 5) {
        usage(stdout);
        return EE_ERROR;
    }
    request.path = argv[1];

    for (i = 2; i < argc; i++) {
        const char *a = argv[i];
        if (strcmp(a, "--log") == 0 && i + 1 < argc)    { request.log_path = argv[++i]; continue; }
        if (strcmp(a, "--out") == 0 && i + 1 < argc)    { request.out_dir = argv[++i]; continue; }
        if (strcmp(a, "--caller") == 0 && i + 1 < argc) { request.caller = argv[++i]; continue; }
        if (strcmp(a, "add") == 0)     { request.verb = EE_VERB_ADD; continue; }
        if (strcmp(a, "remove") == 0)  { request.verb = EE_VERB_REMOVE; continue; }
        if (strcmp(a, "replace") == 0) { request.verb = EE_VERB_REPLACE; continue; }
        if (strcmp(a, "before") == 0)  { request.side = EE_SIDE_BEFORE; continue; }
        if (strcmp(a, "after") == 0)   { request.side = EE_SIDE_AFTER; continue; }
        if (strcmp(a, "|") == 0)       { saw_bar = 1; continue; }
        if (a[0] == '#') {
            if (strcmp(a, "#all") == 0) {
                request.selector = EE_SEL_ALL;
            } else {
                request.selector = atoi(a + 1);
            }
            continue;
        }
        if (a[0] == '-' && a[1] == '-') {
            fprintf(stdout, "STOP    %s is not one of this tool's arguments.\n", a);
            usage(stdout);
            return EE_ERROR;
        }
        if (column_count < 2) {
            columns[column_count] = a;
            column_count++;
        } else {
            fprintf(stdout, "STOP    there are two columns. A third was given.\n");
            return EE_ERROR;
        }
    }

    if (request.verb == EE_VERB_NONE) {
        fprintf(stdout, "STOP    the verb is add, remove, or replace.\n");
        return EE_ERROR;
    }
    if (column_count != 2 || saw_bar == 0) {
        fprintf(stdout, "STOP    both columns are required, separated by |\n");
        usage(stdout);
        return EE_ERROR;
    }
    request.e1 = columns[0];
    request.e2 = columns[1];

    shakti_tick_clock_init(&clock_state);
    return (int)exact_edit_run(&request, &clock_state, stdout);
}
