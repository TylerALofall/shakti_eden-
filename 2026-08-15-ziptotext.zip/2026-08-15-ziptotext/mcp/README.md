# mcp — the switchboard, the menu, and the first tool

## Every file in this section

| Path | Purpose |
|---|---|
| `README.md` | This file. Names every file in the section. |
| `HANDOFF.md` | The continuity card for the next session. Read it first. |
| `CHANGES.md` | What changed, when, why, and who asked for it. |
| `menu/README.md` | The menu section's own card. |
| `menu/shakti_menu.xml` | The two-tier menu, written to Shakti. |
| `exact_edit/README.md` | The tool section's own card. |
| `exact_edit/exact_edit.h` | Request, verbs, side, selector, capacities, outcome, entry point. |
| `exact_edit/exact_edit.c` | The four passes. |
| `exact_edit/exact_edit_shell.c` | The argument line only. |
| `exact_edit/exact_edit_test.c` | Thirteen cases with the exit each must produce. |
| `exact_edit/Makefile` | Build, check, perimeter, clean. |
| `switchboard/README.md` | The switchboard's own card. |
| `switchboard/shakti_mcp.h` | Session, sender, gate, menu entry, registration, capacities. |
| `switchboard/shakti_mcp.c` | Menu reading, the gate, the registry, dispatch, the record. |
| `switchboard/shakti_mcp_shell.c` | The line in and the answer back. |
| `switchboard/mcp_test.c` | Six cases with the result each must produce. |
| `switchboard/Makefile` | Build, check, perimeter, clean. |
| `v1_switchboard/` | The switchboard as it stood before the sender and the sign in went in. Kept, not maintained. |

## What this is

One way in, one way out. A line arrives at the switchboard, the switchboard checks the menu, checks who is asking and through which door, checks the gate, finds the tool in its own table, and calls it as a C function in the same process. Every one of those steps writes a row, including every refusal.

```
line -> switchboard -> in the menu? -> turned on? -> whose is it? -> gate open?
                            |              |             |              |
                         refused        refused       refused        refused
                            \______________\_____________\______________/
                                              |
                                    said out loud and recorded
                                              |
                                  in the registry? -> the C function
```

## Build

Each section builds on its own. `ROOT` points at the repository root, where `include/` and `src/` live.

```
cd exact_edit && make && make check && make perimeter
cd ../switchboard && make && make check && make perimeter
```

`ROOT = ../..` assumes this `mcp/` directory sits at the repository root. If it lands somewhere else, that one line in each Makefile is what changes.

## Where it sits in the loop

Revision 5 §VI.G. `Ge` is `/menu/`, slot 5. `Gf` is `/shakti_run/`, slot 6. Three of the nine slots are here; the other six are named as missing in `switchboard/README.md` rather than left to be discovered.

## Status

**Written, not compiled, not run.** No compiler has seen any of it. Every `PASS` line comes from `make check` on your machine.
