#include "eden.h"

#include <stdio.h>

/*
 * The tabernacle: the registry of what Shakti inherently knows.
 *
 * Declaration, then table, then tensor. Every item is a frozen
 * constant — inherent knowledge, compiled in, never learned. The
 * matching context is a hard-coded tensor: the 3x3x3 color cube.
 *
 * TWO COLOR LAWS, declared and never conflated:
 *   LIGHT (additive): primaries RED, GREEN, BLUE. Green IS a primary
 *     of light. The spoken palette's green (0,128,0) is a half-strength
 *     shade of it — the saturated-primaries lens does not hold it, and
 *     that is its law, not green's demotion.
 *   PIGMENT (subtractive): primaries RED, YELLOW, BLUE. Yellow is a
 *     primary of pigment; in light, yellow = red + green.
 *
 * THE TENSOR: each channel quantizes to one of three levels {0,128,255}
 * by fixed thresholds (below 64 -> 0, 64..191 -> 128, 192+ -> 255 —
 * powers of two), giving 27 = 3^3 cells. Ten cells are declared colors;
 * seventeen are explicitly NONE. A lookup is exact or it is NONE —
 * no nearest-color guessing, no gray area.
 *
 * ENCODING: hex literals in C source. Hex is binary wearing a name
 * tag: the machine holds pure bits, the repo holds reviewable text,
 * and no .bin file ever rides into Eden (commandment I.1).
 */

typedef struct {
    const char *name;
    unsigned char r;
    unsigned char g;
    unsigned char b;
    const char *klass;
} eden_color_t;

/* The ten declarations, in order of the cube's corners and heart. */
static const eden_color_t COLORS[EDEN_COLOR_DECLARED] = {
    { "BLACK",        0x00U, 0x00U, 0x00U, "DARK" },
    { "RED",          0xFFU, 0x00U, 0x00U, "LIGHT-PRIMARY + PIGMENT-PRIMARY" },
    { "GREEN",        0x00U, 0xFFU, 0x00U, "LIGHT-PRIMARY" },
    { "BLUE",         0x00U, 0x00U, 0xFFU, "LIGHT-PRIMARY + PIGMENT-PRIMARY" },
    { "YELLOW",       0xFFU, 0xFFU, 0x00U, "LIGHT-SECONDARY + PIGMENT-PRIMARY" },
    { "CYAN",         0x00U, 0xFFU, 0xFFU, "LIGHT-SECONDARY" },
    { "MAGENTA",      0xFFU, 0x00U, 0xFFU, "LIGHT-SECONDARY" },
    { "WHITE",        0xFFU, 0xFFU, 0xFFU, "LUMEN" },
    { "GREEN-SPOKEN", 0x00U, 0x80U, 0x00U, "SPOKEN — the palette's half green" },
    { "GRAY-MID",     0x80U, 0x80U, 0x80U, "MID — neither light nor dark" }
};

#define COLOR_NONE 0xFFU

/* The 3x3x3 tensor: cell = rl*9 + gl*3 + bl, levels {0,128,255}.
 * Frozen. Ten declared, seventeen NONE. */
static const unsigned char CUBE[27] = {
    /* r=0 */            /* g=0 */              /* g=128 */
    /* b=0    b=128      b=255 */
    0,   COLOR_NONE,     3,       /* r0 g0:   BLACK, none, BLUE */
    8,   COLOR_NONE,     COLOR_NONE, /* r0 g128: GREEN-SPOKEN, none, none */
    2,   COLOR_NONE,     5,       /* r0 g255: GREEN, none, CYAN */
    /* r=128 */
    COLOR_NONE, COLOR_NONE, COLOR_NONE,
    COLOR_NONE, 9,   COLOR_NONE, /* r128 g128: none, GRAY-MID, none */
    COLOR_NONE, COLOR_NONE, COLOR_NONE,
    /* r=255 */
    1,   COLOR_NONE,     6,       /* r255 g0: RED, none, MAGENTA */
    COLOR_NONE, COLOR_NONE, COLOR_NONE,
    4,   COLOR_NONE,     7        /* r255 g255: YELLOW, none, WHITE */
};

static unsigned long color_level(unsigned long v)
{
    if (v < 64UL) {
        return 0UL;
    }
    if (v < 192UL) {
        return 1UL;
    }
    return 2UL;
}

static unsigned char color_match(unsigned long r, unsigned long g,
                                 unsigned long b)
{
    unsigned long cell;

    cell = color_level(r) * 9UL + color_level(g) * 3UL + color_level(b);
    return CUBE[cell];
}

int eden_color_match_print(unsigned long r, unsigned long g,
                           unsigned long b)
{
    unsigned char match;

    if (r > 255UL || g > 255UL || b > 255UL) {
        printf("STOP: channels are bytes, 0..255. No gray area\n");
        return 0;
    }

    match = color_match(r, g, b);

    printf(
        "color (%lu,%lu,%lu) = 0x%02lX%02lX%02lX -> cell %lu -> ",
        r, g, b, r, g, b,
        color_level(r) * 9UL + color_level(g) * 3UL + color_level(b)
    );

    if (match == COLOR_NONE) {
        printf("NONE — no declared color lives in that cell. "
               "Undeclared is an answer, not a guess\n");
    } else {
        printf("%s [%s]\n", COLORS[match].name, COLORS[match].klass);
    }

    return 1;
}

/* ---- ascii: the table and the conversion ----------------------------- */

static const char *ascii_class(unsigned long code, unsigned long *count)
{
    if (code == 32UL) {
        *count = 1UL;
        return "SPACE";
    }
    if (code >= 48UL && code <= 57UL) {
        *count = 10UL;
        return "DIGIT";
    }
    if (code >= 65UL && code <= 90UL) {
        *count = 26UL;
        return "UPPER";
    }
    if (code >= 97UL && code <= 122UL) {
        *count = 26UL;
        return "LOWER";
    }
    *count = 32UL; /* the symbols around the alphanumerics */
    return "SYMBOL";
}

int eden_ascii_print(const char *arg)
{
    unsigned long code;
    unsigned long count;
    unsigned long bit;
    char *end;
    const char *klass;

    if (arg == 0) {
        printf("ascii: the printable table, 32..126 = 95 signs\n");
        printf("  32        SPACE  (1)\n");
        printf("  33..47    SYMBOL (15)\n");
        printf("  48..57    DIGIT  (10)\n");
        printf("  58..64    SYMBOL (7)\n");
        printf("  65..90    UPPER  (26)\n");
        printf("  91..96    SYMBOL (6)\n");
        printf("  97..122   LOWER  (26)\n");
        printf("  123..126  SYMBOL (4)\n");
        printf("  conversion: 'ascii N' prints N as decimal, hex, "
               "and 8 pure bits\n");
        printf("  note: hex is binary wearing a name tag — the machine "
               "holds bits, the repo holds text, no .bin rides in Eden\n");
        return 1;
    }

    code = 0UL;
    end = 0;
    {
        const char *p;

        p = arg;
        while (*p >= '0' && *p <= '9') {
            code = code * 10UL + (unsigned long)(*p - '0');
            ++p;
        }
        end = (char *)p;
    }

    if (end == arg || *end != '\0' || code < 32UL || code > 126UL) {
        printf("STOP: ascii takes a code 32..126 (the printable table)\n");
        return 0;
    }

    klass = ascii_class(code, &count);

    printf("ascii %lu = 0x%02lX = 0b", code, code);
    for (bit = 0UL; bit < 8UL; ++bit) {
        printf("%lu", (code >> (7UL - bit)) & 1UL);
    }
    printf(" = '%c' [%s]\n", (char)code, klass);

    return 1;
}

/* ---- the tabernacle itself -------------------------------------------- */

int eden_tabernacle_run(void)
{
    static const unsigned char expected_palette_map[5] = {
        1U, 8U, 7U, 8U, 3U /* RED, GREEN-SPOKEN, WHITE, GREEN-SPOKEN, BLUE */
    };
    static const char * const palette_names[5] = {
        "RED", "GREEN", "WHITE", "GREEN", "BLUE"
    };
    unsigned char table_bytes[27UL + EDEN_COLOR_DECLARED * 3UL];
    unsigned long i;
    unsigned long t;
    unsigned long declared;
    unsigned long long hash;

    /* Verify the tensor: every declared color must land in a cell that
     * names it back. */
    for (i = 0UL; i < EDEN_COLOR_DECLARED; ++i) {
        if (color_match(COLORS[i].r, COLORS[i].g, COLORS[i].b) !=
            (unsigned char)i) {
            printf(
                "FAIL: tensor cell does not name %s back. No gray area\n",
                COLORS[i].name
            );
            return 0;
        }
    }

    declared = 0UL;
    for (i = 0UL; i < 27UL; ++i) {
        if (CUBE[i] != COLOR_NONE) {
            ++declared;
        }
    }
    if (declared != EDEN_COLOR_DECLARED) {
        printf("FAIL: tensor declared count %lu != %lu\n",
               declared, EDEN_COLOR_DECLARED);
        return 0;
    }

    /* Run the spoken palette through the tensor. */
    printf("tabernacle: declaration, then table, then tensor\n");
    printf(" the spoken palette through the tensor:\n");
    for (i = 0UL; i < EDEN_PALETTE_COUNT; ++i) {
        const unsigned char *entry;
        unsigned char match;

        entry = eden_sight_palette_entry(i);
        match = color_match(entry[0], entry[1], entry[2]);

        printf("  %lu. %-5s (%u,%u,%u) -> %s\n",
               i + 1UL,
               palette_names[i],
               (unsigned int)entry[0],
               (unsigned int)entry[1],
               (unsigned int)entry[2],
               match == COLOR_NONE ? "NONE" : COLORS[match].name);

        if (match != expected_palette_map[i]) {
            printf("FAIL: palette bar %lu mapped wrong\n", i + 1UL);
            return 0;
        }
    }

    printf(" two color laws, never conflated: LIGHT primaries red green "
           "blue (green IS a primary of light); PIGMENT primaries red "
           "yellow blue (yellow is a primary of pigment; in light it is "
           "red + green)\n");
    printf(" the tensor: 3x3x3 = 27 cells, %lu declared, %lu explicitly "
           "NONE. Exact or NONE — no nearest-color guessing\n",
           declared, 27UL - declared);

    /* The registry hash: cube bytes, then each color's channel bytes.
     * Value bytes only — never struct memory (pointers are not
     * portable-deterministic). */
    t = 0UL;
    for (i = 0UL; i < 27UL; ++i) {
        table_bytes[t++] = CUBE[i];
    }
    for (i = 0UL; i < EDEN_COLOR_DECLARED; ++i) {
        table_bytes[t++] = COLORS[i].r;
        table_bytes[t++] = COLORS[i].g;
        table_bytes[t++] = COLORS[i].b;
    }
    hash = eden_fnv1a64(EDEN_FNV_INIT, table_bytes, t);

    printf(" the frozen roll call: palette 5, gates 7, census 12, "
           "mushroom 65, children 13, colors %lu, cube 27, ascii 95\n",
           EDEN_COLOR_DECLARED);
    printf(" tabernacle: hash=fnv1a64:%016llX over %lu table bytes\n",
           hash, t);
    printf("tabernacle: PASS — inherent knowledge, frozen and verified\n");

    return 1;
}
