# Deferred Curriculum

Math was present as a planned sixth level in the supplied archive. It is intentionally outside the active MVP manifest.

Deferred tablet concepts:

- `addition_subtraction_exact_families`
- `multiplication_division_exact_families`
- `math_elastic_transfer`

Promotion gate: the first five levels must complete repeated nine-stage loop runs with all three memory stages stable and with no channel, manifest, sanitizer, or migration failures.
