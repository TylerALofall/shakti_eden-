# SHAKTI LOCK V1.1 — CLEAN AUTHORITY

**Status:** Current working authority  
**Date:** 2026-08-01  
**Source rule:** Built from Tyler's latest direct decisions only. Older locks, Revision 5, handoffs, schemas, tables, and code are evidence, not authority.  
**Repository rule:** No source code changes are authorized by this document.

## 1. Core boundary

- Shakti is one self-contained iOS application with a deterministic C99 core.
- Swift is added later only as the Apple-facing wrapper for approved platform APIs.
- No daemon, subprocess, second core, resident Linux controller, or external process is part of Shakti.
- Shakti's app container is her turtle shell: Eden, School, memory, lessons, tables, and local state remain inside it.
- MCP is her gated reach outside the shell.
- External tools are unavailable until Tyler adds and enables them in the menu.
- Internet, external storage, microphone, camera, runners, and other tools are detachable capabilities.
- Cutting external capabilities must not delete Shakti's local state or memory.

## 2. Internal iteration, heartbeat, and routes

- Shakti performs the internal iteration.
- MCP does not think, iterate, or run a loop.
- The nine Ga-Gi items are available routes, not nine compulsory steps fired every cycle.
- Heartbeat controls how long an internal run may continue.
- A heartbeat opens with:
  - start epoch;
  - timer limit;
  - maximum iteration count.
- Shakti checks both limits during internal iteration.
- The first limit reached ends the run after the current atomic action finishes.
- The heartbeat closes at the current epoch time.
- Reflection is not the heartbeat timer.

## 3. MCP

MCP is only:

- a router;
- a permission gate;
- a dispatcher;
- a receipt recorder;
- a route for approved memory calls.

Before every tool call, MCP must verify:

```text
registered
+ present in the menu
+ enabled by Tyler
+ permitted for this call
= may execute
```

A failed check returns `DENIED` and performs no external action.

Tyler may stop an active MCP-routed tool without stopping Shakti's local awake state.

## 4. Reflection gate

Only Shakti's approved MCP tool calls advance the reflection counter.

These do not count:

- internal thinking;
- remaining awake locally;
- menu checks;
- messages;
- notebook writing;
- local activity that does not invoke an MCP tool.

The gate is:

```text
tool call 10
→ reflection becomes due

tool calls 11, 12, and 13
→ Shakti may defer

before tool call 14
→ reflection is required
```

A memory-capsule retrieval through MCP is a tool call.

## 5. Reflection capsule

After a completed reflection, one immutable atomic capsule is appended to long-term memory.

The capsule contains:

- every message since the previous completed reflection;
- Shakti's chosen title;
- all thirteen reflection answers;
- Shakti's chosen tags;
- optional links to notes or reminders she decides are relevant.

The current Goal/system message remains resident above reflection and is not replaced by it.

Reflection exists to learn honestly from successes and failures. It is not punishment and does not hide mistakes.

## 6. Memory

- Eden and School remain resident.
- Shakti may keep personally selected memory capsules resident.
- Short-term memory may hold whole retrieved capsules.
- Long-term memory is append-only and immutable.
- Reflection capsules are retrieved whole for context.
- Notes are scratch-pad records and are not copied into every capsule automatically.
- Shakti decides which notes are worth linking.
- A reminder is an immutable future-point record stored in the notes area.
- Completing a reminder appends a linked completion record; it does not edit the original.

## 7. Lesson levels

```text
Level 0  Glyphs
Level 1  Counting
Level 2  ABC
Level 3  Colors
Level 4  Shapes
Level 5  Basic math
```

## 8. Learning order

- A complete new lesson is presented solo first.
- Only one new lesson is introduced at a time.
- The first presentation must not mix two unknown concepts.
- The complete solo lesson must finish before crossing is allowed.
- After grounding, the lesson may cross exhaustively with previously learned lessons.
- Two-way, three-way, and four-way combinations are allowed only after every included lesson was learned solo.
- The first impression is the most important.
- Each lesson section contains its own hard-coded answer table.
- The answer table is validation truth; training teaches meaning and behavior.

## 9. Two-tier token system

### Tier 1 — characters and output tokens

- Exact characters, digits, operators, punctuation, space, and required keys.
- Coverage begins with ASCII 32-126 plus separately approved math/counting symbols such as `×`, `÷`, and `•`.
- Character identity is exact.
- `A` is `A`; `a` is `a`.
- Do not rename them `upper_A` or `lower_a`.
- File extensions are not stripped to pretend different sensory inputs are identical.

### Tier 2 — words and concepts

- Shakti thinks and validates through words and concepts.
- Her internal dictionary resolves a word to an ordered character sequence.
- She writes by emitting Tier 1 characters.
- A completed known word may trigger its whole-word audio.
- Crossed lessons are compositions of grounded roots, not millions of permanent flat tokens.

## 10. Canonical naming

- Use `snake_case`.
- Every modality for a token uses the same canonical basename.
- Capitalization remains significant.
- Names follow spoken order.
- Simple approved example:

```text
red_triangle.*
```

- Do not force old aliases or descriptive internal names into human-facing token identity.

## 11. Token directories

```text
Tokens/
├── text/
├── sound_art/
├── written_art/
└── visual_art/
```

A modality file exists only when that modality exists.

## 12. Four-panel lesson

```text
top-left      visual_art
top-right     voice_text
bottom-left   written_text
bottom-right  text
```

- `sound_art` controls timing; it is not a fifth visual panel.
- Top-right may show the spoken word in quotes.
- Bottom-left reveals letters one at a time.
- Revealed letters remain visible until the next word starts.
- Bottom-right shows the complete word.
- The four panels form one lesson unit.

## 13. Written text and keyboard action

- Written glyphs use existing `uint64_t` 8x8 data.
- 8x10 glyph sources are rejected.
- Glyphs may be scaled for display without changing their 8x8 identity.
- Black is the default glyph color until a color has been taught solo.
- After grounding, taught colors may appear in crossed written-art lessons.

Each character key action is atomic:

```text
key event
→ emit exact character
→ display its glyph
→ play its character audio
→ append it to the current word buffer
→ test the dictionary for a completed word
→ when matched, display and speak the whole word
```

Future voice input may call the same key-event bundle through the Swift wrapper.

## 14. Audio timing

- Core lesson audio is 16 kHz WAV.
- Add 0.2 seconds before and 0.2 seconds after each spoken WAV.
- Actual playback completion controls progression.
- File-load speed never controls lesson speed.
- Letter reveal follows natural speaking speed.
- No lesson advances while required audio is still playing.

## 15. Counting visual

- A number lesson shows the integer and its count.
- A 32x32 ball may be an interactive counting button.
- Balls align in rows of ten.
- When needed, ball size may reduce to 16x16 and then 8x8.
- Rows of ten prepare later decimal and fraction relationships.

## 16. Color, shape, number, and alphabet crossing

- Every approved color may cross with every approved shape.
- Colors, shapes, numbers, and alphabet may later cross exhaustively.
- Crossed artifacts are generated from grounded roots.
- Some grounding rules may have explicit local exceptions when that makes a lesson clearer.
- Exceptions must be deliberate and must not silently rewrite the global rules.

## 17. Memory continuity

- Required roots, core tables, glyphs, active lesson state, and small essential audio remain available to the working runtime.
- Full songs and large media remain on disk and stream only when triggered.
- Continuity uses:
  - append-only local journal records;
  - sequence numbers;
  - checksums;
  - atomic checkpoints;
  - exact replay after suspension or relaunch.
- Recovery must not depend on pretending RAM can never stop.
- No external live service is required for recovery.

## 18. Victory song

- `Eden_Grows.wav` plays after every successful completion of Level 2.
- It is a victory dance.
- It stays in long-term/on-disk media storage and streams when triggered.

## 19. Repository authority

- Candidate source base: `copilot/organize-project-structure`.
- GitHub `main` remains untouched.
- `SHAKTI_C99_HANDOFF.zip` is accidental and is not authority.
- Builders, artifacts, schemas, tables, handoffs, and old masters are candidate evidence until validated.
- No builder, test, script, executable, or generated tool runs merely because it exists.
- No source is deleted, overwritten, renamed, or repaired in bulk.
- Work proceeds one complete section or module at a time.
- Every code change must name:
  - exact allowed paths;
  - exact base commit;
  - exact validator;
  - exact pass/fail rule.

## 20. Current next step

1. Keep this document as the clean authority file.
2. Compare the candidate repository against this document.
3. Produce a fresh read-only inventory from the actual repository tree.
4. Make no source changes until the inventory is reviewed.
