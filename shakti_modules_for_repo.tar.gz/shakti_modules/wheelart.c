/* wheelart.c — is the mirror law the thing that draws the heart?
 *
 * Tyler saw a cardioid — a heart — come out of a wheel of chords, and said
 * "there's a mirrored heart beat."
 *
 * There is a classical fact behind that picture. Put N points evenly on a
 * circle and draw a chord from every point i to point (k*i mod N). The
 * envelope of those chords is an epicycloid with (k-1) cusps:
 *
 *     k = 2  ->  1 cusp   ->  CARDIOID      (heart)
 *     k = 3  ->  2 cusps  ->  nephroid      (kidney)
 *     k = 4  ->  3 cusps
 *
 * So the heart is drawn by DOUBLING and by nothing else. This program asks
 * what doubling is on Tyler's own wheels, and whether the mirror law is the
 * same map. It verifies, it does not assert.
 *
 * It also writes an SVG of the wheel so the picture can be compared to his.
 * SVG is text; this is plain C99 writing characters.
 *
 * C99. No heap, no float in the verification. Floating point appears ONLY in
 * the SVG coordinates, which are decoration, never a law.
 */
#include <stdio.h>
#include <math.h>

#define E2 5U
#define E3 4U
#define E5 2U
#define E7 2U
#define CELLS 80U
#define WHEEL 15120UL

static unsigned long period_of(unsigned int a, unsigned int b,
                               unsigned int c, unsigned int d)
{
    unsigned long p = 1UL;
    unsigned int k;
    for (k = 0U; k < a; ++k) { p *= 2UL; }
    for (k = 0U; k < b; ++k) { p *= 3UL; }
    for (k = 0U; k < c; ++k) { p *= 5UL; }
    for (k = 0U; k < d; ++k) { p *= 7UL; }
    return p;
}

static unsigned int index_of(unsigned int a, unsigned int b,
                             unsigned int c, unsigned int d)
{
    return ((a * E3 + b) * E5 + c) * E7 + d;
}

int main(void)
{
    unsigned int a, b, c, d;
    unsigned long tetp[CELLS];
    unsigned int mirror_idx[CELLS];
    int fail_reflect = 0, fail_product = 0, fail_double = 0;
    unsigned int i;
    FILE *svg;

    /* ---- build the lattice, and its mirror, from the exponents ---- */
    for (a = 0U; a < E2; ++a) {
      for (b = 0U; b < E3; ++b) {
        for (c = 0U; c < E5; ++c) {
          for (d = 0U; d < E7; ++d) {
            unsigned int i0 = index_of(a, b, c, d);
            unsigned int im = index_of(E2 - 1U - a, E3 - 1U - b,
                                       E5 - 1U - c, E7 - 1U - d);
            tetp[i0] = period_of(a, b, c, d);
            mirror_idx[i0] = im;
            /* CLAIM 1: the mirror is exact reflection of the index */
            if (im != (CELLS - 1U) - i0) { fail_reflect++; }
          }
        }
      }
    }

    /* CLAIM 2: cell x mirror == wheel, every cell */
    for (i = 0U; i < CELLS; ++i) {
        if (tetp[i] * tetp[mirror_idx[i]] != WHEEL) { fail_product++; }
    }

    /* CLAIM 3: doubling a cell moves its index by exactly +16 */
    for (a = 0U; a < E2 - 1U; ++a) {
      for (b = 0U; b < E3; ++b) {
        for (c = 0U; c < E5; ++c) {
          for (d = 0U; d < E7; ++d) {
            unsigned int i0 = index_of(a, b, c, d);
            unsigned int i1 = index_of(a + 1U, b, c, d);
            if (i1 != i0 + 16U) { fail_double++; }
            if (tetp[i1] != tetp[i0] * 2UL) { fail_double++; }
          }
        }
      }
    }

    printf("=== the mirror law, checked three ways ===\n\n");
    printf("  mirror index == 79 - index, all 80 cells    %s\n",
           fail_reflect == 0 ? "PASS" : "FAIL");
    printf("  cell x mirror == 15120, all 80 cells        %s\n",
           fail_product == 0 ? "PASS" : "FAIL");
    printf("  doubling a cell moves the index by +16      %s\n",
           fail_double == 0 ? "PASS" : "FAIL");

    printf("\n  So on the 80-cell wheel the mirror is a REFLECTION,\n");
    printf("  and doubling is a TRANSLATION by 16. Two different maps.\n");

    /* ---- the 210 organ wheel ---- */
    printf("\n=== the 210 organ wheel ===\n\n");
    {
        static const unsigned long ORGAN[15] = {
            1UL,2UL,3UL,5UL,7UL,6UL,10UL,14UL,15UL,21UL,30UL,35UL,42UL,70UL,210UL
        };
        static const char *const NAME[15] = {
            "heart","eyes","ears","hands","voice","mind","soul","body",
            "self","spirit","flesh","breath","blood","bone","all"
        };
        int j;
        printf("  the organ whose period IS the doubling map:\n");
        for (j = 0; j < 15; ++j) {
            if (ORGAN[j] == 2UL) {
                printf("    %s (period 2).  Its mirror is 210/2 = %lu.\n",
                       NAME[j], 210UL / ORGAN[j]);
            }
        }
        printf("\n  is 105 in the organ table? ");
        {
            int found = 0;
            for (j = 0; j < 15; ++j) { if (ORGAN[j] == 105UL) { found = 1; } }
            printf("%s\n", found ? "yes" : "NO");
        }
        printf("\n  k = 2 draws a cardioid (1 cusp). k is the multiplier.\n");
        printf("  The organ with period 2 is the doubling map, and it is\n");
        printf("  the one organ in the table with no mirror partner.\n");
    }

    /* ---- write the picture ---- */
    svg = fopen("wheel_cardioid.svg", "w");
    if (svg == NULL) { printf("\ncould not write the svg\n"); return 1; }

    fprintf(svg, "<svg xmlns=\"http://www.w3.org/2000/svg\" "
                 "viewBox=\"0 0 900 460\" width=\"900\" height=\"460\">\n");
    fprintf(svg, "<rect width=\"900\" height=\"460\" fill=\"#000\"/>\n");

    {
        int panel;
        const unsigned int NPTS[3] = { 80U, 210U, 80U };
        const unsigned int MULT[3] = { 2U, 2U, 3U };
        const char *LBL[3] = {
            "80 cells, k=2 : cardioid",
            "210 wheel, k=2 : cardioid",
            "80 cells, k=3 : nephroid"
        };
        const char *COL[3] = { "#ffd75e", "#7ec8ff", "#9ee49e" };

        for (panel = 0; panel < 3; ++panel) {
            double cx = 150.0 + 300.0 * (double)panel;
            double cy = 210.0;
            double r = 130.0;
            unsigned int n = NPTS[panel];
            unsigned int k = MULT[panel];
            unsigned int t;

            fprintf(svg, "<circle cx=\"%.1f\" cy=\"%.1f\" r=\"%.1f\" "
                         "fill=\"none\" stroke=\"#333\" stroke-width=\"1\"/>\n",
                    cx, cy, r);
            fprintf(svg, "<g stroke=\"%s\" stroke-width=\"0.5\" "
                         "stroke-opacity=\"0.75\" fill=\"none\">\n", COL[panel]);
            for (t = 0U; t < n; ++t) {
                unsigned int u = (k * t) % n;
                double a0 = 6.283185307179586 * (double)t / (double)n;
                double a1 = 6.283185307179586 * (double)u / (double)n;
                fprintf(svg, "<line x1=\"%.2f\" y1=\"%.2f\" "
                             "x2=\"%.2f\" y2=\"%.2f\"/>\n",
                        cx + r * cos(a0), cy + r * sin(a0),
                        cx + r * cos(a1), cy + r * sin(a1));
            }
            fprintf(svg, "</g>\n");
            fprintf(svg, "<text x=\"%.1f\" y=\"400\" fill=\"#bbb\" "
                         "font-family=\"monospace\" font-size=\"14\" "
                         "text-anchor=\"middle\">%s</text>\n",
                    cx, LBL[panel]);
        }
    }
    fprintf(svg, "<text x=\"450\" y=\"435\" fill=\"#888\" "
                 "font-family=\"monospace\" font-size=\"12\" "
                 "text-anchor=\"middle\">chord i to (k*i mod n) — the "
                 "envelope has k-1 cusps</text>\n");
    fprintf(svg, "</svg>\n");
    fclose(svg);
    printf("\n  wrote wheel_cardioid.svg\n");

    return (fail_reflect + fail_product + fail_double) != 0;
}
