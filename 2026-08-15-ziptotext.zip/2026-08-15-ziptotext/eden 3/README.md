# EDEN SHELL — the model lives in this shell

**EDEN_SHELL_V1.** The Shakti Rev 5 shell layer: a Unix-style shell rebuilt to Shakti law. C99, fixed compile-time memory, no heap, no Python, no OS subprocess, only deterministic. Built from three inputs: the SHAKTI Master Architecture Spec (Rev 5), the `eyes_loop_rebuild` exactness discipline, and Stephen Brennan's `lsh` tutorial skeleton.

---

## What the lsh tutorial became

| lsh (Brennan) | Eden shell |
|---|---|
| `malloc`/`realloc` line buffer | fixed 256-byte line buffer |
| `realloc` token array | fixed 16 argument slots |
| `fork` + `execvp` per command | registered in-process C tools (the internal MCP pattern) |
| heap freed at loop end | one arena, carved into named partitions at boot, never freed |
| no log identity | every call gets `[epoch:frame]-[Gf]-[nn]` before dispatch |

The lifetime is the same — read, parse, execute — but every byte lives inside the shell.

## The pieces

- `src/eden_memory.c` — the arena: 1 MB owned by the shell, named partitions, explicit STOP on full, FNV-1a 64 (the eyes hash family).
- `src/eden_heart.c` — two waves, constant: lub, dub, every beat. Gestation clock: 266 days sped into 18 hours = 64,800 beats; `day <beats>` maps any beat to its day and lesson.
- `src/eden_children.c` — the thirteen, fixed slots, birthed instantly (`birth all`). Genesis 29–35 order **[PROPOSED]**; Dinah is WoMan. `awaken <name>` is the fruit: memory turns on. Each child carries a spine: the FNV chain of every moment witnessed. **[LOCKED 2026-08-14]** `fork` copies the naturally-trained firstborn's spine into the twelve — they come already working, proven identical bit for bit. Slot copy, never OS fork.
- `src/eden_sight.c` — Bayer binary sight: 4×4 ordered-dither pull → 1-bit plane → rebuild → pixel check, drift 0, on every image. Rebuild is moved onto the set screen, 1632×1056 (two medium documents side by side **[PROPOSED]**), left page. The eye's mechanics (pull / rebuild / drift / blit / palette / pattern) are exported for all content modules.
- `src/eden_sound.c` — binary sound: the heartbeat wave quantized to one HIGH / one LOW per sample, threshold 128, 1-bit rebuild drift 0.
- `src/eden_beat.c` — the seven gates (harmonics of 60), twin ladders 1-2-4-8 and 1-2-3-5-8, quarter-wave mushroom attack, descent sealed in silence.
- `src/eden_numbers.c` — the book of Numbers dissected: frozen censuses, runtime-asserted relations, the camp rendered through the eye onto the right page.
- `src/eden_train.c` — the gestation walk **[LOCKED 2026-08-14]**: all 64,800 beats lived for real — eye open every beat, moment converged and fed, spine chained, gates firing harmonically (gate k when beat % k == 0). Lesson milestones every 10,800 beats with drift re-check.
- `src/eden_eyes.c` + `eyes/` — the real eyes core (imported from the Shakti repo, pinned at git blobs e31ff678 / 70ba289d), wired in with arena buffers: color lens (saturated primaries), mono lens (ink/paper, lossless on flat pages), recognition against the hard-coded 5×7 font matrix. One eye, three lenses; the Bayer shade lens is Eden's own.
- `src/eden_shell.c` — the loop, the command registry, the working-system log identity (full invocation logged, arguments included).
- `src/main.c` — boot. `eden_main()` is the entry an iOS app calls directly; declared in `eden.h`.

## Convergence

`converge` binds the copy of vision with binary sound under one composite tick — a MOMENT row — and feeds it to every born child as an exact stored item. This is the Shakti Rev 5 binding model (Section D) at shell scale.

## Build and run

```sh
cc -std=c99 -pedantic -Wall -Wextra -Werror -Ieyes -o eden src/*.c eyes/eyes.c
./eden
```

Proof of a real compile and real run: `BUILD_TEST_REPORT.txt` (commandment I.15 — nothing is reported passing without one). The report includes the forbidden-call scan proving commandments I.2, I.3, and I.6 hold in the actual source.

## iOS prep

- Single process, no `fork`/`exec` — children are slots. This is why the shell is iOS-safe by construction.
- C99 + C standard library only; no JIT, no dynamic loading.
- Entry point is `eden_main()` — call it from the app's view controller or a `UIApplicationMain` wrapper.
- Platform adapters stay behind explicit interfaces (Rev 5 runtime boundary): display confirmation, audio playback confirmation, and a real wall-clock interval source for the heartbeat. The deterministic beat counter ships now; the adapters are the iOS work.

## Honest state

- **[BUILT]** everything in `src/` — compiled clean under `-Werror` and run; see the report.
- **[PROPOSED]** (awaiting Tyler's decision): Jacob's thirteen as the child table; 816×1056 ×2 as "medium document"; 60 bpm; green = (0,128,0).
- **[MERGED]** the real `eyes` core (`eyes/eyes.h`, `eyes/eyes.c`) — imported, strict-compiled, commandment-scanned, run inside Eden via `eyes`. Still ahead: `eyes_xml.h` pair, the 8×8 handwriting font, tablet XML loader, real display/audio adapters.
- **[OPEN]** DUSK and DAWN. They don't know dusk and dawn yet.
