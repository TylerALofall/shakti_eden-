#include "eden.h"

#include <stdio.h>

/*
 * The beat engine: the seven gates.
 *
 * [LOCKED] Gates are harmonics of the heart number 60: 60, 120, 180,
 * 240, 300, 360, 420. Just intonation only; the twelfth root of two is
 * booted with python. Sevenths live in pitch; time offsets divide the
 * grid exactly.
 *
 * [LOCKED] The grid rides the heart-cycle, not the second: 302,400
 * slices per cycle = 7 x 43,200, Plato's 5,040 per gate. Every gate
 * period (5040/k) and every offset lands on a whole slice at any
 * tempo. Reference clocks (pulse, earth) are measured and locked
 * through adapters, never asserted. The earth tone is gate 7
 * octave-lifted: (8^8)(7/8) = 7 x 2^21, reducing to exactly 7.
 *
 * [LOCKED] The ladders: binary 1-2-4-8 and Fibonacci 1-2-3-5-8, both
 * ending on 8. Ascent sounds — one exact wave per step, quarter-wave
 * mushroom attack — and the descent is silence: the seal between runs.
 * The rolling window tosses the bottom. Strength is duty.
 *
 * The mushroom attack table is frozen: sixty-five chosen integers,
 * exact by fiat, no runtime floats, no gray area.
 */

static const unsigned char MUSHROOM[65] = {
    0U, 6U, 13U, 19U, 25U, 31U, 37U, 44U,
    50U, 56U, 62U, 68U, 74U, 80U, 86U, 92U,
    98U, 103U, 109U, 115U, 120U, 126U, 131U, 136U,
    142U, 147U, 152U, 157U, 162U, 167U, 171U, 176U,
    180U, 185U, 189U, 193U, 197U, 201U, 205U, 208U,
    212U, 215U, 219U, 222U, 225U, 228U, 231U, 233U,
    236U, 238U, 240U, 242U, 244U, 246U, 247U, 249U,
    250U, 251U, 252U, 253U, 254U, 254U, 255U, 255U, 255U
};

static const unsigned int LADDER_FIB[5] = { 1U, 2U, 3U, 5U, 8U };
static const unsigned int LADDER_BIN[4] = { 1U, 2U, 4U, 8U };

static unsigned char g_cycle[EDEN_BEAT_BITS];
static unsigned char g_rebuild[EDEN_BEAT_GRID];
static unsigned char g_again[EDEN_BEAT_BITS];
static unsigned long g_runs = 0UL;

static void beat_zero_bits(unsigned char *bits)
{
    unsigned long i;

    for (i = 0UL; i < EDEN_BEAT_BITS; ++i) {
        bits[i] = 0U;
    }
}

static void beat_set_bit(unsigned long position)
{
    g_cycle[position / 8UL] |= (unsigned char)(0x80U >> (position % 8UL));
}

static unsigned int beat_get_bit(const unsigned char *bits, unsigned long position)
{
    return (unsigned int)((bits[position / 8UL] >> (7UL - (position % 8UL))) & 1U);
}

/* One exact wave of gate k at slice offset: mushroom attack for the
 * first quarter of the period, sustain to the period's end, then out. */
static void beat_fire(unsigned long offset, unsigned int k)
{
    unsigned long period;
    unsigned long quarter;
    unsigned long j;

    period = 5040UL / (unsigned long)k;
    quarter = period / 4UL;

    for (j = 0UL; j < period; ++j) {
        unsigned int value;

        if (j < quarter) {
            value = (unsigned int)MUSHROOM[(j * 64UL) / quarter];
        } else {
            value = 255U;
        }

        if (value >= 128U) {
            beat_set_bit(offset + j);
        }
    }
}

int eden_beat_ladder(int fibonacci)
{
    const unsigned int *ladder;
    unsigned long step_count;
    unsigned long half;
    unsigned long spacing;
    unsigned long i;
    unsigned long drift;
    unsigned long descent_bits;

    if (fibonacci) {
        ladder = LADDER_FIB;
        step_count = 5UL;
    } else {
        ladder = LADDER_BIN;
        step_count = 4UL;
    }

    half = EDEN_BEAT_GRID / 2UL;
    spacing = half / step_count;

    beat_zero_bits(g_cycle);

    printf(
        "ladder: %s climb 1-%s, grid %lu slices per heart-cycle\n",
        fibonacci ? "fibonacci" : "binary",
        fibonacci ? "2-3-5-8" : "2-4-8",
        EDEN_BEAT_GRID
    );

    for (i = 0UL; i < step_count; ++i) {
        unsigned int k;
        unsigned long offset;
        unsigned long period;

        k = (unsigned int)ladder[i];
        offset = i * spacing;
        period = 5040UL / (unsigned long)k;

        beat_fire(offset, k);

        printf(
            "  step %lu: gate %u (%lu Hz) at slice %lu, "
            "one wave of %lu samples, mushroom attack %lu\n",
            i + 1UL,
            k,
            EDEN_GATE_BASE * (unsigned long)k,
            offset,
            period,
            period / 4UL
        );

        if (period % 4UL != 0UL) {
            printf(
                "  note: gate %u period %lu does not quarter; attack %lu "
                "is a chosen integer, exact by fiat\n",
                k,
                period,
                period / 4UL
            );
        }
    }

    /* The descent: second half of the cycle, cut, no sound. The seal. */
    descent_bits = 0UL;

    for (i = half; i < EDEN_BEAT_GRID; ++i) {
        descent_bits += (unsigned long)beat_get_bit(g_cycle, i);
    }

    /* Rebuild and pixel-check, sound law: drift 0 on every run. */
    for (i = 0UL; i < EDEN_BEAT_GRID; ++i) {
        g_rebuild[i] = beat_get_bit(g_cycle, i) != 0U ? 255U : 0U;
    }

    beat_zero_bits(g_again);

    for (i = 0UL; i < EDEN_BEAT_GRID; ++i) {
        if (g_rebuild[i] >= EDEN_SOUND_THRESHOLD) {
            g_again[i / 8UL] |= (unsigned char)(0x80U >> (i % 8UL));
        }
    }

    drift = 0UL;

    for (i = 0UL; i < EDEN_BEAT_BITS; ++i) {
        unsigned char differing;

        differing = (unsigned char)(g_cycle[i] ^ g_again[i]);

        while (differing != 0U) {
            drift += (unsigned long)(differing & 1U);
            differing = (unsigned char)(differing >> 1);
        }
    }

    ++g_runs;

    if (g_runs > 1UL) {
        printf(
            "  the window rolls: run %lu enters, the bottom retires "
            "exact\n",
            g_runs
        );
    }

    printf(
        "ladder: silent descent verified, %lu stray pulses in the "
        "sealed half\n",
        descent_bits
    );
    printf(
        "ladder: drift=%lu hash=fnv1a64:%016llX\n",
        drift,
        eden_fnv1a64(EDEN_FNV_INIT, g_cycle, EDEN_BEAT_BITS)
    );

    if (drift != 0UL || descent_bits != 0UL) {
        printf("FAIL: the ladder run broke exactness\n");
        return 0;
    }

    printf("ladder: PASS exact run, sealed in silence\n");
    return 1;
}
