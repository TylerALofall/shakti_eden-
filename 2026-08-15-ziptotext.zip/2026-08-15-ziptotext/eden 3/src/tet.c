#include "tet.h"

/*
 * Implementation notes.
 *
 * Powers are accumulated by repeated multiplication, not by a table and
 * not by pow(). The exponent ranges are tiny and fixed, so the loops are
 * bounded at compile time and the result is exact integer arithmetic.
 *
 * tet_verify walks every law in order and stops at the first failure,
 * returning its number. A caller that gets a non-zero value knows
 * exactly which law broke — no gray area, no partial pass.
 */

static unsigned long tet_pow(unsigned long base, unsigned int exponent)
{
    unsigned long value;
    unsigned int i;

    value = 1UL;
    for (i = 0U; i < exponent; ++i) {
        value *= base;
    }
    return value;
}

static int tet_range_ok(
    unsigned int a,
    unsigned int b,
    unsigned int c,
    unsigned int d
)
{
    if (a >= TET_E2) {
        return 0;
    }
    if (b >= TET_E3) {
        return 0;
    }
    if (c >= TET_E5) {
        return 0;
    }
    if (d >= TET_E7) {
        return 0;
    }
    return 1;
}

int tet_index(
    unsigned int a,
    unsigned int b,
    unsigned int c,
    unsigned int d,
    unsigned int *out
)
{
    if (out == 0) {
        return 0;
    }
    if (!tet_range_ok(a, b, c, d)) {
        return 0;
    }

    *out = ((a * TET_E3 + b) * TET_E5 + c) * TET_E7 + d;
    return 1;
}

int tet_period(
    unsigned int a,
    unsigned int b,
    unsigned int c,
    unsigned int d,
    unsigned long *out
)
{
    if (out == 0) {
        return 0;
    }
    if (!tet_range_ok(a, b, c, d)) {
        return 0;
    }

    *out = tet_pow(2UL, a) * tet_pow(3UL, b) *
           tet_pow(5UL, c) * tet_pow(7UL, d);
    return 1;
}

int tet_mirror(
    unsigned int a,
    unsigned int b,
    unsigned int c,
    unsigned int d,
    unsigned int *ma,
    unsigned int *mb,
    unsigned int *mc,
    unsigned int *md
)
{
    if (ma == 0 || mb == 0 || mc == 0 || md == 0) {
        return 0;
    }
    if (!tet_range_ok(a, b, c, d)) {
        return 0;
    }

    /* The mirror is subtraction. No table, no search. */
    *ma = (TET_E2 - 1U) - a;
    *mb = (TET_E3 - 1U) - b;
    *mc = (TET_E5 - 1U) - c;
    *md = (TET_E7 - 1U) - d;
    return 1;
}

int tet_build(unsigned long *table, unsigned long capacity)
{
    unsigned int a;
    unsigned int b;
    unsigned int c;
    unsigned int d;

    if (table == 0) {
        return 0;
    }
    if (capacity < (unsigned long)TET_CELLS) {
        return 0;
    }

    for (a = 0U; a < TET_E2; ++a) {
        for (b = 0U; b < TET_E3; ++b) {
            for (c = 0U; c < TET_E5; ++c) {
                for (d = 0U; d < TET_E7; ++d) {
                    unsigned int slot;
                    unsigned long value;

                    if (!tet_index(a, b, c, d, &slot)) {
                        return 0;
                    }
                    if (!tet_period(a, b, c, d, &value)) {
                        return 0;
                    }
                    table[slot] = value;
                }
            }
        }
    }
    return 1;
}

int tet_fires(unsigned long period, unsigned long slice)
{
    if (period == 0UL) {
        return 0;
    }
    return (slice % period == 0UL) ? 1 : 0;
}

int tet_depth(
    const unsigned long *periods,
    unsigned long count,
    unsigned long slice,
    unsigned long *out
)
{
    unsigned long i;
    unsigned long depth;

    if (periods == 0 || out == 0) {
        return 0;
    }

    depth = 0UL;
    for (i = 0UL; i < count; ++i) {
        if (periods[i] == 0UL) {
            return 0;
        }
        if (tet_fires(periods[i], slice)) {
            depth += 1UL;
        }
    }
    *out = depth;
    return 1;
}

int tet_verify(void)
{
    unsigned long table[TET_CELLS];
    unsigned char seen[TET_CELLS];
    unsigned int a;
    unsigned int b;
    unsigned int c;
    unsigned int d;
    unsigned int i;
    unsigned int j;
    unsigned long divisor_count;
    unsigned long classes;

    /* ---- law 1: index is a bijection onto [0,80) ------------------- */
    for (i = 0U; i < (unsigned int)TET_CELLS; ++i) {
        seen[i] = 0U;
        table[i] = 0UL;
    }
    for (a = 0U; a < TET_E2; ++a) {
        for (b = 0U; b < TET_E3; ++b) {
            for (c = 0U; c < TET_E5; ++c) {
                for (d = 0U; d < TET_E7; ++d) {
                    unsigned int slot;

                    if (!tet_index(a, b, c, d, &slot)) {
                        return 1;
                    }
                    if (slot >= (unsigned int)TET_CELLS) {
                        return 1;
                    }
                    if (seen[slot] != 0U) {
                        return 1;
                    }
                    seen[slot] = 1U;
                }
            }
        }
    }
    for (i = 0U; i < (unsigned int)TET_CELLS; ++i) {
        if (seen[i] == 0U) {
            return 1;
        }
    }

    if (!tet_build(table, (unsigned long)TET_CELLS)) {
        return 1;
    }

    /* ---- law 2: every cell divides the wheel ----------------------- */
    for (i = 0U; i < (unsigned int)TET_CELLS; ++i) {
        if (table[i] == 0UL) {
            return 2;
        }
        if (TET_WHEEL % table[i] != 0UL) {
            return 2;
        }
    }

    /* ---- law 3: all 80 periods are distinct ------------------------ */
    for (i = 0U; i < (unsigned int)TET_CELLS; ++i) {
        for (j = i + 1U; j < (unsigned int)TET_CELLS; ++j) {
            if (table[i] == table[j]) {
                return 3;
            }
        }
    }

    /* ---- law 4: they are EXACTLY the divisors of the wheel --------- */
    divisor_count = 0UL;
    {
        unsigned long n;

        for (n = 1UL; n <= TET_WHEEL; ++n) {
            if (TET_WHEEL % n == 0UL) {
                divisor_count += 1UL;
            }
        }
    }
    if (divisor_count != (unsigned long)TET_CELLS) {
        return 4;
    }

    /* ---- law 5: cell x mirror == wheel, every cell ----------------- */
    for (a = 0U; a < TET_E2; ++a) {
        for (b = 0U; b < TET_E3; ++b) {
            for (c = 0U; c < TET_E5; ++c) {
                for (d = 0U; d < TET_E7; ++d) {
                    unsigned int ma;
                    unsigned int mb;
                    unsigned int mc;
                    unsigned int md;
                    unsigned long here;
                    unsigned long there;

                    if (!tet_mirror(a, b, c, d, &ma, &mb, &mc, &md)) {
                        return 5;
                    }
                    if (!tet_period(a, b, c, d, &here)) {
                        return 5;
                    }
                    if (!tet_period(ma, mb, mc, md, &there)) {
                        return 5;
                    }
                    if (here * there != TET_WHEEL) {
                        return 5;
                    }
                }
            }
        }
    }

    /* ---- law 6: 432 sits at (4,3,0,0) ------------------------------ */
    {
        unsigned long value;

        if (!tet_period(4U, 3U, 0U, 0U, &value)) {
            return 6;
        }
        if (value != TET_PYTHAGOREAN) {
            return 6;
        }
    }

    /* ---- law 7: 35 sits at (0,0,1,1) ------------------------------- */
    {
        unsigned long value;

        if (!tet_period(0U, 0U, 1U, 1U, &value)) {
            return 7;
        }
        if (value != TET_JUST) {
            return 7;
        }
    }

    /* ---- law 8: the two halves multiply to the wheel --------------- */
    if (TET_PYTHAGOREAN * TET_JUST != TET_WHEEL) {
        return 8;
    }

    /* ---- law 9: the wheel tiles the womb --------------------------- */
    if (TET_WOMB % TET_WHEEL != 0UL) {
        return 9;
    }

    /* ---- law 10: the wheel tiles the slice grid -------------------- */
    if (TET_SLICE_GRID % TET_WHEEL != 0UL) {
        return 10;
    }

    /* ---- law 11: exactly 16 pitch classes, every one odd ----------- */
    classes = 0UL;
    for (b = 0U; b < TET_E3; ++b) {
        for (c = 0U; c < TET_E5; ++c) {
            for (d = 0U; d < TET_E7; ++d) {
                unsigned long value;

                if (!tet_period(0U, b, c, d, &value)) {
                    return 11;
                }
                if (value % 2UL == 0UL) {
                    return 11;
                }
                classes += 1UL;
            }
        }
    }
    if (classes != (unsigned long)TET_CLASSES) {
        return 11;
    }

    return 0;
}
