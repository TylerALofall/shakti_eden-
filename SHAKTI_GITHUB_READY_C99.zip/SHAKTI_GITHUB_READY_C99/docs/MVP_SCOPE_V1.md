# MVP Scope — First Five Levels

## Locked scope

The runnable MVP covers exactly five curriculum levels while the nine-stage loop and three-stage memory model are proven:

| Order | Level | Current state |
|---:|---|---|
| 0 | `foundation_ascii` | Implemented |
| 1 | `counting` | Implemented through zero–ten; later counting remains planned |
| 2 | `alphabet` | Implemented |
| 3 | `colors` | Planned |
| 4 | `shapes` | Planned |

Math is deferred. It must not enter the active manifest or bulk-import output until these five levels run cleanly through the loop and memory tests.

## Four-field stone contract

`<text>` is the source value taken from the curriculum list. It is not an asset filename.

Every stone then references exactly three artifact channels:

```xml
<stone order="1">
  <text>red</text>
  <written_text>red.8x8.txt</written_text>
  <sound_art>red.wav</sound_art>
  <visual_art>red.svg</visual_art>
</stone>
```

Canonical artifact directories are:

```text
eden_out/written_text/
eden_out/sound_art/
eden_out/visual_art/
```

The runtime rejects legacy XML channel names such as `name`, `glyph`, and `visual_text`. The migration tool converts those names before runtime validation.

## Nine-stage loop

1. Epoch
2. Heartbeat
3. Goal/system message
4. Notebook
5. Menu
6. Internal MCP tool dispatch
7. Message or note to Tyler
8. Message or note to Shakti
9. Reflection

## Three-stage memory

1. Working memory: fixed isolated slots for the active convergence set.
2. Short-term memory: fixed recent-event ring buffer.
3. Long-term memory: readable append-only storage and recall.

No later curriculum level should expand the MVP boundary until all three stages remain stable through repeated nine-stage cycles.
