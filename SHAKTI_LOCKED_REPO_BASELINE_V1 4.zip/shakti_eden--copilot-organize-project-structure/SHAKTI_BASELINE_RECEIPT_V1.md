# SHAKTI BASELINE RECEIPT V1

## Candidate build base

- Source archive: `shakti_eden--copilot-organize-project-structure 2.zip`
- Intended branch: `copilot/organize-project-structure`
- Status: **CANDIDATE BASELINE**
- GitHub `main`: **DO NOT MODIFY**
- Archive SHA-256: `35a715cfdec595f3c8eea0a73341188858543583a2096d54564703cf784fd8ee`
- Archive size: `5,654,916` bytes
- Archive entries: `613`

## Read-only inspection completed

The archive contains an unpacked C99 project with:

- `src/`
- `include/`
- `tests/`
- `tools/`
- `docs/`
- `data/`
- generated output under `eden_out/`

No code, builder, test, shell script, or executable was run.

## Known protected decisions

- Shakti remains one self-contained iOS application with a C99 runtime.
- Swift is an optional host/package boundary for Apple APIs.
- No daemon, subprocess, second core, or external process becomes part of Shakti.
- MCP is the gated reach outside Shakti's shell.
- External tools are added individually through the menu when approved.
- The 13-question reflection exists in `src/shakti_loop.c`.
- The current School implementation contains obsolete four-pass/mastery behavior and must not be accepted unchanged.
- Artifact naming, lesson schema, four-panel behavior, two-tier tokens, solo-first learning, and RAM-resident roots must be locked before source edits.
- Candidate artifacts and builders must not be executed until separately approved.

## Immediate next controlled step

Create `SHAKTI_LOCK_V1.md` and `REPO_INVENTORY_V1.md` beside this receipt without changing source code. Any unresolved rule will be marked `UNKNOWN`; it will not be guessed.
