#ifndef SHAKTI_MCP_H
#define SHAKTI_MCP_H

#include <stdio.h>

#include "shakti_types.h"

/* Section Ge is /menu/. Section Gf is /shakti_run/. */
#define MCP_SECTION_MENU "Ge"
#define MCP_SECTION_RUN  "Gf"

/* Declared capacities. Printed by /status. */
#define MCP_MENU_BYTES    65536
#define MCP_NAME_MAX         64
#define MCP_PATH_MAX        512
#define MCP_ARG_MAX          24
#define MCP_LINE_MAX       2048
#define MCP_REGISTRY_MAX     32

/* What a call ends as. Also the exit code of the shell entry. */
typedef enum {
    MCP_DONE = 0,        /* the tool ran and changed something        */
    MCP_STOPPED = 1,     /* refused, or the tool stopped              */
    MCP_NO_CHANGE = 2    /* the tool ran and changed nothing          */
} mcp_result_t;

/* Who is calling. Set by the harness at start, never by a tool. */
typedef enum {
    MCP_CALLER_SHAKTI = 0,
    MCP_CALLER_TYLER = 1
} mcp_caller_t;

/* Where the line came from. Named by the harness on the way in, so the record
   carries the door as well as the name. */
typedef enum {
    MCP_ORIGIN_HER_SHELL = 0,   /* Shakti's own shell, always open to her  */
    MCP_ORIGIN_TERMINAL = 1,    /* a terminal on this machine              */
    MCP_ORIGIN_CONTROL_APP = 2  /* shakti_control_2, html now, Swift later */
} mcp_origin_t;

/* How the sender was checked. The MCP does not perform the check. The app
   states which one it made, and that statement is what goes in the record. */
typedef enum {
    MCP_CHECK_NONE = 0,
    MCP_CHECK_SIGN_IN = 1,
    MCP_CHECK_FACE = 2
} mcp_check_t;

/* The session. One per process. The gate lives here. */
typedef struct {
    mcp_caller_t caller;
    mcp_origin_t origin;
    mcp_check_t check;                    /* what the app says it did        */
    unsigned char signed_in;              /* 1 once a check has been stated  */
    unsigned char edit_open;              /* 1 when the edit branch is open  */
    char who[MCP_NAME_MAX];               /* the name the app sent           */
    char branch[MCP_NAME_MAX];            /* the branch that was opened      */
    char menu_path[MCP_PATH_MAX];         /* the menu the MCP checks         */
    char temp_dir[MCP_PATH_MAX];          /* the MCP owns it; tools write here */
    char log_path[MCP_PATH_MAX];          /* append-only working record      */
    shakti_tick_clock_t clock;
} mcp_session_t;

/* What the menu says about one tool. */
typedef struct {
    char section[MCP_NAME_MAX];
    char id[MCP_NAME_MAX];
    char owner[MCP_NAME_MAX];   /* empty, or tyler                          */
    char class_name[MCP_NAME_MAX]; /* empty, or edit                        */
    unsigned char found;
    unsigned char enabled;
} mcp_menu_entry_t;

/* A registered tool. Both the menu and this table must carry it. */
typedef mcp_result_t (*mcp_tool_fn)(const mcp_session_t *session,
                                    int argc, char **argv, FILE *report);

typedef struct {
    const char *id;
    mcp_tool_fn run;
} mcp_registration_t;

void mcp_session_init(mcp_session_t *session, mcp_caller_t caller);

/* The app states who it is and which check it made. Recorded as stated. */
mcp_result_t mcp_sign_in(mcp_session_t *session, const char *who,
                         mcp_check_t check, FILE *report);

const char *mcp_origin_name(mcp_origin_t origin);
const char *mcp_check_name(mcp_check_t check);

/* Tyler opens the edit branch. A call from Shakti is refused and logged.
   Her shell stays open either way. */
mcp_result_t mcp_edit_open(mcp_session_t *session, const char *branch, FILE *report);
mcp_result_t mcp_edit_close(mcp_session_t *session, FILE *report);

/* Ge — what she can do. section NULL returns tier one. */
mcp_result_t mcp_menu(mcp_session_t *session, const char *section,
                      const char *tool, FILE *report);

/* Gf — the one way a tool runs. */
mcp_result_t mcp_run(mcp_session_t *session, const char *tool_id,
                     int argc, char **argv, FILE *report);

mcp_result_t mcp_status(mcp_session_t *session, FILE *report);

/* Reads one tool's line out of the menu file. */
int mcp_menu_lookup(const mcp_session_t *session, const char *tool_id,
                    mcp_menu_entry_t *entry);

#endif
