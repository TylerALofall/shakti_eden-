# Bulk Curriculum Import

The repository includes `tools/migrate_curriculum.py` for safely cleaning large legacy collections before they enter Eden.

## Contract

The migration uses `<text>` as the source-of-truth value and normalizes the referenced channels to:

- `<written_text>`
- `<sound_art>`
- `<visual_art>`

Legacy aliases are migrated as follows:

| Legacy | Canonical |
|---|---|
| `<name>` | `<text>` |
| `<glyph>` | `<written_text>` |
| `<visual_text>` | `<written_text>` |

Only the first five MVP levels are accepted: `foundation_ascii`, `counting`, `alphabet`, `colors`, and `shapes`.

## Dry run

```sh
python3 tools/migrate_curriculum.py /path/to/incoming   --output migration_out   --report migration_report.json
```

A dry run parses every tablet, checks channel counts, computes canonical filenames, finds referenced assets recursively, detects duplicates, and reports conflicts. It does not write the staging tree.

## Apply

```sh
python3 tools/migrate_curriculum.py /path/to/incoming   --output migration_out   --apply
```

The output is isolated from the source:

```text
migration_out/
├── data/eden/XML_text/
├── eden_out/written_text/
├── eden_out/sound_art/
├── eden_out/visual_art/
├── quarantine/conflicts/
└── migration_report.json
```

Identical files with the same basename are deduplicated. Different files with the same basename are never overwritten; they are reported and copied to quarantine when `--apply` is used. Duplicate XML basenames and different legacy files that resolve to the same canonical filename are handled the same way.

## Promotion sequence

1. Run the dry scan and resolve every error.
2. Apply into a new staging directory.
3. Review `migration_report.json`.
4. Generate the manifest ledger against staging.
5. Run `make test`, `./shakti --check`, and a repeated loop drill.
6. Promote only verified tablets into the repository.

Do not run a 30,000-file import directly against `eden_out/`.
