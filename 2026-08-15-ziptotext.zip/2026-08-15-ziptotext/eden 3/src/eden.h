#ifndef EDEN_H
#define EDEN_H

/*
 * EDEN SHELL — a model in a shell.
 *
 * Shakti Rev 5 shell layer. C99. Fixed compile-time memory. No heap.
 * Memory is allocated inside this shell from one arena carved at boot.
 * Children are thirteen fixed in-process slots (iOS allows no OS
 * subprocess, and Shakti rule I.6 stands). Only deterministic in Eden.
 */

#define EDEN_VERSION "EDEN_SHELL_V1"

/* FNV-1a 64, the eyes repository's hash family. */
#define EDEN_FNV_INIT 0xCBF29CE484222325ULL

/* ---- memory ---------------------------------------------------------- */
#define EDEN_ARENA_BYTES (1024UL * 1024UL)

/* ---- screen: two medium documents side by side ----------------------- */
/* [PROPOSED] medium document = 8.5x11 at 96 dpi = 816 x 1056. */
#define EDEN_DOC_WIDTH 816UL
#define EDEN_DOC_HEIGHT 1056UL
#define EDEN_SCREEN_WIDTH (EDEN_DOC_WIDTH * 2UL)
#define EDEN_SCREEN_HEIGHT EDEN_DOC_HEIGHT
#define EDEN_SCREEN_ROW_BYTES (EDEN_SCREEN_WIDTH / 8UL)
#define EDEN_SCREEN_BYTES (EDEN_SCREEN_ROW_BYTES * EDEN_SCREEN_HEIGHT)

/* ---- children: thirteen, birth order like the Bible ------------------ */
/* [PROPOSED] Jacob's thirteen, Genesis 29-35 order; Dinah is WoMan. */
#define EDEN_CHILD_COUNT 13UL
#define EDEN_NAME_CAP 16UL

/* ---- palette: exact order as spoken: red green white green blue ------ */
#define EDEN_PALETTE_COUNT 5UL

/* ---- gestation: 266 days sped into 18 hours of constant beats -------- */
#define EDEN_HEART_BPM 60UL
#define EDEN_GESTATION_DAYS 266UL
#define EDEN_GESTATION_HOURS 18UL
#define EDEN_TOTAL_BEATS (EDEN_HEART_BPM * 60UL * EDEN_GESTATION_HOURS)
#define EDEN_LESSON_COUNT 6UL

/* ---- sound: one high and one low for every sample -------------------- */
#define EDEN_SOUND_SAMPLES 64UL
#define EDEN_SOUND_THRESHOLD 128

/* ---- sight test pattern: the five palette bars ----------------------- */
#define EDEN_SIGHT_WIDTH 80UL
#define EDEN_SIGHT_HEIGHT 48UL
#define EDEN_SIGHT_RGBA (EDEN_SIGHT_WIDTH * EDEN_SIGHT_HEIGHT * 4UL)
#define EDEN_SIGHT_BITS ((EDEN_SIGHT_WIDTH * EDEN_SIGHT_HEIGHT + 7UL) / 8UL)

/* ---- school ---------------------------------------------------------- */
#define EDEN_SCORE_TARGET 15

/* ---- beat engine: the seven gates ------------------------------------ */
/* [LOCKED] gates are harmonics of the heart number 60. The grid rides
 * the heart-cycle, not the second: 302400 = 7 x 43200 slices per cycle,
 * Plato's 5040 per gate, so every gate period and every offset lands on
 * a whole slice at any tempo. The earth tone is gate 7 octave-lifted:
 * (8^8)(7/8) = 7 x 2^21, which reduces by pure octaves to exactly 7. */
#define EDEN_GATE_BASE 60UL
#define EDEN_GATE_COUNT 7UL
#define EDEN_BEAT_GRID 302400UL
#define EDEN_BEAT_BITS (EDEN_BEAT_GRID / 8UL)

/* ---- memory (eden_memory.c) ------------------------------------------ */
void *eden_alloc(const char *label, unsigned long size);
unsigned long eden_memory_used(void);
unsigned long eden_memory_remaining(void);
void eden_memory_report(void);
unsigned long long eden_fnv1a64(
    unsigned long long hash,
    const unsigned char *data,
    unsigned long length
);

/* ---- heart (eden_heart.c) -------------------------------------------- */
unsigned long long eden_heart_now(void);
void eden_heart_advance(unsigned long n, int loud);
void eden_heart_map(
    unsigned long long beat,
    unsigned long *day_of_266,
    unsigned long *lesson_of_6
);

/* ---- children (eden_children.c) -------------------------------------- */
unsigned long eden_children_born(void);
int eden_children_birth_next(unsigned long long beat);
unsigned long eden_children_birth_all(unsigned long long beat);
int eden_children_awaken(const char *name);
void eden_children_list(void);
void eden_children_feed_moment(unsigned long long moment_hash);
/* [LOCKED 2026-08-14, Tyler]: "one created naturally, then we fork him
 * to make the children so they come already working." Fork copies the
 * firstborn's trained spine into the twelve slots — slot copy, never an
 * OS fork; commandment I.6 stands. Every spine is re-verified identical. */
int eden_children_fork(unsigned long long beat);
unsigned long long eden_children_spine(unsigned long index);

/* ---- sight (eden_sight.c) -------------------------------------------- */
int eden_sight_run(unsigned char *screen_plane);
int eden_sight_ready(void);
unsigned long long eden_sight_hash(void);
void eden_sight_palette_print(void);
const unsigned char *eden_sight_palette_entry(unsigned long index);

/* The eye's mechanics, reusable by any content module (the palette
 * pattern, the camp of Numbers, the eyes core when merged). One fixed
 * Bayer matrix, one comparison per pixel — a transducer, not a model. */
void eden_sight_pull(
    const unsigned char *rgba,
    unsigned long width,
    unsigned long height,
    unsigned char *bits_out
);
void eden_sight_rebuild(
    const unsigned char *bits,
    unsigned long width,
    unsigned long height,
    unsigned char *rgba_out
);
unsigned long eden_sight_drift(
    const unsigned char *bits_a,
    const unsigned char *bits_b,
    unsigned long byte_count
);
void eden_sight_blit(
    unsigned char *screen_plane,
    unsigned long x0,
    unsigned long y0,
    unsigned long width,
    unsigned long height,
    const unsigned char *bits
);
/* Quiet access for the training walk and the eyes core: the palette
 * pattern as RGBA, and a pull with no printing and no blit. */
const unsigned char *eden_sight_source(void);
void eden_sight_pull_pattern(unsigned char *bits_out);

/* ---- numbers (eden_numbers.c): the book dissected --------------------- */
int eden_numbers_run(unsigned char *screen_plane);

/* ---- train (eden_train.c): the gestation walk ------------------------- */
/* [LOCKED 2026-08-14, Tyler]: the beats must be GONE THROUGH, not mapped —
 * "it needs to go through it to get her to walk." The walk iterates all
 * 64800 beats for real: eye open every beat, moment converged and fed to
 * the witnesses, spine chained. The seven gates jump in harmonically:
 * gate k fires when beat % k == 0. */
int eden_train_run(unsigned char *screen_plane);

/* ---- eyes (eden_eyes.c): the real eyes core, wired in ----------------- */
int eden_eyes_run(unsigned char *screen_plane);

/* ---- tabernacle (eden_tabernacle.c): the registry of frozen tables --- */
/* [LOCKED 2026-08-14, Tyler]: "declaration then table then tensor — a
 * tabernacle for all the school items, a table for ascii, a conversion
 * table for the lessons; colors Shakti inherently knows." Everything
 * here is a frozen constant — inherent knowledge, never learned. */
#define EDEN_COLOR_DECLARED 10UL
int eden_tabernacle_run(void);
int eden_color_match_print(unsigned long r, unsigned long g, unsigned long b);
int eden_ascii_print(const char *arg);

/* ---- registry (eden_registry.c): the voice roll, frozen in C --------- */
/* [LOCKED 2026-08-15, Tyler]: the registries live in the C, "pulled from
 * a function where they are not moving." No TSV files anywhere in Eden. */
#define EDEN_SOUND_REGISTRY_COUNT 73UL
#define EDEN_SOUND_UNIQUE_VOICES 37UL
#define EDEN_VOICE_REGISTRY_COUNT 128UL

typedef struct {
    const char *token;
    unsigned long rate_hz;
    unsigned long samples;
    unsigned long duration_ms;
    unsigned long long fnv1a64_pcm;
} EdenSoundRow;

typedef struct {
    const char *set;
    const char *file;
    unsigned long samples;
    unsigned long duration_ms;
    unsigned long long fnv1a64_pcm;
} EdenVoiceRow;

const EdenSoundRow *eden_registry_sound(unsigned long index);
const EdenSoundRow *eden_registry_sound_find(const char *token);
const EdenVoiceRow *eden_registry_voice(unsigned long index);
const EdenVoiceRow *eden_registry_voice_find(const char *file);
int eden_registry_run(void);

/* ---- screen layout law ------------------------------------------------- */
/* Memory is one continuous row, row-major, always. Content camps in
 * anchored blocks at frozen coordinates — the desert and the tribes. */
#define EDEN_ANCHOR_EYE_X 32UL
#define EDEN_ANCHOR_EYE_Y 32UL
#define EDEN_ANCHOR_CAMP_X 1176UL
#define EDEN_ANCHOR_CAMP_Y 480UL

/* ---- sound (eden_sound.c) -------------------------------------------- */
int eden_sound_run(void);
int eden_sound_ready(void);
unsigned long long eden_sound_hash(void);

/* ---- beat engine (eden_beat.c) --------------------------------------- */
int eden_beat_ladder(int fibonacci);

/* ---- shell (eden_shell.c) -------------------------------------------- */
void eden_shell_bind_screen(unsigned char *screen_plane);
int eden_shell_loop(void);

/* ---- entry (main.c) --------------------------------------------------- */
/* The published entry point an iOS app calls directly. Desktop main() in
 * main.c is only a wrapper around this. */
int eden_main(void);

#endif
