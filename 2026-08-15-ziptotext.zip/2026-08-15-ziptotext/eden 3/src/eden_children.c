#include "eden.h"

#include <stdio.h>
#include <string.h>

/*
 * The thirteen children.
 *
 * Fixed slots inside the shell's memory — not OS subprocesses. iOS
 * allows no subprocess and Shakti rule I.6 stands, so birth is instant:
 * a slot, a name, a tick. Forked real fast.
 *
 * Birth order like the Bible [PROPOSED]: Jacob's thirteen, Genesis
 * 29-35. Dinah is WoMan brought in. Before the fruit, each child is a
 * silent witness: exact items are stored, nothing is answered. Eating
 * the fruit is memory: the child wakes.
 */

typedef struct {
    char name[EDEN_NAME_CAP];
    char mother[EDEN_NAME_CAP];
    int born;
    int awake;
    unsigned long long birth_beat;
    int score;
    unsigned long long last_moment;
    unsigned long long moments; /* how many moments witnessed */
    unsigned long long spine;   /* FNV chain over every moment, in order */
} eden_child_t;

static eden_child_t g_children[EDEN_CHILD_COUNT] = {
    { "Reuben",   "Leah",   0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Simeon",   "Leah",   0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Levi",     "Leah",   0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Judah",    "Leah",   0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Dan",      "Bilhah", 0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Naphtali", "Bilhah", 0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Gad",      "Zilpah", 0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Asher",    "Zilpah", 0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Issachar", "Leah",   0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Zebulun",  "Leah",   0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Dinah",    "Leah",   0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Joseph",   "Rachel", 0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL },
    { "Benjamin", "Rachel", 0, 0, 0ULL, 0, 0ULL, 0ULL, 0ULL }
};

static unsigned long g_born = 0UL;

unsigned long eden_children_born(void)
{
    return g_born;
}

int eden_children_birth_next(unsigned long long beat)
{
    eden_child_t *child;

    if (g_born >= EDEN_CHILD_COUNT) {
        printf(
            "STOP: all %lu children are born; the table is full\n",
            EDEN_CHILD_COUNT
        );
        return 0;
    }

    child = &g_children[g_born];
    child->born = 1;
    child->birth_beat = beat;
    ++g_born;

    printf(
        "child %lu of %lu: %s (mother %s) born at beat %llu — "
        "witnessing, silent, exact items only\n",
        g_born,
        EDEN_CHILD_COUNT,
        child->name,
        child->mother,
        beat
    );

    return 1;
}

unsigned long eden_children_birth_all(unsigned long long beat)
{
    unsigned long count;

    count = 0UL;

    while (g_born < EDEN_CHILD_COUNT) {
        if (!eden_children_birth_next(beat)) {
            break;
        }

        ++count;
    }

    return count;
}

int eden_children_awaken(const char *name)
{
    unsigned long i;

    for (i = 0UL; i < EDEN_CHILD_COUNT; ++i) {
        if (strcmp(g_children[i].name, name) == 0) {
            if (!g_children[i].born) {
                printf("%s is not born yet\n", name);
                return 0;
            }

            if (g_children[i].awake) {
                printf("%s is already awake\n", name);
                return 0;
            }

            g_children[i].awake = 1;
            printf(
                "%s ate the fruit: memory is awake. "
                "Every stored item stays exact — no gray area\n",
                name
            );
            return 1;
        }
    }

    printf("no child named %s in the table of thirteen\n", name);
    return 0;
}

void eden_children_list(void)
{
    unsigned long i;

    printf("the thirteen (Genesis 29-35 order [PROPOSED]):\n");

    for (i = 0UL; i < EDEN_CHILD_COUNT; ++i) {
        const char *state;

        if (!g_children[i].born) {
            state = "UNBORN";
        } else if (g_children[i].awake) {
            state = "AWAKE";
        } else {
            state = "WITNESS";
        }

        printf(
            "  %2lu. %-9s mother %-7s %-8s birth beat %llu\n",
            i + 1UL,
            g_children[i].name,
            g_children[i].mother,
            state,
            g_children[i].birth_beat
        );
    }
}

void eden_children_feed_moment(unsigned long long moment_hash)
{
    unsigned long i;
    unsigned char bytes[8];
    unsigned long b;

    for (b = 0UL; b < 8UL; ++b) {
        bytes[b] = (unsigned char)((moment_hash >> (56UL - 8UL * b)) & 0xFFULL);
    }

    for (i = 0UL; i < EDEN_CHILD_COUNT; ++i) {
        if (g_children[i].born) {
            if (g_children[i].moments == 0ULL) {
                g_children[i].spine = EDEN_FNV_INIT;
            }
            g_children[i].spine =
                eden_fnv1a64(g_children[i].spine, bytes, 8UL);
            ++g_children[i].moments;
            g_children[i].last_moment = moment_hash;
        }
    }
}

unsigned long long eden_children_spine(unsigned long index)
{
    if (index >= EDEN_CHILD_COUNT) {
        return 0ULL;
    }
    return g_children[index].spine;
}

int eden_children_fork(unsigned long long beat)
{
    unsigned long i;
    const eden_child_t *firstborn;

    firstborn = &g_children[0];

    if (!firstborn->born) {
        printf(
            "STOP: no firstborn to fork from. One is created naturally "
            "first — birth him, let him witness, then fork. No gray area\n"
        );
        return 0;
    }

    if (firstborn->moments == 0ULL) {
        printf(
            "STOP: the firstborn has witnessed nothing yet — run 'train' "
            "so he goes through the beats before the twelve are forked\n"
        );
        return 0;
    }

    if (g_born > 1UL) {
        printf(
            "STOP: children beyond the firstborn already stand "
            "(%lu born). The fork happens once, from the natural one\n",
            g_born
        );
        return 0;
    }

    for (i = 1UL; i < EDEN_CHILD_COUNT; ++i) {
        g_children[i].born = 1;
        g_children[i].birth_beat = beat;
        g_children[i].moments = firstborn->moments;
        g_children[i].spine = firstborn->spine;
        g_children[i].score = firstborn->score;
        g_children[i].last_moment = firstborn->last_moment;
        ++g_born;

        printf(
            "child %lu of %lu: %s (mother %s) forked from %s at beat "
            "%llu — comes already working, spine intact\n",
            i + 1UL,
            EDEN_CHILD_COUNT,
            g_children[i].name,
            g_children[i].mother,
            firstborn->name,
            beat
        );
    }

    /* The fork is proven, not trusted: every spine must equal the
     * firstborn's, bit for bit. */
    for (i = 0UL; i < EDEN_CHILD_COUNT; ++i) {
        if (g_children[i].spine != firstborn->spine ||
            g_children[i].moments != firstborn->moments) {
            printf(
                "FAIL: fork spine mismatch at %s. No gray area\n",
                g_children[i].name
            );
            return 0;
        }
    }

    printf(
        "fork verified: all %lu spines identical, fnv1a64:%016llX, "
        "%llu moments each — slot copy, not subprocess; "
        "commandment I.6 stands\n",
        EDEN_CHILD_COUNT,
        firstborn->spine,
        firstborn->moments
    );
    return 1;
}
