#include "eden.h"
#include "eyes.h"

#include <stdio.h>

/*
 * The real eyes core, wired into Eden.
 *
 * The core was imported locked from the Shakti repo (branch Shakti-main,
 * blobs e31ff678 / 70ba289d) and compiles under Eden's full strict flag
 * set. It is a transducer with caller-supplied buffers — Eden supplies
 * them from the arena. One eye, three lenses:
 *
 *   color pull  — sees only saturated primaries (the color-printer law:
 *                 a real black mixes three colors, so no single channel
 *                 reads saturated; half-strength colors are invisible
 *                 to this lens — the palette's (0,128,0) greens are NOT
 *                 seen here, and that is disclosed, not hidden)
 *   mono pull   — luma ink/paper, lossless on flat pages; the text lens
 *   bayer pull  — Eden's shade lens (eden_sight.c), for density content
 *
 * The matching context is hard-coded frozen matrices — the clean 5x7
 * font in 8x8 cells that eyes_recognize_text matches against, the Bayer
 * matrix, the census tables. No learned weights anywhere. [LOCKED
 * 2026-08-14, Tyler: "a c tensor matrix as the matching context that
 * gets hard coded in there."]
 */

int eden_eyes_run(unsigned char *screen_plane)
{
    const unsigned char *source;
    unsigned long pixels;
    char *color_bits;
    char *mono_bits;
    unsigned char *recon_color;
    unsigned char *recon_mono;
    eyes_recog_t *recognized;
    unsigned long color_drift;
    unsigned long mono_drift;
    unsigned long recognized_count;
    unsigned long long color_hash;
    unsigned long long mono_hash;

    (void)screen_plane;

    pixels = EDEN_SIGHT_WIDTH * EDEN_SIGHT_HEIGHT;

    color_bits = eden_alloc("eyes_color_bits", pixels * 3UL + 1UL);
    mono_bits = eden_alloc("eyes_mono_bits", pixels + 1UL);
    recon_color = eden_alloc("eyes_recon_color", pixels * 4UL);
    recon_mono = eden_alloc("eyes_recon_mono", pixels * 4UL);
    recognized = eden_alloc(
        "eyes_recog", EYES_RECOG_MAX * sizeof(eyes_recog_t)
    );

    if (color_bits == NULL || mono_bits == NULL || recon_color == NULL ||
        recon_mono == NULL || recognized == NULL) {
        printf("STOP: arena cannot feed the eyes. Explicit full, no "
               "silent truncation\n");
        return 0;
    }

    source = eden_sight_source();

    /* ---- color lens --------------------------------------------------- */
    if (!eyes_pull_color(
            source, (unsigned int)EDEN_SIGHT_WIDTH,
            (unsigned int)EDEN_SIGHT_HEIGHT,
            color_bits, pixels * 3UL + 1UL)) {
        printf("STOP: color pull rejected the page\n");
        return 0;
    }
    if (!eyes_reconstruct_color(
            color_bits, (unsigned int)EDEN_SIGHT_WIDTH,
            (unsigned int)EDEN_SIGHT_HEIGHT,
            recon_color, pixels * 4UL)) {
        printf("STOP: color rebuild rejected the bits\n");
        return 0;
    }
    color_drift = eyes_diff(
        source, recon_color, (unsigned int)EDEN_SIGHT_WIDTH,
        (unsigned int)EDEN_SIGHT_HEIGHT, 1
    );
    if (color_drift == (unsigned long)-1) {
        printf("STOP: color diff rejected the pair\n");
        return 0;
    }

    /* ---- mono lens ---------------------------------------------------- */
    if (!eyes_pull_mono(
            source, (unsigned int)EDEN_SIGHT_WIDTH,
            (unsigned int)EDEN_SIGHT_HEIGHT,
            mono_bits, pixels + 1UL)) {
        printf("STOP: mono pull rejected the page\n");
        return 0;
    }
    if (!eyes_reconstruct_mono(
            mono_bits, (unsigned int)EDEN_SIGHT_WIDTH,
            (unsigned int)EDEN_SIGHT_HEIGHT,
            recon_mono, pixels * 4UL)) {
        printf("STOP: mono rebuild rejected the bits\n");
        return 0;
    }
    mono_drift = eyes_diff(
        source, recon_mono, (unsigned int)EDEN_SIGHT_WIDTH,
        (unsigned int)EDEN_SIGHT_HEIGHT, 0
    );
    if (mono_drift == (unsigned long)-1) {
        printf("STOP: mono diff rejected the pair\n");
        return 0;
    }

    recognized_count = eyes_recognize_text(
        recon_mono, (unsigned int)EDEN_SIGHT_WIDTH,
        (unsigned int)EDEN_SIGHT_HEIGHT, recognized, EYES_RECOG_MAX
    );

    color_hash = eden_fnv1a64(
        EDEN_FNV_INIT, (const unsigned char *)color_bits, pixels * 3UL
    );
    mono_hash = eden_fnv1a64(
        EDEN_FNV_INIT, (const unsigned char *)mono_bits, pixels
    );

    printf("eyes: the real core looks at the palette page, %lux%lu\n",
           EDEN_SIGHT_WIDTH, EDEN_SIGHT_HEIGHT);
    printf(
        "eyes: color lens — drift %lu of %lu. Disclosure: this lens sees "
        "only saturated primaries, so of the five bars only RED and BLUE "
        "came back (%lu pixels held); the half-strength greens (0,128,0) "
        "and the white are not primaries to this lens and rebuilt lost. "
        "They are carried by the shade and mono lenses. The palette "
        "stays locked as spoken; the blindness is the lens's law, "
        "printed aloud\n",
        color_drift, pixels, pixels - color_drift
    );
    printf(
        "eyes: mono lens — ink/paper round trip drift %lu "
        "(lossless on flat pages)\n",
        mono_drift
    );
    printf(
        "eyes: recognition against the hard-coded 5x7 font matrix: "
        "%lu characters (this page is bars, not text — the matrix "
        "guesses nothing)\n",
        recognized_count
    );
    printf("eyes: color pull hash=fnv1a64:%016llX\n", color_hash);
    printf("eyes: mono pull  hash=fnv1a64:%016llX\n", mono_hash);

    if (mono_drift != 0UL) {
        printf("FAIL: the mono lens drifted on a flat page\n");
        return 0;
    }

    printf("eyes: PASS — the imported core sees inside Eden, buffers "
           "from the arena, drift disclosed lens by lens\n");
    return 1;
}
