#include "eden.h"

#include <stdio.h>

/*
 * Bayer binary sight.
 *
 * The picture image goes to binary through a 4x4 Bayer ordered-dither
 * pull, gets rebuilt, and passes a pixel check on every image: pulling
 * the rebuild returns the identical bits, drift 0, hashed FNV-1a 64.
 * The rebuild is moved onto the set screen — two medium documents side
 * by side — into the left page. The test pattern is the palette itself:
 * five bars, red green white green blue, exact order as spoken.
 *
 * This mirrors the discipline of the eyes core (mono pull -> exact
 * reconstruct, drift 0 through the chain). [MERGE REQUIRED] swap in the
 * real eyes.h / eyes.c core when Tyler merges the project.
 */

static const unsigned char BAYER4[4][4] = {
    { 0U, 8U, 2U, 10U },
    { 12U, 4U, 14U, 6U },
    { 3U, 11U, 1U, 9U },
    { 15U, 7U, 13U, 5U }
};

/* Palette, exact order: red, green, white, green, blue. Green twice. */
static const unsigned char PALETTE[EDEN_PALETTE_COUNT][3] = {
    { 255U, 0U, 0U },
    { 0U, 128U, 0U },
    { 255U, 255U, 255U },
    { 0U, 128U, 0U },
    { 0U, 0U, 255U }
};

static const char * const PALETTE_NAMES[EDEN_PALETTE_COUNT] = {
    "RED", "GREEN", "WHITE", "GREEN", "BLUE"
};

static unsigned char g_source[EDEN_SIGHT_RGBA];
static unsigned char g_bits[EDEN_SIGHT_BITS];
static unsigned char g_rebuilt[EDEN_SIGHT_RGBA];
static unsigned char g_bits_again[EDEN_SIGHT_BITS];
static int g_ready = 0;
static unsigned long long g_hash = 0ULL;

static void sight_build_pattern(void);

int eden_sight_ready(void)
{
    return g_ready;
}

unsigned long long eden_sight_hash(void)
{
    return g_hash;
}

const unsigned char *eden_sight_palette_entry(unsigned long index)
{
    if (index >= EDEN_PALETTE_COUNT) {
        index = EDEN_PALETTE_COUNT - 1UL;
    }
    return PALETTE[index];
}

const unsigned char *eden_sight_source(void)
{
    sight_build_pattern();
    return g_source;
}

void eden_sight_pull_pattern(unsigned char *bits_out)
{
    sight_build_pattern();
    eden_sight_pull(g_source, EDEN_SIGHT_WIDTH, EDEN_SIGHT_HEIGHT, bits_out);
}

void eden_sight_palette_print(void)
{
    unsigned long i;

    printf("palette, exact order as spoken:\n");

    for (i = 0UL; i < EDEN_PALETTE_COUNT; ++i) {
        printf(
            "  %lu. %-5s (%u,%u,%u)\n",
            i + 1UL,
            PALETTE_NAMES[i],
            (unsigned int)PALETTE[i][0],
            (unsigned int)PALETTE[i][1],
            (unsigned int)PALETTE[i][2]
        );
    }

    printf("note: GREEN appears twice, positions 2 and 4. "
           "Preserved exactly. DUSK and DAWN remain [OPEN].\n");
}

static unsigned int sight_luma(const unsigned char *pixel)
{
    return (unsigned int)(
        (299UL * (unsigned long)pixel[0] +
         587UL * (unsigned long)pixel[1] +
         114UL * (unsigned long)pixel[2]) / 1000UL
    );
}

static void sight_build_pattern(void)
{
    unsigned long x;
    unsigned long y;
    unsigned long bar_width;

    bar_width = EDEN_SIGHT_WIDTH / EDEN_PALETTE_COUNT;

    for (y = 0UL; y < EDEN_SIGHT_HEIGHT; ++y) {
        for (x = 0UL; x < EDEN_SIGHT_WIDTH; ++x) {
            unsigned long bar;
            unsigned char *pixel;

            bar = x / bar_width;

            if (bar >= EDEN_PALETTE_COUNT) {
                bar = EDEN_PALETTE_COUNT - 1UL;
            }

            pixel = g_source + (y * EDEN_SIGHT_WIDTH + x) * 4UL;
            pixel[0] = PALETTE[bar][0];
            pixel[1] = PALETTE[bar][1];
            pixel[2] = PALETTE[bar][2];
            pixel[3] = 255U;
        }
    }
}

/* ---- the eye's mechanics, exported ----------------------------------- */
/* The eye is a transducer, not a model: one fixed 16-integer Bayer
 * matrix, one comparison per pixel. Any content module (the palette
 * pattern, the camp of Numbers, the real eyes core when merged) feeds
 * RGBA through these same four functions. No weights, no learning. */

void eden_sight_pull(
    const unsigned char *rgba,
    unsigned long width,
    unsigned long height,
    unsigned char *bits_out
)
{
    unsigned long x;
    unsigned long y;
    unsigned long i;
    unsigned long byte_count;

    byte_count = (width * height + 7UL) / 8UL;

    for (i = 0UL; i < byte_count; ++i) {
        bits_out[i] = 0U;
    }

    for (y = 0UL; y < height; ++y) {
        for (x = 0UL; x < width; ++x) {
            unsigned long position;
            unsigned int luma;
            unsigned int threshold;

            position = y * width + x;
            luma = sight_luma(rgba + position * 4UL);
            threshold =
                (unsigned int)BAYER4[y & 3UL][x & 3UL] * 16U + 8U;

            if (luma > threshold) {
                bits_out[position / 8UL] |=
                    (unsigned char)(0x80U >> (position % 8UL));
            }
        }
    }
}

void eden_sight_rebuild(
    const unsigned char *bits,
    unsigned long width,
    unsigned long height,
    unsigned char *rgba_out
)
{
    unsigned long x;
    unsigned long y;

    for (y = 0UL; y < height; ++y) {
        for (x = 0UL; x < width; ++x) {
            unsigned long position;
            unsigned int bit;
            unsigned char *pixel;
            unsigned char value;

            position = y * width + x;
            bit = (unsigned int)(
                (bits[position / 8UL] >> (7UL - (position % 8UL))) & 1U
            );
            value = bit != 0U ? 255U : 0U;

            pixel = rgba_out + position * 4UL;
            pixel[0] = value;
            pixel[1] = value;
            pixel[2] = value;
            pixel[3] = 255U;
        }
    }
}

unsigned long eden_sight_drift(
    const unsigned char *bits_a,
    const unsigned char *bits_b,
    unsigned long byte_count
)
{
    unsigned long i;
    unsigned long drift;

    drift = 0UL;

    for (i = 0UL; i < byte_count; ++i) {
        unsigned char differing;

        differing = (unsigned char)(bits_a[i] ^ bits_b[i]);

        while (differing != 0U) {
            drift += (unsigned long)(differing & 1U);
            differing = (unsigned char)(differing >> 1);
        }
    }

    return drift;
}

void eden_sight_blit(
    unsigned char *screen_plane,
    unsigned long x0,
    unsigned long y0,
    unsigned long width,
    unsigned long height,
    const unsigned char *bits
)
{
    unsigned long x;
    unsigned long y;

    for (y = 0UL; y < height; ++y) {
        for (x = 0UL; x < width; ++x) {
            unsigned long position;
            unsigned int bit;

            position = y * width + x;
            bit = (unsigned int)(
                (bits[position / 8UL] >> (7UL - (position % 8UL))) & 1U
            );

            if (bit != 0U) {
                unsigned long sx;
                unsigned long sy;

                sx = x0 + x;
                sy = y0 + y;

                if (sx < EDEN_SCREEN_WIDTH && sy < EDEN_SCREEN_HEIGHT) {
                    screen_plane[sy * EDEN_SCREEN_ROW_BYTES + sx / 8UL] |=
                        (unsigned char)(0x80U >> (sx % 8UL));
                }
            }
        }
    }
}

int eden_sight_run(unsigned char *screen_plane)
{
    unsigned long drift;

    if (screen_plane == NULL) {
        printf("STOP: no screen plane bound\n");
        return 0;
    }

    sight_build_pattern();
    eden_sight_pull(g_source, EDEN_SIGHT_WIDTH, EDEN_SIGHT_HEIGHT, g_bits);
    eden_sight_rebuild(g_bits, EDEN_SIGHT_WIDTH, EDEN_SIGHT_HEIGHT, g_rebuilt);
    eden_sight_pull(g_rebuilt, EDEN_SIGHT_WIDTH, EDEN_SIGHT_HEIGHT, g_bits_again);

    drift = eden_sight_drift(g_bits, g_bits_again, EDEN_SIGHT_BITS);

    g_hash = eden_fnv1a64(EDEN_FNV_INIT, g_bits, EDEN_SIGHT_BITS);

    /* Move the rebuild onto the set screen, left page, at the eye's
     * anchor in the layout law. */
    eden_sight_blit(
        screen_plane, EDEN_ANCHOR_EYE_X, EDEN_ANCHOR_EYE_Y,
        EDEN_SIGHT_WIDTH, EDEN_SIGHT_HEIGHT, g_bits
    );

    printf(
        "sight: pattern five bars red green white green blue, "
        "%lux%lu rgba\n",
        EDEN_SIGHT_WIDTH,
        EDEN_SIGHT_HEIGHT
    );
    printf(
        "sight: bayer 4x4 ordered pull, %lu pixels to %lu bits; "
        "rebuild pixel check drift=%lu\n",
        EDEN_SIGHT_WIDTH * EDEN_SIGHT_HEIGHT,
        EDEN_SIGHT_WIDTH * EDEN_SIGHT_HEIGHT,
        drift
    );
    printf(
        "sight: moved onto set screen %lux%lu, left page at (32,32)\n",
        EDEN_SCREEN_WIDTH,
        EDEN_SCREEN_HEIGHT
    );
    printf("sight: hash=fnv1a64:%016llX\n", g_hash);

    if (drift != 0UL) {
        printf("FAIL: bayer rebuild drifted\n");
        return 0;
    }

    g_ready = 1;
    printf("sight: PASS exact binary rebuild\n");
    return 1;
}
