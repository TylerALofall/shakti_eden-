/*
 * EDEN REGISTRY — the voice roll, frozen in C.
 *
 * [LOCKED 2026-08-15, Tyler]: no TSV registries in this project —
 * "they would be better installed in the C directly and then pulled
 * from a function where they are not moving." Loose tabular files get
 * swept into sync loops and corrupted; compiled constants do not move.
 * Both media TSV files were deleted after this table was verified
 * against them row for row. This file IS the registry now.
 *
 * Sound law recorded here: sound has no case. 73 tokens, 37 unique
 * voices — 0 pairs with zero, A pairs with a. The duplicates are
 * lawful; every spelling resolves to its voice.
 */

#include <stdio.h>
#include <string.h>

#include "eden.h"

/* 73 tokens, 37 unique voices. media/sound_art/, mono 16 kHz 16-bit PCM. */
static const EdenSoundRow SOUND_REGISTRY[EDEN_SOUND_REGISTRY_COUNT] = {
    { "0", 16000UL, 57941UL, 3621UL, 0xE862B616193A6442ULL },
    { "1", 16000UL, 18560UL, 1160UL, 0x940494404BF97BFCULL },
    { "2", 16000UL, 16640UL, 1040UL, 0xAD9FC4B32610298FULL },
    { "3", 16000UL, 17280UL, 1080UL, 0x3C1F6E252AFD4E33ULL },
    { "4", 16000UL, 16320UL, 1020UL, 0xBBE18A6FDB30DDFCULL },
    { "5", 16000UL, 16320UL, 1020UL, 0xD9614229A4E26A95ULL },
    { "6", 16000UL, 13760UL, 860UL, 0x8A75CDC0B67C85F0ULL },
    { "7", 16000UL, 16000UL, 1000UL, 0xD7AD265BFAC72589ULL },
    { "8", 16000UL, 15360UL, 960UL, 0x48C34BBF57CAE41FULL },
    { "9", 16000UL, 18560UL, 1160UL, 0x65F11A3A281C1CE9ULL },
    { "zero", 16000UL, 57941UL, 3621UL, 0xE862B616193A6442ULL },
    { "one", 16000UL, 18560UL, 1160UL, 0x940494404BF97BFCULL },
    { "two", 16000UL, 16640UL, 1040UL, 0xAD9FC4B32610298FULL },
    { "three", 16000UL, 17280UL, 1080UL, 0x3C1F6E252AFD4E33ULL },
    { "four", 16000UL, 16320UL, 1020UL, 0xBBE18A6FDB30DDFCULL },
    { "five", 16000UL, 16320UL, 1020UL, 0xD9614229A4E26A95ULL },
    { "six", 16000UL, 13760UL, 860UL, 0x8A75CDC0B67C85F0ULL },
    { "seven", 16000UL, 16000UL, 1000UL, 0xD7AD265BFAC72589ULL },
    { "eight", 16000UL, 15360UL, 960UL, 0x48C34BBF57CAE41FULL },
    { "nine", 16000UL, 18560UL, 1160UL, 0x65F11A3A281C1CE9ULL },
    { "ten", 16000UL, 16640UL, 1040UL, 0x1617E3F20968CAB4ULL },
    { "A", 16000UL, 17600UL, 1100UL, 0x431DEA4F1577CF56ULL },
    { "B", 16000UL, 16960UL, 1060UL, 0x306C03F1BF742327ULL },
    { "C", 16000UL, 16960UL, 1060UL, 0xFCC8822F9A093151ULL },
    { "D", 16000UL, 16960UL, 1060UL, 0x30EDF2E3C5A83211ULL },
    { "E", 16000UL, 17280UL, 1080UL, 0x4141115BF7691168ULL },
    { "F", 16000UL, 15040UL, 940UL, 0x80654F9B61214E76ULL },
    { "G", 16000UL, 19520UL, 1220UL, 0xEBC739CDFE05DA52ULL },
    { "H", 16000UL, 18880UL, 1180UL, 0xBE5875E9F83BFC0FULL },
    { "I", 16000UL, 19520UL, 1220UL, 0x8AECB81D2B587C6CULL },
    { "J", 16000UL, 18240UL, 1140UL, 0x15FC6C6A48BCA620ULL },
    { "K", 16000UL, 18560UL, 1160UL, 0x0F622BD5F4FD31B6ULL },
    { "L", 16000UL, 17920UL, 1120UL, 0xF107FB5C1060A147ULL },
    { "M", 16000UL, 16960UL, 1060UL, 0x00A0FAD73E8CCD13ULL },
    { "N", 16000UL, 18880UL, 1180UL, 0x41E5B0CB357490E4ULL },
    { "O", 16000UL, 17920UL, 1120UL, 0x31F4E8C08F0DC8CBULL },
    { "P", 16000UL, 17920UL, 1120UL, 0x7696612A1F0FD336ULL },
    { "Q", 16000UL, 19200UL, 1200UL, 0x1BF98F9AA07CD26FULL },
    { "R", 16000UL, 18560UL, 1160UL, 0xA7846F02E050CCF5ULL },
    { "S", 16000UL, 15680UL, 980UL, 0x5AF794CA0F669154ULL },
    { "T", 16000UL, 18240UL, 1140UL, 0xBD9975137BC56A29ULL },
    { "U", 16000UL, 18560UL, 1160UL, 0xD20B50E4A56D8DDBULL },
    { "V", 16000UL, 18880UL, 1180UL, 0x52EDC8BA21EF5A4CULL },
    { "W", 16000UL, 21120UL, 1320UL, 0x150425A9CD1340AAULL },
    { "X", 16000UL, 15360UL, 960UL, 0x2A5A2CDC014DEFDAULL },
    { "Y", 16000UL, 19520UL, 1220UL, 0xDEF3183C34FD6CF8ULL },
    { "Z", 16000UL, 18539UL, 1159UL, 0xC83B919D61239069ULL },
    { "a", 16000UL, 17600UL, 1100UL, 0x431DEA4F1577CF56ULL },
    { "b", 16000UL, 16960UL, 1060UL, 0x306C03F1BF742327ULL },
    { "c", 16000UL, 16960UL, 1060UL, 0xFCC8822F9A093151ULL },
    { "d", 16000UL, 16960UL, 1060UL, 0x30EDF2E3C5A83211ULL },
    { "e", 16000UL, 17280UL, 1080UL, 0x4141115BF7691168ULL },
    { "f", 16000UL, 15040UL, 940UL, 0x80654F9B61214E76ULL },
    { "g", 16000UL, 19520UL, 1220UL, 0xEBC739CDFE05DA52ULL },
    { "h", 16000UL, 18880UL, 1180UL, 0xBE5875E9F83BFC0FULL },
    { "i", 16000UL, 19520UL, 1220UL, 0x8AECB81D2B587C6CULL },
    { "j", 16000UL, 18240UL, 1140UL, 0x15FC6C6A48BCA620ULL },
    { "k", 16000UL, 18560UL, 1160UL, 0x0F622BD5F4FD31B6ULL },
    { "l", 16000UL, 17920UL, 1120UL, 0xF107FB5C1060A147ULL },
    { "m", 16000UL, 16960UL, 1060UL, 0x00A0FAD73E8CCD13ULL },
    { "n", 16000UL, 18880UL, 1180UL, 0x41E5B0CB357490E4ULL },
    { "o", 16000UL, 17920UL, 1120UL, 0x31F4E8C08F0DC8CBULL },
    { "p", 16000UL, 17920UL, 1120UL, 0x7696612A1F0FD336ULL },
    { "q", 16000UL, 19200UL, 1200UL, 0x1BF98F9AA07CD26FULL },
    { "r", 16000UL, 18560UL, 1160UL, 0xA7846F02E050CCF5ULL },
    { "s", 16000UL, 15680UL, 980UL, 0x5AF794CA0F669154ULL },
    { "t", 16000UL, 18240UL, 1140UL, 0xBD9975137BC56A29ULL },
    { "u", 16000UL, 18560UL, 1160UL, 0xD20B50E4A56D8DDBULL },
    { "v", 16000UL, 18880UL, 1180UL, 0x52EDC8BA21EF5A4CULL },
    { "w", 16000UL, 21120UL, 1320UL, 0x150425A9CD1340AAULL },
    { "x", 16000UL, 15360UL, 960UL, 0x2A5A2CDC014DEFDAULL },
    { "y", 16000UL, 19520UL, 1220UL, 0xDEF3183C34FD6CF8ULL },
    { "z", 16000UL, 18539UL, 1159UL, 0xC83B919D61239069ULL },
};

/* 128 voice artifacts, every hash distinct. founder/ is Tyler's voice
 * atoms (a-z, 1-21, 30-90, 100, 1000, 10^6, 10^9, the greeting);
 * voice69/ the school artifacts (counting words, ABCs, operators,
 * colors, balls, hurray). */
static const EdenVoiceRow VOICE_REGISTRY[EDEN_VOICE_REGISTRY_COUNT] = {
    { "founder", "01_a.wav", 40960UL, 2560UL, 0x9E6CE1A339D3A1E2ULL },
    { "founder", "02_b.wav", 24576UL, 1536UL, 0xA97253D7D643B812ULL },
    { "founder", "03_c.wav", 26624UL, 1664UL, 0xC2B917114D4DB453ULL },
    { "founder", "04_d.wav", 28672UL, 1792UL, 0xCE2C05876B7E6ACDULL },
    { "founder", "05_e.wav", 26624UL, 1664UL, 0x1E149218CCD21D46ULL },
    { "founder", "06_f.wav", 28672UL, 1792UL, 0x2319365DCB725992ULL },
    { "founder", "07_g.wav", 24576UL, 1536UL, 0xCE073314ABADC462ULL },
    { "founder", "08_h.wav", 28672UL, 1792UL, 0x3102D7B8E8817A70ULL },
    { "founder", "09_i.wav", 26624UL, 1664UL, 0xAA3D009A12B34798ULL },
    { "founder", "10_j.wav", 28672UL, 1792UL, 0x1E3545477421D3CDULL },
    { "founder", "11_k.wav", 30720UL, 1920UL, 0x9CF251D2DCE21763ULL },
    { "founder", "12_l.wav", 28672UL, 1792UL, 0x5636E52E2BFB7A0FULL },
    { "founder", "13_m.wav", 28672UL, 1792UL, 0x923231151FFBFFD6ULL },
    { "founder", "14_n.wav", 28672UL, 1792UL, 0xBC29BF3B0BE3FC8DULL },
    { "founder", "15_o.wav", 26624UL, 1664UL, 0xBE64DAF45BB1352FULL },
    { "founder", "16_p.wav", 26624UL, 1664UL, 0x4B378CE7C85C646FULL },
    { "founder", "17_q.wav", 26624UL, 1664UL, 0x17B0A5BF8F6A451AULL },
    { "founder", "18_r.wav", 26624UL, 1664UL, 0xAF6A66A86E84A535ULL },
    { "founder", "19_s.wav", 26624UL, 1664UL, 0x1A377963966484CEULL },
    { "founder", "20_t.wav", 26624UL, 1664UL, 0x55715BC5DE8844C4ULL },
    { "founder", "21_u.wav", 24576UL, 1536UL, 0x8BD292E2AFA70561ULL },
    { "founder", "22_v.wav", 26624UL, 1664UL, 0x408543B166E0170EULL },
    { "founder", "23_w.wav", 26624UL, 1664UL, 0x262E8A2491B7236EULL },
    { "founder", "24_x.wav", 24576UL, 1536UL, 0xB18EF4930117567FULL },
    { "founder", "25_y.wav", 34816UL, 2176UL, 0x2FB7BAF84F37F241ULL },
    { "founder", "26_z.wav", 47104UL, 2944UL, 0x9651E4C55FAEA0A0ULL },
    { "founder", "27_1.wav", 43008UL, 2688UL, 0x0B99A85F2AE94436ULL },
    { "founder", "28_2.wav", 24576UL, 1536UL, 0x5C187FFD7C89C060ULL },
    { "founder", "29_3.wav", 26624UL, 1664UL, 0xE61101DB5B901F07ULL },
    { "founder", "30_4.wav", 28672UL, 1792UL, 0xE40D883C86E5138DULL },
    { "founder", "31_5.wav", 26624UL, 1664UL, 0x5894522354C577A1ULL },
    { "founder", "32_6.wav", 30720UL, 1920UL, 0x57838DE7C9FDBDCFULL },
    { "founder", "33_7.wav", 26624UL, 1664UL, 0x016AC99B26E791A3ULL },
    { "founder", "34_8.wav", 26624UL, 1664UL, 0x65666F5C666CF682ULL },
    { "founder", "35_9.wav", 28672UL, 1792UL, 0xD6C14CCB9D346F8DULL },
    { "founder", "36_10.wav", 28672UL, 1792UL, 0xA9ED1FFDE1020FCFULL },
    { "founder", "37_11.wav", 30720UL, 1920UL, 0x86ACAAF8149BF41FULL },
    { "founder", "38_12.wav", 28672UL, 1792UL, 0xA9336B6DB2633E21ULL },
    { "founder", "39_13.wav", 28672UL, 1792UL, 0x447D50035CF092F5ULL },
    { "founder", "40_14.wav", 26624UL, 1664UL, 0x6B20F03F59911E87ULL },
    { "founder", "41_15.wav", 28672UL, 1792UL, 0x781C5DA9F14CD089ULL },
    { "founder", "42_16.wav", 28672UL, 1792UL, 0xBA739129400CA591ULL },
    { "founder", "43_17.wav", 30720UL, 1920UL, 0x5C1EC4D7BFB7CE79ULL },
    { "founder", "44_18.wav", 24576UL, 1536UL, 0x7F74312C18EE3032ULL },
    { "founder", "45_19.wav", 28672UL, 1792UL, 0xAA7BD0C7C258AA4EULL },
    { "founder", "46_20.wav", 26624UL, 1664UL, 0x2CCAD0A68B85F0F6ULL },
    { "founder", "47_21.wav", 49152UL, 3072UL, 0x4120AA31C74B7291ULL },
    { "founder", "48_30.wav", 49152UL, 3072UL, 0x3026B98E350FF42BULL },
    { "founder", "49_40.wav", 40960UL, 2560UL, 0xA28B53036802D2C4ULL },
    { "founder", "50_50.wav", 38912UL, 2432UL, 0xDCAEBB64423F4921ULL },
    { "founder", "51_60.wav", 38912UL, 2432UL, 0x48B9B1F24DDEB3F7ULL },
    { "founder", "52_70.wav", 36864UL, 2304UL, 0x485391C07D88E32BULL },
    { "founder", "53_80.wav", 32768UL, 2048UL, 0xF3A84A7F9684872CULL },
    { "founder", "54_90.wav", 38912UL, 2432UL, 0x6DCFA0FF4F7AB0D8ULL },
    { "founder", "55_100.wav", 67584UL, 4224UL, 0xEDA5695DAADC1C33ULL },
    { "founder", "56_1000.wav", 69632UL, 4352UL, 0xF3128C2501323C0CULL },
    { "founder", "57_1000000.wav", 73728UL, 4608UL, 0x2FA3251DA998D4FBULL },
    { "founder", "58_1000000000.wav", 96256UL, 6016UL, 0x12F60D57B7D907DAULL },
    { "founder", "59_greeting_shakti_welcome_to_eden.wav", 254955UL, 15935UL, 0x59F845CA8E30BE4AULL },
    { "voice69", "balls.wav", 10304UL, 644UL, 0x2D0F57FFE764B5D1ULL },
    { "voice69", "blue.wav", 10880UL, 680UL, 0x264B3505C2D0BB99ULL },
    { "voice69", "brown.wav", 11520UL, 720UL, 0x8C7CAEEF00D58587ULL },
    { "voice69", "divide.wav", 14720UL, 920UL, 0x861681D95693CCE2ULL },
    { "voice69", "equals.wav", 11840UL, 740UL, 0x9889F7B5DECD678CULL },
    { "voice69", "green.wav", 10880UL, 680UL, 0x684B05C283302666ULL },
    { "voice69", "hurray.wav", 18880UL, 1180UL, 0x15F3DD343F3F1FB7ULL },
    { "voice69", "lvl1_counting_and.wav", 10880UL, 680UL, 0xA44CD5BB2ED92561ULL },
    { "voice69", "lvl1_counting_eight.wav", 8960UL, 560UL, 0xFA73DEF64280541FULL },
    { "voice69", "lvl1_counting_eighteen.wav", 13120UL, 820UL, 0xEBD954F3CDC10390ULL },
    { "voice69", "lvl1_counting_eighty.wav", 12480UL, 780UL, 0x201072F2D78094C2ULL },
    { "voice69", "lvl1_counting_eleven.wav", 12160UL, 760UL, 0x080C032AC18D2BBCULL },
    { "voice69", "lvl1_counting_fifteen.wav", 11520UL, 720UL, 0xF408C02D465BFF41ULL },
    { "voice69", "lvl1_counting_fifty.wav", 15680UL, 980UL, 0xAADA03C10285BA0AULL },
    { "voice69", "lvl1_counting_five.wav", 9920UL, 620UL, 0x9D32C8D60683C295ULL },
    { "voice69", "lvl1_counting_forty.wav", 11520UL, 720UL, 0xA03D5D91DFCCF3D4ULL },
    { "voice69", "lvl1_counting_four.wav", 9920UL, 620UL, 0x90707A3B4116F9FCULL },
    { "voice69", "lvl1_counting_fourteen.wav", 12160UL, 760UL, 0x71F1DE658E4879F2ULL },
    { "voice69", "lvl1_counting_hundred.wav", 10880UL, 680UL, 0xD08D970934ACB33FULL },
    { "voice69", "lvl1_counting_nine.wav", 12160UL, 760UL, 0x863BE96D0708A4E9ULL },
    { "voice69", "lvl1_counting_nineteen.wav", 14080UL, 880UL, 0xF8E81E16FDA68831ULL },
    { "voice69", "lvl1_counting_ninety.wav", 12800UL, 800UL, 0x518D75E768BA0EDCULL },
    { "voice69", "lvl1_counting_one.wav", 12160UL, 760UL, 0xE61AE621B66F97FCULL },
    { "voice69", "lvl1_counting_seven.wav", 9600UL, 600UL, 0xDC28A7BE2DF52D89ULL },
    { "voice69", "lvl1_counting_seventeen.wav", 12800UL, 800UL, 0x87368139CF3E9417ULL },
    { "voice69", "lvl1_counting_seventy.wav", 12160UL, 760UL, 0x0E446E25E1F0E582ULL },
    { "voice69", "lvl1_counting_six.wav", 7360UL, 460UL, 0x890096620C1351F0ULL },
    { "voice69", "lvl1_counting_sixteen.wav", 12160UL, 760UL, 0x25BA7502FACC6E24ULL },
    { "voice69", "lvl1_counting_sixty.wav", 11200UL, 700UL, 0xC1F1088104C575D6ULL },
    { "voice69", "lvl1_counting_ten.wav", 10240UL, 640UL, 0xE4AE2CC3BB9706B4ULL },
    { "voice69", "lvl1_counting_thirteen.wav", 11840UL, 740UL, 0x6D3BD1FB00AFC9DCULL },
    { "voice69", "lvl1_counting_thirty.wav", 10880UL, 680UL, 0x34686F778AE9315EULL },
    { "voice69", "lvl1_counting_three.wav", 10880UL, 680UL, 0x757CFC4197FEEE33ULL },
    { "voice69", "lvl1_counting_twelve.wav", 9920UL, 620UL, 0x95DA43EE66C5C475ULL },
    { "voice69", "lvl1_counting_twenty.wav", 9600UL, 600UL, 0x07562B46AF7DDF32ULL },
    { "voice69", "lvl1_counting_two.wav", 10240UL, 640UL, 0x1EF5E5C75615D98FULL },
    { "voice69", "lvl2_ABCs_a.wav", 11200UL, 700UL, 0x9A60E3C1BA1CC356ULL },
    { "voice69", "lvl2_ABCs_b.wav", 10560UL, 660UL, 0x1A449E5D41DA7327ULL },
    { "voice69", "lvl2_ABCs_c.wav", 10560UL, 660UL, 0x4DDE1D63B13D1951ULL },
    { "voice69", "lvl2_ABCs_d.wav", 10560UL, 660UL, 0x577F4C02AFD11A11ULL },
    { "voice69", "lvl2_ABCs_e.wav", 10880UL, 680UL, 0xAA8DB9061F34FD68ULL },
    { "voice69", "lvl2_ABCs_f.wav", 8640UL, 540UL, 0xE396B72A1D3DC276ULL },
    { "voice69", "lvl2_ABCs_g.wav", 13120UL, 820UL, 0xAE87890E5B345E52ULL },
    { "voice69", "lvl2_ABCs_h.wav", 12480UL, 780UL, 0x484B26E0A7CFAC0FULL },
    { "voice69", "lvl2_ABCs_i.wav", 13120UL, 820UL, 0x1DDE5963279AD86CULL },
    { "voice69", "lvl2_ABCs_j.wav", 11840UL, 740UL, 0x5CC3F5891E20B220ULL },
    { "voice69", "lvl2_ABCs_k.wav", 12160UL, 760UL, 0xBD4FE479C73CA5B6ULL },
    { "voice69", "lvl2_ABCs_l.wav", 11520UL, 720UL, 0xF59E356EEDCA7147ULL },
    { "voice69", "lvl2_ABCs_m.wav", 10560UL, 660UL, 0xA0E6AC058BA6ED13ULL },
    { "voice69", "lvl2_ABCs_n.wav", 12480UL, 780UL, 0x6D0FB15754500CE4ULL },
    { "voice69", "lvl2_ABCs_o.wav", 11520UL, 720UL, 0xAE77FB59168408CBULL },
    { "voice69", "lvl2_ABCs_p.wav", 11520UL, 720UL, 0xD5F7E2BBC1C94736ULL },
    { "voice69", "lvl2_ABCs_q.wav", 12800UL, 800UL, 0x6C7ACE39696B026FULL },
    { "voice69", "lvl2_ABCs_r.wav", 12160UL, 760UL, 0x9A5D9725B96CA4F5ULL },
    { "voice69", "lvl2_ABCs_s.wav", 9280UL, 580UL, 0x5F8D62BFCEF64D54ULL },
    { "voice69", "lvl2_ABCs_t.wav", 11840UL, 740UL, 0x01241C9D0FCCF229ULL },
    { "voice69", "lvl2_ABCs_u.wav", 12160UL, 760UL, 0x1AD425E6B9C98DDBULL },
    { "voice69", "lvl2_ABCs_v.wav", 12480UL, 780UL, 0x967C49B2E2B6364CULL },
    { "voice69", "lvl2_ABCs_w.wav", 14720UL, 920UL, 0x70F249AC8F4764AAULL },
    { "voice69", "lvl2_ABCs_x.wav", 8960UL, 560UL, 0x40A19287857353DAULL },
    { "voice69", "lvl2_ABCs_y.wav", 13120UL, 820UL, 0xFEE73664B1BD18F8ULL },
    { "voice69", "lvl2_ABCs_z.wav", 12139UL, 759UL, 0x55D47FE99797B869ULL },
    { "voice69", "minus.wav", 10880UL, 680UL, 0x1CDED1231E33DBDCULL },
    { "voice69", "orange.wav", 10560UL, 660UL, 0x6925E2C688FACE58ULL },
    { "voice69", "plus.wav", 9600UL, 600UL, 0x878E644D0ED773FBULL },
    { "voice69", "purple.wav", 10880UL, 680UL, 0xD41FDB5009BE379BULL },
    { "voice69", "red.wav", 10560UL, 660UL, 0x0C968408632E5AC5ULL },
    { "voice69", "times.wav", 10560UL, 660UL, 0x24886A23A451609BULL },
    { "voice69", "yellow.wav", 11520UL, 720UL, 0xFFC79379E9D10C58ULL },
};

const EdenSoundRow *eden_registry_sound(unsigned long index)
{
    if (index >= EDEN_SOUND_REGISTRY_COUNT) {
        return (const EdenSoundRow *)0;
    }
    return &SOUND_REGISTRY[index];
}

const EdenSoundRow *eden_registry_sound_find(const char *token)
{
    unsigned long i;

    if (token == (const char *)0) {
        return (const EdenSoundRow *)0;
    }
    for (i = 0UL; i < EDEN_SOUND_REGISTRY_COUNT; ++i) {
        if (strcmp(SOUND_REGISTRY[i].token, token) == 0) {
            return &SOUND_REGISTRY[i];
        }
    }
    return (const EdenSoundRow *)0;
}

const EdenVoiceRow *eden_registry_voice(unsigned long index)
{
    if (index >= EDEN_VOICE_REGISTRY_COUNT) {
        return (const EdenVoiceRow *)0;
    }
    return &VOICE_REGISTRY[index];
}

const EdenVoiceRow *eden_registry_voice_find(const char *file)
{
    unsigned long i;

    if (file == (const char *)0) {
        return (const EdenVoiceRow *)0;
    }
    for (i = 0UL; i < EDEN_VOICE_REGISTRY_COUNT; ++i) {
        if (strcmp(VOICE_REGISTRY[i].file, file) == 0) {
            return &VOICE_REGISTRY[i];
        }
    }
    return (const EdenVoiceRow *)0;
}

/* The table hash layout, frozen and disclosed: sound rows first, then
 * voice rows. Sound row: token chars, rate u32BE, samples u32BE,
 * duration u32BE, pcm hash u64BE. Voice row: set chars, file chars,
 * samples u32BE, duration u32BE, pcm hash u64BE. Value bytes only —
 * struct memory is never hashed. */
static unsigned long long hash_u32be(
    unsigned long long h,
    unsigned long value,
    unsigned long *tally
)
{
    unsigned char buf[4];

    buf[0] = (unsigned char)((value >> 24UL) & 0xFFUL);
    buf[1] = (unsigned char)((value >> 16UL) & 0xFFUL);
    buf[2] = (unsigned char)((value >> 8UL) & 0xFFUL);
    buf[3] = (unsigned char)(value & 0xFFUL);
    *tally += 4UL;
    return eden_fnv1a64(h, buf, 4UL);
}

static unsigned long long hash_u64be(
    unsigned long long h,
    unsigned long long value,
    unsigned long *tally
)
{
    unsigned char buf[8];
    unsigned long b;

    for (b = 0UL; b < 8UL; ++b) {
        buf[b] = (unsigned char)((value >> (56UL - 8UL * b)) & 0xFFULL);
    }
    *tally += 8UL;
    return eden_fnv1a64(h, buf, 8UL);
}

static unsigned long long registry_hash_all(unsigned long *byte_count)
{
    unsigned long long h;
    unsigned long t;
    unsigned long i;

    h = EDEN_FNV_INIT;
    t = 0UL;

    for (i = 0UL; i < EDEN_SOUND_REGISTRY_COUNT; ++i) {
        const EdenSoundRow *r = &SOUND_REGISTRY[i];

        h = eden_fnv1a64(h, (const unsigned char *)r->token,
                         strlen(r->token));
        t += strlen(r->token);
        h = hash_u32be(h, r->rate_hz, &t);
        h = hash_u32be(h, r->samples, &t);
        h = hash_u32be(h, r->duration_ms, &t);
        h = hash_u64be(h, r->fnv1a64_pcm, &t);
    }

    for (i = 0UL; i < EDEN_VOICE_REGISTRY_COUNT; ++i) {
        const EdenVoiceRow *r = &VOICE_REGISTRY[i];

        h = eden_fnv1a64(h, (const unsigned char *)r->set,
                         strlen(r->set));
        t += strlen(r->set);
        h = eden_fnv1a64(h, (const unsigned char *)r->file,
                         strlen(r->file));
        t += strlen(r->file);
        h = hash_u32be(h, r->samples, &t);
        h = hash_u32be(h, r->duration_ms, &t);
        h = hash_u64be(h, r->fnv1a64_pcm, &t);
    }

    *byte_count = t;
    return h;
}

/* Verification: the roll call proves itself at runtime, like the
 * tabernacle. Counts, fields, the uniqueness laws, every lookup
 * resolving to its own row — then the table hash is printed so the
 * handoff ritual can pin one number. */
int eden_registry_run(void)
{
    unsigned long i;
    unsigned long j;
    unsigned long sound_unique;
    unsigned long voice_unique;
    unsigned long table_bytes;
    unsigned long long hash;
    const EdenSoundRow *sr;
    const EdenVoiceRow *vr;

    /* every row has real content */
    for (i = 0UL; i < EDEN_SOUND_REGISTRY_COUNT; ++i) {
        sr = &SOUND_REGISTRY[i];
        if (sr->token[0] == '\0' || sr->rate_hz != 16000UL ||
            sr->samples == 0UL || sr->duration_ms == 0UL ||
            sr->fnv1a64_pcm == 0ULL) {
            printf("STOP: sound registry row %lu is empty or wrong\n", i);
            return 0;
        }
    }
    for (i = 0UL; i < EDEN_VOICE_REGISTRY_COUNT; ++i) {
        vr = &VOICE_REGISTRY[i];
        if (vr->set[0] == '\0' || vr->file[0] == '\0' ||
            vr->samples == 0UL || vr->duration_ms == 0UL ||
            vr->fnv1a64_pcm == 0ULL) {
            printf("STOP: voice registry row %lu is empty\n", i);
            return 0;
        }
    }

    /* the uniqueness laws: 37 voices under 73 tokens; 128 distinct */
    sound_unique = 0UL;
    for (i = 0UL; i < EDEN_SOUND_REGISTRY_COUNT; ++i) {
        int seen;

        seen = 0;
        for (j = 0UL; j < i; ++j) {
            if (SOUND_REGISTRY[j].fnv1a64_pcm ==
                SOUND_REGISTRY[i].fnv1a64_pcm) {
                seen = 1;
            }
        }
        if (!seen) {
            ++sound_unique;
        }
    }
    if (sound_unique != EDEN_SOUND_UNIQUE_VOICES) {
        printf("STOP: sound uniqueness law broken: %lu unique, must be "
               "%lu\n", sound_unique, EDEN_SOUND_UNIQUE_VOICES);
        return 0;
    }

    voice_unique = 0UL;
    for (i = 0UL; i < EDEN_VOICE_REGISTRY_COUNT; ++i) {
        int seen;

        seen = 0;
        for (j = 0UL; j < i; ++j) {
            if (VOICE_REGISTRY[j].fnv1a64_pcm ==
                VOICE_REGISTRY[i].fnv1a64_pcm) {
                seen = 1;
            }
        }
        if (!seen) {
            ++voice_unique;
        }
    }
    if (voice_unique != EDEN_VOICE_REGISTRY_COUNT) {
        printf("STOP: voice registry has a duplicate hash at row %lu\n",
               i);
        return 0;
    }

    /* every lookup resolves to its own row — the function pulls, the
     * table never moves */
    for (i = 0UL; i < EDEN_SOUND_REGISTRY_COUNT; ++i) {
        if (eden_registry_sound_find(SOUND_REGISTRY[i].token) !=
            &SOUND_REGISTRY[i]) {
            printf("STOP: sound lookup broken at row %lu\n", i);
            return 0;
        }
    }
    for (i = 0UL; i < EDEN_VOICE_REGISTRY_COUNT; ++i) {
        if (eden_registry_voice_find(VOICE_REGISTRY[i].file) !=
            &VOICE_REGISTRY[i]) {
            printf("STOP: voice lookup broken at row %lu\n", i);
            return 0;
        }
    }

    hash = registry_hash_all(&table_bytes);

    printf(" the voice roll: %lu sound tokens, %lu unique voices "
           "(sound has no case); %lu voice artifacts, all distinct\n",
           (unsigned long)EDEN_SOUND_REGISTRY_COUNT,
           sound_unique,
           (unsigned long)EDEN_VOICE_REGISTRY_COUNT);
    printf(" the registry lives in the C: no TSV, no moving file, "
           "pulled by function only\n");
    printf(" registry: hash=fnv1a64:%016llX over %lu value bytes\n",
           hash, table_bytes);
    printf("registry: PASS — the voice roll is frozen and verified\n");

    return 1;
}
