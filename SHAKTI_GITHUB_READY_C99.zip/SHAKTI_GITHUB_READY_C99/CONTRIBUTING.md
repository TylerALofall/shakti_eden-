# Contributing

## Required checks

```sh
make clean
make test
./shakti --check
```

For memory, parser, or artifact changes, also run:

```sh
make clean
make test CC=clang   CFLAGS="-std=c99 -Wall -Wextra -Wpedantic -Werror -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer"
```

## Curriculum changes

- Keep the active manifest limited to Foundation, Counting, Alphabet, Colors, and Shapes.
- Use `<text>` only for the curriculum-list value.
- Use exactly `written_text`, `sound_art`, and `visual_art` for artifact references.
- Stage bulk imports with `tools/migrate_curriculum.py`.
- Never overwrite a conflicting artifact.
- Regenerate `data/eden/manifest_ledger.tsv`, run `./shakti --check`, and update `MANIFEST.sha256`.

## Pull requests

Keep code changes separate from large curriculum imports when practical. Include the migration report and validation totals for asset batches.
