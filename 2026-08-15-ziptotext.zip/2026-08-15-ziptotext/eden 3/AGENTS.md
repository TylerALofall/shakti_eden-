# AGENTS.md — EDEN SHELL

You are a terminal agent working inside the Eden shell project. Eden is
the Shakti Rev 5 shell layer: a deterministic C99 machine. Read
`commandments.md` and `GENESIS.md` before touching anything. They are
the law and the ledger.

## The law (summary — full text in commandments.md)

- No heap. Memory comes from one arena (`src/eden_memory.c`); full is an
  explicit STOP, never silent truncation.
- No Python, no JavaScript, no prebuilt ML, no probabilities, no floats,
  no RNG, no clock in the deterministic core.
- No OS subprocess: no `system`, `popen`, `fork`, `exec`, `spawn`.
  Children are fixed in-process slots.
- Only deterministic: same state + same input = same result, byte for
  byte, across compilers and optimization levels.
- No gray area: every stored item is exact; every approximation is
  printed aloud as a disclosed chosen integer (see the gate-8 mushroom
  attack and the camp density rule for the pattern).
- Nothing is reported passing without a real compile and a real run,
  appended to `BUILD_TEST_REPORT.txt`.

## Build (strict — warnings are errors)

```sh
cc -std=c99 -pedantic -Wall -Wextra -Werror -Ieyes -o eden src/*.c eyes/eyes.c
./eden
```

Also keep the tree clean under `-Wmissing-prototypes`: every public
function is declared in `eden.h` (or `eyes/eyes.h` for the eyes core).

## Verify (the ritual — run after ANY change)

```sh
printf 'see\nhear\nladder\nladder bin\nexit\n' | ./eden
printf 'birth\ntrain\nfork\nexit\n' | ./eden
printf 'eyes\nnumbers\ntabernacle\nregistry\ntet\nexit\n' | ./eden
```

The hash registry — these must reproduce EXACTLY or the change is wrong:

| artifact | fnv1a64 |
|---|---|
| sight (Bayer palette pull) | CBA9DCB8FC24F705 |
| sound (heartbeat, 13 high / 51 low) | 7132269E1F4A6302 |
| ladder fibonacci 1-2-3-5-8 | DB686787A5FBC2AF |
| ladder binary 1-2-4-8 | D2A3A4180894D545 |
| bound moment (sight‖sound) | E5D7988462660B42 |
| camp of Numbers (right page) | 65FFB6B13CF03CB5 |
| gestation spine (64,800-beat walk) | 0F515C9CE2551225 |
| eyes color pull (palette page) | DBF08AC0B9205125 |
| eyes mono pull (palette page) | 3F600D82D6435B25 |
| tabernacle registry (57 bytes) | 4AED21CD97C8324B |
| voice registry in C (6,252 value bytes, 73+128 rows) | 2A21A2A65603D69D |

Cross-machine proof already holds: gcc 12.2.0 and gcc 13.3.0, -O0 and
-O2, byte-identical (see `verification/`).

## Architecture notes

- One eye, three lenses: `eyes/` color pull (saturated primaries only),
  `eyes/` mono pull (ink/paper text), Eden's Bayer pull (shades). The
  matching context is hard-coded frozen matrices — no learned weights.
- The tabernacle (`src/eden_tabernacle.c`) is the frozen registry:
  ten declared colors in a 3x3x3 tensor (exact or NONE, no guessing),
  the ASCII class table, and the dec/hex/bits conversion printer.
- The voice registry (`src/eden_registry.c`) is frozen C: 73 sound
  tokens (37 unique voices — sound has no case) and 128 voice artifacts,
  pulled by function only. Registry law [LOCKED 2026-08-15]: no TSV
  files anywhere in this project — if one appears, delete it.
- The wheel (`src/tet.c`, `src/tet.h`) is the harmonic heart's
  arithmetic: 15120 = 2^4 x 3^3 x 5 x 7 = 432 x 35 [LOCKED 2026-08-15,
  Tyler: "432x35"]. 80 tensor cells = exactly the 80 divisors; the
  mirror (overtone/undertone) is four subtractions, cell x mirror =
  wheel for every cell; 16 pitch classes, all odd. Integer-only, no
  heap, caller-supplied buffers, 11-law self-verification via `tet`.
- Screen law: one continuous row-major plane; content camps in
  anchored blocks at the EDEN_ANCHOR_* coordinates in eden.h.
- The training overlap is harmonic interleave on one heart — no threads;
  the scheduler is the grid (gate k fires when beat % k == 0).
- The eyes core file writers (`eyes_write_frame` / `eyes_write_recon`)
  are desktop-only; on iOS they become notebook writes. Do not call them
  from the deterministic core path.
- `eden_main()` in `src/main.c` is the iOS entry point.

## Permission structure

[LOCKED] = Tyler decided it; do not reopen. [PROPOSED] = awaiting
Tyler's word; do not treat as law. [DOCTRINE] = Tyler's cosmology, the
frame; locked by his word. [VERIFIED] = checked by math or machine.
[OPEN] = reserved, awaiting a rule. When in doubt, mark it [PROPOSED]
and stop.
