#!/usr/bin/env python3
"""Normalize legacy Shakti curriculum XML and stage referenced assets safely."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Sequence

ALLOWED_LEVELS = {
    "foundation_ascii",
    "counting",
    "alphabet",
    "colors",
    "shapes",
}
CHANNEL_ORDER = ("text", "written_text", "sound_art", "visual_art")
LEGACY_ALIASES = {
    "name": "text",
    "glyph": "written_text",
    "visual_text": "written_text",
}
ASSET_DIRECTORIES = {
    "written_text": "written_text",
    "sound_art": "sound_art",
    "visual_art": "visual_art",
}
EXTENSIONS = {
    "written_text": ".8x8.txt",
    "sound_art": ".wav",
    "visual_art": ".svg",
}


@dataclass(frozen=True)
class Issue:
    severity: str
    code: str
    path: str
    message: str


@dataclass(frozen=True)
class AssetReference:
    xml_path: str
    stone_order: int
    channel: str
    source_name: str
    canonical_name: str
    required: bool = True


@dataclass
class MigrationReport:
    source_root: str
    output_root: str
    apply: bool
    xml_discovered: int = 0
    tablets_normalized: int = 0
    stones_normalized: int = 0
    assets_referenced: int = 0
    assets_copied: int = 0
    duplicate_assets_deduplicated: int = 0
    ignored_xml: int = 0
    issues: list[Issue] = field(default_factory=list)

    @property
    def error_count(self) -> int:
        return sum(issue.severity == "error" for issue in self.issues)

    @property
    def warning_count(self) -> int:
        return sum(issue.severity == "warning" for issue in self.issues)

    def add(self, severity: str, code: str, path: Path | str, message: str) -> None:
        self.issues.append(
            Issue(
                severity=severity,
                code=code,
                path=str(path),
                message=message,
            )
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["error_count"] = self.error_count
        result["warning_count"] = self.warning_count
        return result


class MigrationError(RuntimeError):
    """Raised when migration cannot safely continue."""


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Normalize legacy XML tags to text, written_text, sound_art, "
            "and visual_art; stage assets without overwriting conflicts."
        )
    )
    parser.add_argument("source", type=Path, help="Root containing XML and assets")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("migration_out"),
        help="Staging root written only with --apply",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Write the normalized staging tree",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Replace an existing output directory",
    )
    parser.add_argument(
        "--report",
        type=Path,
        help="Write the JSON report to this path",
    )
    return parser.parse_args(argv)


def is_safe_filename(filename: str) -> bool:
    return (
        bool(filename)
        and ".." not in filename
        and "/" not in filename
        and "\\" not in filename
        and all(32 <= ord(character) != 127 for character in filename)
    )


def asset_key_from_text(text: str) -> str:
    if not text:
        raise ValueError("text is empty")

    encoded = text.encode("ascii", errors="strict")

    if len(encoded) == 1 and not chr(encoded[0]).isalnum():
        return f"ascii_{encoded[0]:03d}"

    if text.startswith(" ") or text.endswith(" ") or "  " in text:
        raise ValueError("text has leading, trailing, or repeated spaces")

    key_parts: list[str] = []

    for value in encoded:
        character = chr(value)

        if character.isalnum() or character == "-":
            key_parts.append(character)
        elif character == " ":
            key_parts.append("_")
        elif 32 <= value <= 126:
            key_parts.append(f"%{value:02X}")
        else:
            raise ValueError("text contains a non-printable character")

    return "".join(key_parts)


def canonical_filename(text: str, channel: str) -> str:
    return f"{asset_key_from_text(text)}{EXTENSIONS[channel]}"


def child_elements(parent: ET.Element, tag: str) -> list[ET.Element]:
    return [child for child in list(parent) if child.tag == tag]


def element_text(element: ET.Element, preserve: bool = False) -> str:
    value = element.text or ""
    return value if preserve else value.strip()


def normalize_aliases(stone: ET.Element, xml_path: Path, report: MigrationReport) -> None:
    for legacy, canonical in LEGACY_ALIASES.items():
        aliases = child_elements(stone, legacy)

        for alias in aliases:
            canonical_elements = child_elements(stone, canonical)
            preserve = canonical == "text"
            alias_value = element_text(alias, preserve=preserve)

            if canonical_elements:
                canonical_value = element_text(
                    canonical_elements[0],
                    preserve=preserve,
                )

                if canonical_value != alias_value:
                    report.add(
                        "error",
                        "conflicting_channel_alias",
                        xml_path,
                        f"<{legacy}> conflicts with <{canonical}>.",
                    )
                    continue

                stone.remove(alias)
                report.add(
                    "warning",
                    "duplicate_legacy_alias_removed",
                    xml_path,
                    f"Removed duplicate <{legacy}>.",
                )
            else:
                alias.tag = canonical
                report.add(
                    "warning",
                    "legacy_alias_normalized",
                    xml_path,
                    f"Renamed <{legacy}> to <{canonical}>.",
                )


def require_single_channel(
    stone: ET.Element,
    tag: str,
    xml_path: Path,
    report: MigrationReport,
) -> ET.Element | None:
    elements = child_elements(stone, tag)

    if len(elements) != 1:
        report.add(
            "error",
            "invalid_channel_count",
            xml_path,
            f"Each stone requires exactly one <{tag}>; found {len(elements)}.",
        )
        return None

    if not element_text(elements[0], preserve=tag == "text"):
        report.add(
            "error",
            "empty_channel",
            xml_path,
            f"<{tag}> cannot be empty.",
        )
        return None

    return elements[0]


def reorder_channels(stone: ET.Element, channels: dict[str, ET.Element]) -> None:
    original_children = list(stone)
    extras = [child for child in original_children if child.tag not in CHANNEL_ORDER]

    for child in original_children:
        stone.remove(child)

    for tag in CHANNEL_ORDER:
        stone.append(channels[tag])

    for child in extras:
        stone.append(child)


def normalize_stone(
    stone: ET.Element,
    xml_path: Path,
    stone_order: int,
    level: str,
    report: MigrationReport,
) -> list[AssetReference]:
    normalize_aliases(stone, xml_path, report)
    channels: dict[str, ET.Element] = {}

    for tag in CHANNEL_ORDER:
        channel = require_single_channel(stone, tag, xml_path, report)

        if channel is None:
            return []

        channels[tag] = channel

    text_value = element_text(channels["text"], preserve=True)

    try:
        written_name = canonical_filename(text_value, "written_text")
        visual_name = canonical_filename(text_value, "visual_art")
    except (UnicodeEncodeError, ValueError) as error:
        report.add(
            "error",
            "invalid_text_key",
            xml_path,
            f"Stone {stone_order}: {error}.",
        )
        return []

    original_written = element_text(channels["written_text"])
    original_visual = element_text(channels["visual_art"])
    original_sound = element_text(channels["sound_art"])
    sound_clips = original_sound.split("|")

    if any(not is_safe_filename(clip) or not clip.endswith(".wav") for clip in sound_clips):
        report.add(
            "error",
            "invalid_sound_sequence",
            xml_path,
            f"Stone {stone_order}: sound_art contains an unsafe clip.",
        )
        return []

    if len(sound_clips) == 1:
        try:
            canonical_sound = canonical_filename(text_value, "sound_art")
        except (UnicodeEncodeError, ValueError) as error:
            report.add(
                "error",
                "invalid_sound_key",
                xml_path,
                f"Stone {stone_order}: {error}.",
            )
            return []
        canonical_sound_clips = [canonical_sound]
    else:
        canonical_sound_clips = sound_clips

    channels["written_text"].text = written_name
    channels["visual_art"].text = visual_name
    channels["sound_art"].text = "|".join(canonical_sound_clips)
    stone.set("order", str(stone_order))
    reorder_channels(stone, channels)

    references = [
        AssetReference(
            xml_path=str(xml_path),
            stone_order=stone_order,
            channel="written_text",
            source_name=original_written,
            canonical_name=written_name,
        ),
        AssetReference(
            xml_path=str(xml_path),
            stone_order=stone_order,
            channel="visual_art",
            source_name=original_visual,
            canonical_name=visual_name,
        ),
    ]

    references.extend(
        AssetReference(
            xml_path=str(xml_path),
            stone_order=stone_order,
            channel="sound_art",
            source_name=source_clip,
            canonical_name=canonical_clip,
            required=level != "foundation_ascii",
        )
        for source_clip, canonical_clip in zip(sound_clips, canonical_sound_clips)
    )

    return references


def normalize_tablet(
    tree: ET.ElementTree,
    xml_path: Path,
    report: MigrationReport,
) -> list[AssetReference] | None:
    root = tree.getroot()

    if root.tag != "tablet":
        report.ignored_xml += 1
        return None

    if root.get("schema") != "SHAKTI_TABLET_4S_V2":
        root.set("schema", "SHAKTI_TABLET_4S_V2")
        report.add(
            "warning",
            "schema_normalized",
            xml_path,
            "Normalized tablet schema to SHAKTI_TABLET_4S_V2.",
        )

    level_element = root.find("level")
    lesson_element = root.find("lesson")
    level = element_text(level_element) if level_element is not None else ""
    lesson = element_text(lesson_element) if lesson_element is not None else ""

    if level not in ALLOWED_LEVELS:
        report.add(
            "error",
            "level_out_of_mvp_scope",
            xml_path,
            f"Level '{level}' is outside the first-five-level MVP.",
        )
        return []

    if not lesson:
        report.add("error", "missing_lesson", xml_path, "Tablet lesson is empty.")
        return []

    stones = root.findall("stone")
    stone_count = root.find("stone_count")

    if stone_count is None:
        stone_count = ET.Element("stone_count")
        insert_at = list(root).index(lesson_element) + 1 if lesson_element is not None else 0
        root.insert(insert_at, stone_count)

    stone_count.text = str(len(stones))
    references: list[AssetReference] = []

    for order, stone in enumerate(stones, start=1):
        references.extend(normalize_stone(stone, xml_path, order, level, report))

    report.tablets_normalized += 1
    report.stones_normalized += len(stones)
    return references


def discover_files(source_root: Path, output_root: Path) -> tuple[list[Path], dict[str, list[Path]]]:
    xml_files: list[Path] = []
    by_basename: dict[str, list[Path]] = defaultdict(list)
    output_resolved = output_root.resolve()

    for root, directories, filenames in os.walk(source_root):
        root_path = Path(root)

        directories[:] = [
            directory
            for directory in directories
            if (root_path / directory).resolve() != output_resolved
            and directory != ".git"
        ]

        for filename in filenames:
            path = root_path / filename

            if path.suffix.lower() == ".xml":
                xml_files.append(path)
            else:
                by_basename[path.name].append(path)

    xml_files.sort()
    for paths in by_basename.values():
        paths.sort()

    return xml_files, by_basename


def sha256(path: Path) -> str:
    digest = hashlib.sha256()

    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)

    return digest.hexdigest()


def tree_fingerprint(tree: ET.ElementTree) -> str:
    payload = ET.tostring(tree.getroot(), encoding="utf-8")
    return hashlib.sha256(payload).hexdigest()


def copy_paths_to_quarantine(
    paths: Iterable[Path],
    destination_root: Path,
) -> None:
    for source in paths:
        digest = sha256(source)
        destination = destination_root / f"{digest[:12]}-{source.name}"
        destination.parent.mkdir(parents=True, exist_ok=True)

        if destination.exists() and sha256(destination) == digest:
            continue

        shutil.copy2(source, destination)


def choose_asset(
    reference: AssetReference,
    assets_by_name: dict[str, list[Path]],
    report: MigrationReport,
) -> tuple[Path | None, dict[str, list[Path]]]:
    candidates = list(assets_by_name.get(Path(reference.source_name).name, []))

    if not candidates and reference.source_name != reference.canonical_name:
        candidates = list(assets_by_name.get(reference.canonical_name, []))

    if not candidates:
        report.add(
            "error" if reference.required else "warning",
            "missing_asset" if reference.required else "optional_asset_missing",
            reference.xml_path,
            (
                f"Stone {reference.stone_order}: no {reference.channel} file "
                f"for '{reference.source_name}'."
            ),
        )
        return None, {}

    by_hash: dict[str, list[Path]] = defaultdict(list)

    for candidate in candidates:
        by_hash[sha256(candidate)].append(candidate)

    if len(by_hash) > 1:
        report.add(
            "error",
            "conflicting_assets",
            reference.xml_path,
            (
                f"Stone {reference.stone_order}: basename "
                f"'{Path(reference.source_name).name}' has different contents."
            ),
        )
        return None, by_hash

    selected_paths = next(iter(by_hash.values()))

    if len(selected_paths) > 1:
        report.duplicate_assets_deduplicated += len(selected_paths) - 1
        report.add(
            "warning",
            "duplicate_asset_deduplicated",
            reference.xml_path,
            (
                f"Stone {reference.stone_order}: deduplicated "
                f"{len(selected_paths)} identical files."
            ),
        )

    return selected_paths[0], {next(iter(by_hash.keys())): selected_paths}


def copy_conflicts(
    conflicts: dict[str, list[Path]],
    staging_root: Path,
    reference: AssetReference,
) -> None:
    destination_root = (
        staging_root
        / "quarantine"
        / "conflicts"
        / reference.channel
        / Path(reference.source_name).name
    )
    paths = [
        path
        for conflict_paths in conflicts.values()
        for path in conflict_paths
    ]
    copy_paths_to_quarantine(paths, destination_root)


def write_tablet(tree: ET.ElementTree, destination: Path) -> None:
    ET.indent(tree, space="  ")
    destination.parent.mkdir(parents=True, exist_ok=True)
    tree.write(destination, encoding="utf-8", xml_declaration=True)


def prepare_output(output_root: Path, force: bool) -> Path:
    if output_root.exists():
        if not force:
            raise MigrationError(
                f"Output already exists: {output_root}. Use --force to replace it."
            )
        shutil.rmtree(output_root)

    output_root.parent.mkdir(parents=True, exist_ok=True)
    return Path(
        tempfile.mkdtemp(
            prefix=f".{output_root.name}.tmp-",
            dir=output_root.parent,
        )
    )


def commit_output(staging_root: Path, output_root: Path) -> None:
    staging_root.replace(output_root)


def migrate(args: argparse.Namespace) -> MigrationReport:
    source_root = args.source.resolve()
    output_root = args.output.resolve()
    report = MigrationReport(
        source_root=str(source_root),
        output_root=str(output_root),
        apply=args.apply,
    )

    if not source_root.is_dir():
        raise MigrationError(f"Source is not a directory: {source_root}")

    xml_files, assets_by_name = discover_files(source_root, output_root)
    report.xml_discovered = len(xml_files)
    normalized_by_name: dict[
        str,
        tuple[Path, ET.ElementTree, list[AssetReference], str],
    ] = {}
    xml_conflicts: dict[str, list[Path]] = defaultdict(list)

    for xml_path in xml_files:
        try:
            tree = ET.parse(xml_path)
        except ET.ParseError as error:
            report.add("error", "invalid_xml", xml_path, str(error))
            continue

        error_count_before = report.error_count
        references = normalize_tablet(tree, xml_path, report)

        if references is None or report.error_count != error_count_before:
            continue

        report.assets_referenced += len(references)
        fingerprint = tree_fingerprint(tree)
        existing = normalized_by_name.get(xml_path.name)

        if existing is not None:
            existing_path, _, _, existing_fingerprint = existing

            if existing_fingerprint == fingerprint:
                report.add(
                    "warning",
                    "duplicate_tablet_deduplicated",
                    xml_path,
                    f"Deduplicated identical tablet '{xml_path.name}'.",
                )
                continue

            report.add(
                "error",
                "tablet_filename_collision",
                xml_path,
                (
                    f"Different tablets share the output filename "
                    f"'{xml_path.name}'."
                ),
            )
            xml_conflicts[xml_path.name].extend([existing_path, xml_path])
            normalized_by_name.pop(xml_path.name, None)
            continue

        if xml_path.name in xml_conflicts:
            report.add(
                "error",
                "tablet_filename_collision",
                xml_path,
                (
                    f"Tablet filename '{xml_path.name}' already has "
                    "conflicting inputs."
                ),
            )
            xml_conflicts[xml_path.name].append(xml_path)
            continue

        normalized_by_name[xml_path.name] = (
            xml_path,
            tree,
            references,
            fingerprint,
        )

    normalized = [
        (xml_path, tree, references)
        for xml_path, tree, references, _ in normalized_by_name.values()
    ]
    normalized.sort(key=lambda item: item[0].name)

    staging_root: Path | None = None

    if args.apply:
        staging_root = prepare_output(output_root, args.force)

        for filename, conflict_paths in xml_conflicts.items():
            copy_paths_to_quarantine(
                conflict_paths,
                staging_root / "quarantine" / "conflicts" / "xml" / filename,
            )

    copied_destinations: dict[Path, str] = {}
    copied_sources: dict[Path, Path] = {}
    destination_conflicts: set[Path] = set()

    for xml_path, tree, references in normalized:
        tablet_error_count = report.error_count

        for reference in references:
            source_asset, conflicts = choose_asset(reference, assets_by_name, report)

            if source_asset is None:
                if args.apply and staging_root is not None and conflicts:
                    copy_conflicts(conflicts, staging_root, reference)
                continue

            if args.apply and staging_root is not None:
                destination = (
                    staging_root
                    / "eden_out"
                    / ASSET_DIRECTORIES[reference.channel]
                    / reference.canonical_name
                )
                source_digest = sha256(source_asset)

                if destination in destination_conflicts:
                    copy_paths_to_quarantine(
                        [source_asset],
                        (
                            staging_root
                            / "quarantine"
                            / "conflicts"
                            / reference.channel
                            / reference.canonical_name
                        ),
                    )
                    continue

                if destination in copied_destinations:
                    if copied_destinations[destination] != source_digest:
                        report.add(
                            "error",
                            "destination_collision",
                            reference.xml_path,
                            f"Different assets resolve to '{destination.name}'.",
                        )
                        previous_source = copied_sources[destination]
                        copy_paths_to_quarantine(
                            [previous_source, source_asset],
                            (
                                staging_root
                                / "quarantine"
                                / "conflicts"
                                / reference.channel
                                / reference.canonical_name
                            ),
                        )
                        destination.unlink(missing_ok=True)
                        report.assets_copied -= 1
                        destination_conflicts.add(destination)
                        copied_destinations.pop(destination, None)
                        copied_sources.pop(destination, None)
                    continue

                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_asset, destination)
                copied_destinations[destination] = source_digest
                copied_sources[destination] = source_asset
                report.assets_copied += 1

        if args.apply and staging_root is not None and report.error_count == tablet_error_count:
            destination_xml = (
                staging_root
                / "data"
                / "eden"
                / "XML_text"
                / xml_path.name
            )
            write_tablet(tree, destination_xml)

    if args.apply and staging_root is not None:
        report_path = staging_root / "migration_report.json"
        report_path.write_text(
            json.dumps(report.to_dict(), indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        commit_output(staging_root, output_root)

    return report


def write_external_report(report: MigrationReport, report_path: Path) -> None:
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report.to_dict(), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def print_summary(report: MigrationReport) -> None:
    print(
        "Migration scan: "
        f"{report.tablets_normalized} tablet(s), "
        f"{report.stones_normalized} stone(s), "
        f"{report.assets_referenced} asset reference(s), "
        f"{report.error_count} error(s), "
        f"{report.warning_count} warning(s)."
    )

    if report.apply:
        print(f"Staged output: {report.output_root}")
    else:
        print("Dry run only. Re-run with --apply after reviewing the report.")


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])

    try:
        report = migrate(args)
    except (MigrationError, OSError) as error:
        print(f"Migration failed: {error}", file=sys.stderr)
        return 2

    if args.report is not None:
        write_external_report(report, args.report.resolve())

    print_summary(report)
    return 2 if report.error_count else 0


if __name__ == "__main__":
    raise SystemExit(main())
