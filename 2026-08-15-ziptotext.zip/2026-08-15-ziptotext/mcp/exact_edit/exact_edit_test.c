/* exact_edit_test.c — the intentional-error record.
   Every case states the exit it must produce and that the source file must be
   untouched. A case that behaves differently prints FAIL and the run fails.
   exact_edit_run is called directly, in this process. No child process. */

#include "exact_edit.h"
#include "shakti_time.h"

#include <stdio.h>
#include <string.h>

#define FIXTURE "temp/exact_edit_fixture.txt"
#define TESTLOG "temp/exact_edit_test.log"
#define RECORD  "temp/exact_edit_test_record.xml"
#define TEMPDIR "temp"

static const char *FIXTURE_BODY =
    "alpha\n"
    "bravo\n"
    "charlie\n"
    "bravo\n"
    "delta\n";

typedef struct {
    const char *name;
    ee_verb_t verb;
    const char *e1;
    const char *e2;
    ee_side_t side;
    int selector;
    ee_result_t want;
    const char *why;
} case_t;

static const case_t CASES[] = {
    { "column_two_empty", EE_VERB_REPLACE, "bravo",   "",        EE_SIDE_AFTER,  EE_SEL_NONE, EE_ERROR,     "both columns are required" },
    { "nothing_matches",  EE_VERB_REPLACE, "zulu",    "x",       EE_SIDE_AFTER,  EE_SEL_NONE, EE_NO_CHANGE, "no match stops the run" },
    { "several_match",    EE_VERB_REPLACE, "bravo",   "x",       EE_SIDE_AFTER,  EE_SEL_NONE, EE_NO_CHANGE, "two matches need an occurrence" },
    { "no_such_number",   EE_VERB_REPLACE, "bravo",   "x",       EE_SIDE_AFTER,  9,           EE_ERROR,     "selector past the match count" },
    { "confirm_differs",  EE_VERB_REMOVE,  "bravo",   "brava",   EE_SIDE_AFTER,  1,           EE_ERROR,     "remove needs the same line twice" },
    { "case_matters",     EE_VERB_REPLACE, "BRAVO",   "x",       EE_SIDE_AFTER,  EE_SEL_NONE, EE_NO_CHANGE, "capitals are part of the line" },
    { "inner_space",      EE_VERB_REPLACE, "bra vo",  "x",       EE_SIDE_AFTER,  EE_SEL_NONE, EE_NO_CHANGE, "spaces inside a line are part of it" },
    { "part_of_a_line",   EE_VERB_REPLACE, "brav",    "x",       EE_SIDE_AFTER,  EE_SEL_NONE, EE_NO_CHANGE, "the whole line is the unit" },
    { "one_replace",      EE_VERB_REPLACE, "charlie", "CHARLIE", EE_SIDE_AFTER,  EE_SEL_NONE, EE_CHANGED,   "one match is acted on" },
    { "add_after",        EE_VERB_ADD,     "echo",    "delta",   EE_SIDE_AFTER,  EE_SEL_NONE, EE_CHANGED,   "the new line follows the anchor" },
    { "add_before",       EE_VERB_ADD,     "aardvark","alpha",   EE_SIDE_BEFORE, EE_SEL_NONE, EE_CHANGED,   "before puts it ahead of the anchor" },
    { "remove_second",    EE_VERB_REMOVE,  "bravo",   "bravo",   EE_SIDE_AFTER,  2,           EE_CHANGED,   "the named occurrence goes" },
    { "replace_all",      EE_VERB_REPLACE, "bravo",   "BRAVO",   EE_SIDE_AFTER,  EE_SEL_ALL,  EE_CHANGED,   "all acts from the bottom up" }
};

static int write_fixture(void)
{
    FILE *f = fopen(FIXTURE, "wb");
    if (f == NULL) {
        return 0;
    }
    fputs(FIXTURE_BODY, f);
    return fclose(f) == 0;
}

/* Reads the fixture back and reports whether it is byte for byte as written. */
static int fixture_untouched(void)
{
    char buffer[512];
    size_t n;
    FILE *f = fopen(FIXTURE, "rb");
    if (f == NULL) {
        return 0;
    }
    n = fread(buffer, 1U, sizeof buffer - 1U, f);
    fclose(f);
    buffer[n] = '\0';
    return strcmp(buffer, FIXTURE_BODY) == 0;
}

int main(void)
{
    size_t count = sizeof CASES / sizeof CASES[0];
    size_t k;
    unsigned passed = 0U;
    unsigned failed = 0U;
    FILE *record;

    record = fopen(RECORD, "wb");
    if (record == NULL) {
        printf("STOP    %s could not be opened.\n", RECORD);
        return (int)EE_ERROR;
    }
    fprintf(record, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    fprintf(record, "<exact_edit_test_record schema=\"EXACT_EDIT_TEST_V1\">\n");

    for (k = 0U; k < count; k++) {
        shakti_tick_clock_t clock_state;
        ee_request_t request;
        ee_result_t got;
        int untouched;

        if (!write_fixture()) {
            printf("STOP    the fixture could not be written.\n");
            fclose(record);
            return (int)EE_ERROR;
        }

        memset(&request, 0, sizeof request);
        request.path = FIXTURE;
        request.e1 = CASES[k].e1;
        request.e2 = CASES[k].e2;
        request.verb = CASES[k].verb;
        request.side = CASES[k].side;
        request.selector = CASES[k].selector;
        request.log_path = TESTLOG;
        request.out_dir = TEMPDIR;
        request.caller = "test";

        printf("\n=== %s ===\n", CASES[k].name);
        shakti_tick_clock_init(&clock_state);
        got = exact_edit_run(&request, &clock_state, stdout);
        untouched = fixture_untouched();

        if (got == CASES[k].want && untouched) {
            passed++;
            printf("PASS  %s  exit %d  the file it read is unchanged\n",
                   CASES[k].name, (int)got);
        } else {
            failed++;
            printf("FAIL  %s  wanted exit %d, got %d. "
                   "the file it read is unchanged: %s\n",
                   CASES[k].name, (int)CASES[k].want, (int)got,
                   untouched ? "yes" : "no");
        }
        fprintf(record, "  <case name=\"%s\">\n", CASES[k].name);
        fprintf(record, "    <verb>%s</verb>\n", exact_edit_verb_name(CASES[k].verb));
        fprintf(record, "    <column_one><![CDATA[%s]]></column_one>\n", CASES[k].e1);
        fprintf(record, "    <column_two><![CDATA[%s]]></column_two>\n", CASES[k].e2);
        fprintf(record, "    <wanted_exit>%d</wanted_exit>\n", (int)CASES[k].want);
        fprintf(record, "    <got_exit>%d</got_exit>\n", (int)got);
        fprintf(record, "    <source_unchanged>%s</source_unchanged>\n",
                untouched ? "yes" : "no");
        fprintf(record, "    <result>%s</result>\n",
                (got == CASES[k].want && untouched) ? "PASS" : "FAIL");
        fprintf(record, "    <why><![CDATA[%s]]></why>\n", CASES[k].why);
        fprintf(record, "  </case>\n");
    }
    fprintf(record, "  <totals passed=\"%u\" failed=\"%u\" cases=\"%lu\"/>\n",
            passed, failed, (unsigned long)count);
    fprintf(record, "</exact_edit_test_record>\n");
    fclose(record);

    printf("\n%u passed, %u failed, %lu cases. Record appended to %s\n",
           passed, failed, (unsigned long)count, RECORD);
    return failed == 0U ? (int)EE_CHANGED : (int)EE_ERROR;
}
