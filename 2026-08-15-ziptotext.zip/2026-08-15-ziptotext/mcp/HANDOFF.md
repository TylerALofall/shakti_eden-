# mcp-session-handoff

Continuity card for the next session working on `mcp/`. Read this first, then
`README.md`, then `CHANGES.md`. Tyler's latest direct instruction overrides
everything below.

## Current state (as of 2026-08-12)

- **Where it lives:** this workspace, not the repository. Nothing here has been
  pushed. Tyler promotes.
- **Purity:** C99 and the standard library. Fixed compile-time capacity. One
  process. No child process anywhere in the section.
- **Build:** `make` in `exact_edit/` and `switchboard/`.
  CFLAGS `-std=c99 -pedantic -Wall -Wextra -Werror`.
- **Test:** `make check` in each. Records land in `temp/` as XML.
- **Perimeter:** `make perimeter` in each. Two greps, each matching a call
  rather than prose. Both must print nothing.
- **Compiled:** no. **Run:** no. No compiler has seen this section. Every
  statement about it building is reading, not running.

## Tyler's architecture (do not violate)

1. **Shakti lives in her own shell.** A refusal ends one call and nothing else.
   She is never shut down, logged out, or stopped because a gate is closed.
2. **No runner, no subprocess, no daemon, no second core.** A registered tool is
   a C function the switchboard calls in its own process.
3. **The switchboard is the only route out.** Two registrations are required:
   the menu file and the table in `shakti_mcp.c`. One without the other is a
   refusal.
4. **Every call is recorded**, including every refusal, with who sent it and
   through which door.
5. **Originals do not move.** The file a tool is given is read and left where it
   is. Copies and records go to the temp dir the switchboard owns and names.
6. **Stored records are XML.**
7. **A CORE/ML that trains her runs outside her house** and its artifacts wait
   until deliberately admitted. Eden stays deterministic.

## The gate

A session begins with editing closed. Always.

- `/sign_in/ <who> sign_in|face` — the control app states a name and its check.
- `/edit/ open <branch>` — Tyler, signed in. Editing tools run this session.
- `/edit/ close` — editing tools stop running.

A tool with `class="edit"` runs while the branch is open. A tool with
`owner="tyler"` refuses Shakti whatever the gate says.

**The switchboard does not perform the check.** It cannot see a face and holds
no password. The app states which check it made and the record says `stated`.
Making that provable is separate work and is not in this section.

## What is missing

Revision 5 §VI.G lists nine loop points. Three are here.

| # | Point | Here |
|---|---|---|
| 1 | Epoch | through `shakti_tick_next` on every row |
| 2 | Heartbeat | missing |
| 3 | Goal / system message | missing |
| 4 | `/notebook/` | missing |
| 5 | `/menu/` | built |
| 6 | `/shakti_run/` | built |
| 7 | `/message_tyler/`, `/note_tyler/` | missing |
| 8 | `/message_shakti/`, `/note_shakti/` | missing |
| 9 | `/reflection/` | missing |

Memory is not here either.

## Known gap

`switchboard/mcp_test.c` case `tylers_tool_from_shakti` calls `edit_menu`, which
is a `<section>` in the menu and not a `<tool>`. It will refuse for the reason
"not in the menu" rather than "tyler owns it" — the right result for the wrong
reason. Either the menu grows a tool inside `edit_menu`, or `mcp_menu_lookup`
learns to check sections as well. Tyler's call.

## Open decisions

- The section letter and function order this work owns in Constitution
  Section III. `Gf` is taken from Revision 5 §VI.G; the ordered function numbers
  inside `Gf` are assigned at registration and have not been reviewed.
- Whether the test record should be one file per run, named by tick, instead of
  one file rewritten each run. XML has one closed root, so appending is not
  available the way it was for the tab file.
- Whether the sign-in check has to be provable rather than stated.

## How to work here

- C99 only. Read what Tyler names. Write only in this workspace.
- Smallest change. Do not add scope. Do not rewrite Tyler's documents.
- Say "written, not compiled" and "written, not run" when that is the state.
- Mark unclear dictated text `UNKNOWN`, verbatim, and ask.
- One section at a time. Every section's `README.md` names its files first.
