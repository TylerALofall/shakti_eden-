#!/usr/bin/env python3
"""Tests for the curriculum migration pipeline."""

from __future__ import annotations

import importlib.util
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "tools" / "migrate_curriculum.py"
SPEC = importlib.util.spec_from_file_location("migrate_curriculum", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
MIGRATE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MIGRATE
SPEC.loader.exec_module(MIGRATE)


class Args:
    def __init__(self, source: Path, output: Path, apply: bool = True) -> None:
        self.source = source
        self.output = output
        self.apply = apply
        self.force = False
        self.report = None


class MigrationTests(unittest.TestCase):
    def make_asset(self, root: Path, directory: str, name: str, content: bytes) -> None:
        path = root / directory / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)

    def write_tablet(self, root: Path, body: str, name: str = "tablet.xml") -> Path:
        path = root / "legacy" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body, encoding="utf-8")
        return path

    def test_normalizes_legacy_tags_and_directories(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            source = base / "source"
            output = base / "output"
            source.mkdir()

            self.write_tablet(
                source,
                """<?xml version="1.0" encoding="UTF-8"?>
<tablet schema="OLD">
  <level>colors</level>
  <lesson>colors_solo</lesson>
  <stone_count>1</stone_count>
  <stone order="9">
    <name>red</name>
    <glyph>legacy-red.txt</glyph>
    <sound_art>legacy-red.wav</sound_art>
    <visual_art>legacy-red.svg</visual_art>
  </stone>
</tablet>
""",
            )
            self.make_asset(source, "Visual_text", "legacy-red.txt", b"written")
            self.make_asset(source, "Sound_art", "legacy-red.wav", b"sound")
            self.make_asset(source, "Visual_art", "legacy-red.svg", b"<svg/>")

            report = MIGRATE.migrate(Args(source, output))

            self.assertEqual(report.error_count, 0)
            self.assertTrue((output / "eden_out" / "written_text" / "red.8x8.txt").is_file())
            self.assertTrue((output / "eden_out" / "sound_art" / "red.wav").is_file())
            self.assertTrue((output / "eden_out" / "visual_art" / "red.svg").is_file())

            tree = ET.parse(output / "data" / "eden" / "XML_text" / "tablet.xml")
            stone = tree.getroot().find("stone")
            self.assertIsNotNone(stone)
            assert stone is not None
            self.assertEqual([child.tag for child in list(stone)[:4]], list(MIGRATE.CHANNEL_ORDER))
            self.assertEqual(stone.get("order"), "1")
            self.assertEqual(stone.findtext("text"), "red")
            self.assertEqual(stone.findtext("written_text"), "red.8x8.txt")
            self.assertEqual(stone.findtext("sound_art"), "red.wav")
            self.assertEqual(stone.findtext("visual_art"), "red.svg")

    def test_preserves_single_space_text(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            source = base / "source"
            output = base / "output"
            source.mkdir()

            self.write_tablet(
                source,
                """<tablet schema="SHAKTI_TABLET_4S_V2">
  <level>foundation_ascii</level>
  <lesson>space</lesson>
  <stone_count>1</stone_count>
  <stone order="1">
    <text> </text>
    <written_text>ascii_032.8x8.txt</written_text>
    <sound_art>ascii_032.wav</sound_art>
    <visual_art>ascii_032.svg</visual_art>
  </stone>
</tablet>
""",
            )
            self.make_asset(
                source,
                "written_text",
                "ascii_032.8x8.txt",
                b"written",
            )
            self.make_asset(
                source,
                "visual_art",
                "ascii_032.svg",
                b"<svg/>",
            )

            report = MIGRATE.migrate(Args(source, output))

            self.assertEqual(report.error_count, 0)
            tree = ET.parse(output / "data" / "eden" / "XML_text" / "tablet.xml")
            self.assertEqual(tree.getroot().find("stone").findtext("text"), " ")

    def test_rejects_conflicting_aliases(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            source = base / "source"
            output = base / "output"
            source.mkdir()

            self.write_tablet(
                source,
                """<tablet schema="SHAKTI_TABLET_4S_V2">
  <level>alphabet</level>
  <lesson>conflict</lesson>
  <stone_count>1</stone_count>
  <stone order="1">
    <text>A</text>
    <name>B</name>
    <written_text>A.8x8.txt</written_text>
    <sound_art>A.wav</sound_art>
    <visual_art>A.svg</visual_art>
  </stone>
</tablet>
""",
            )

            report = MIGRATE.migrate(Args(source, output, apply=False))

            self.assertGreater(report.error_count, 0)
            self.assertTrue(
                any(issue.code == "conflicting_channel_alias" for issue in report.issues)
            )

    def test_quarantines_duplicate_xml_filenames(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            source = base / "source"
            output = base / "output"
            source.mkdir()

            first = source / "first"
            second = source / "second"
            first.mkdir()
            second.mkdir()

            (first / "tablet.xml").write_text(
                """<tablet schema="SHAKTI_TABLET_4S_V2">
  <level>colors</level>
  <lesson>red</lesson>
  <stone_count>1</stone_count>
  <stone order="1">
    <text>red</text>
    <written_text>red.8x8.txt</written_text>
    <sound_art>red.wav</sound_art>
    <visual_art>red.svg</visual_art>
  </stone>
</tablet>
""",
                encoding="utf-8",
            )
            (second / "tablet.xml").write_text(
                """<tablet schema="SHAKTI_TABLET_4S_V2">
  <level>colors</level>
  <lesson>blue</lesson>
  <stone_count>1</stone_count>
  <stone order="1">
    <text>blue</text>
    <written_text>blue.8x8.txt</written_text>
    <sound_art>blue.wav</sound_art>
    <visual_art>blue.svg</visual_art>
  </stone>
</tablet>
""",
                encoding="utf-8",
            )

            report = MIGRATE.migrate(Args(source, output))

            self.assertGreater(report.error_count, 0)
            self.assertTrue(
                any(issue.code == "tablet_filename_collision" for issue in report.issues)
            )
            self.assertFalse(
                (output / "data" / "eden" / "XML_text" / "tablet.xml").exists()
            )
            quarantined = list(
                (output / "quarantine" / "conflicts" / "xml" / "tablet.xml").glob("*")
            )
            self.assertEqual(len(quarantined), 2)

    def test_quarantines_canonical_asset_collisions(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            source = base / "source"
            output = base / "output"
            source.mkdir()

            self.write_tablet(
                source,
                """<tablet schema="SHAKTI_TABLET_4S_V2">
  <level>colors</level>
  <lesson>collision</lesson>
  <stone_count>2</stone_count>
  <stone order="1">
    <text>red</text>
    <written_text>legacy-a.txt</written_text>
    <sound_art>legacy-a.wav</sound_art>
    <visual_art>legacy-a.svg</visual_art>
  </stone>
  <stone order="2">
    <text>red</text>
    <written_text>legacy-b.txt</written_text>
    <sound_art>legacy-b.wav</sound_art>
    <visual_art>legacy-b.svg</visual_art>
  </stone>
</tablet>
""",
            )

            for suffix, first_content, second_content in (
                (".txt", b"first-written", b"second-written"),
                (".wav", b"first-sound", b"second-sound"),
                (".svg", b"first-visual", b"second-visual"),
            ):
                self.make_asset(source, "legacy", f"legacy-a{suffix}", first_content)
                self.make_asset(source, "legacy", f"legacy-b{suffix}", second_content)

            report = MIGRATE.migrate(Args(source, output))

            self.assertGreater(report.error_count, 0)
            self.assertTrue(
                any(issue.code == "destination_collision" for issue in report.issues)
            )
            self.assertFalse(
                (output / "eden_out" / "written_text" / "red.8x8.txt").exists()
            )
            self.assertFalse(
                (output / "eden_out" / "sound_art" / "red.wav").exists()
            )
            self.assertFalse(
                (output / "eden_out" / "visual_art" / "red.svg").exists()
            )
            self.assertEqual(
                len(
                    list(
                        (
                            output
                            / "quarantine"
                            / "conflicts"
                            / "written_text"
                            / "red.8x8.txt"
                        ).glob("*")
                    )
                ),
                2,
            )

    def test_rejects_math_until_first_five_levels_are_proven(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            source = base / "source"
            output = base / "output"
            source.mkdir()

            self.write_tablet(
                source,
                """<tablet schema="SHAKTI_TABLET_4S_V2">
  <level>math</level>
  <lesson>deferred</lesson>
  <stone_count>1</stone_count>
  <stone order="1">
    <text>2 + 2 = 4</text>
    <written_text>2_%2B_2_%3D_4.8x8.txt</written_text>
    <sound_art>two.wav|plus.wav|two.wav|equals.wav|four.wav</sound_art>
    <visual_art>2_%2B_2_%3D_4.svg</visual_art>
  </stone>
</tablet>
""",
            )

            report = MIGRATE.migrate(Args(source, output, apply=False))

            self.assertGreater(report.error_count, 0)
            self.assertTrue(
                any(issue.code == "level_out_of_mvp_scope" for issue in report.issues)
            )


if __name__ == "__main__":
    unittest.main()
