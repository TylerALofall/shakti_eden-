#include "eden.h"

#include <stdio.h>

/*
 * Binary sound: one HIGH and one LOW for every sample.
 *
 * The source wave is the heartbeat itself — two waves, constant, the
 * lub and the dub — synthesized with fixed integer math. Every sample
 * quantizes to exactly one bit against threshold 128. The 1-bit rebuild
 * must be exact: re-quantizing the rebuild returns the identical bits,
 * drift 0, hashed FNV-1a 64 (the eyes family).
 */

static int g_wave[EDEN_SOUND_SAMPLES];
static unsigned char g_bits[EDEN_SOUND_SAMPLES / 8UL];
static int g_rebuild[EDEN_SOUND_SAMPLES];
static int g_ready = 0;
static unsigned long long g_hash = 0ULL;

int eden_sound_ready(void)
{
    return g_ready;
}

unsigned long long eden_sound_hash(void)
{
    return g_hash;
}

static void sound_synth_heartbeat(void)
{
    unsigned long i;

    for (i = 0UL; i < EDEN_SOUND_SAMPLES; ++i) {
        g_wave[i] = 0;
    }

    /* lub: the first wave */
    for (i = 0UL; i < 8UL; ++i) {
        g_wave[i] = 200 - (int)(10UL * i);
    }

    /* dub: the second wave, softer, constant spacing */
    for (i = 16UL; i < 24UL; ++i) {
        g_wave[i] = 170 - (int)(10UL * (i - 16UL));
    }
}

int eden_sound_run(void)
{
    unsigned long i;
    unsigned long high;
    unsigned long low;
    unsigned long drift;

    sound_synth_heartbeat();

    for (i = 0UL; i < EDEN_SOUND_SAMPLES / 8UL; ++i) {
        g_bits[i] = 0U;
    }

    high = 0UL;
    low = 0UL;

    for (i = 0UL; i < EDEN_SOUND_SAMPLES; ++i) {
        if (g_wave[i] >= EDEN_SOUND_THRESHOLD) {
            g_bits[i / 8UL] |= (unsigned char)(0x80U >> (i % 8UL));
            ++high;
        } else {
            ++low;
        }
    }

    for (i = 0UL; i < EDEN_SOUND_SAMPLES; ++i) {
        unsigned int bit;

        bit = (unsigned int)((g_bits[i / 8UL] >> (7UL - (i % 8UL))) & 1U);
        g_rebuild[i] = bit != 0U ? 255 : 0;
    }

    drift = 0UL;

    for (i = 0UL; i < EDEN_SOUND_SAMPLES; ++i) {
        unsigned int bit;
        unsigned int again;

        bit = (unsigned int)((g_bits[i / 8UL] >> (7UL - (i % 8UL))) & 1U);
        again = g_rebuild[i] >= EDEN_SOUND_THRESHOLD ? 1U : 0U;

        if (bit != again) {
            ++drift;
        }
    }

    g_hash = eden_fnv1a64(
        EDEN_FNV_INIT, g_bits, EDEN_SOUND_SAMPLES / 8UL
    );

    printf(
        "sound: heartbeat wave, %lu samples, one high and one low "
        "per sample\n",
        EDEN_SOUND_SAMPLES
    );
    printf(
        "sound: high=%lu low=%lu drift=%lu hash=fnv1a64:%016llX\n",
        high,
        low,
        drift,
        g_hash
    );

    if (drift != 0UL) {
        printf("FAIL: binary sound rebuild drifted\n");
        return 0;
    }

    g_ready = 1;
    printf("sound: PASS exact 1-bit rebuild\n");
    return 1;
}
