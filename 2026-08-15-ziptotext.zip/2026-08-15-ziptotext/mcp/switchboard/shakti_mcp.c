/* shakti_mcp.c — the switchboard. The one way a tool runs.
   C99 and the standard library. Working memory is the fixed arrays declared
   below, sized at compile time. The whole call happens in this process: a
   registered tool is a C function and the MCP calls it directly.

   Two registrations are required before anything runs. The menu file has to
   carry the tool, and the table in this file has to carry it. One without the
   other is a refusal, said out loud and written to the record. */

#include "shakti_mcp.h"
#include "shakti_log.h"
#include "shakti_time.h"
#include "../exact_edit/exact_edit.h"

#include <stdlib.h>
#include <string.h>

/* Working memory. */
static char g_menu[MCP_MENU_BYTES];
static long g_menu_length;

const char *mcp_origin_name(mcp_origin_t origin)
{
    if (origin == MCP_ORIGIN_TERMINAL)    return "terminal";
    if (origin == MCP_ORIGIN_CONTROL_APP) return "shakti_control_2";
    return "her shell";
}

const char *mcp_check_name(mcp_check_t check)
{
    if (check == MCP_CHECK_SIGN_IN) return "sign in";
    if (check == MCP_CHECK_FACE)    return "face";
    return "none";
}

/* ---------------------------------------------------------------- record */

/* One row per call, per Revision 5 VII. The timing letter rides in the phase
   field: A the call arriving, T the tool returning, Z the call ending.
   The channel field carries who sent it and through which door. */
static void record(mcp_session_t *session, const char *section,
                   unsigned int function_order, const char *timing,
                   const char *subject, const char *property, const char *value)
{
    shakti_tick_t tick;
    char sender[MCP_NAME_MAX * 2];
    if (session->log_path[0] == '\0') {
        return;
    }
    if (!shakti_tick_next(&session->clock, &tick)) {
        return;
    }
    sprintf(sender, "%s@%s",
            session->who[0] != '\0' ? session->who :
                (session->caller == MCP_CALLER_TYLER ? "tyler" : "shakti"),
            mcp_origin_name(session->origin));
    (void)shakti_log_append(session->log_path, "LRN1", &tick, section,
                            function_order, timing, sender,
                            subject, property, value);
}

/* ---------------------------------------------------------------- menu file */

static int menu_load(const mcp_session_t *session)
{
    FILE *file;
    size_t n;
    g_menu_length = 0L;
    g_menu[0] = '\0';
    file = fopen(session->menu_path, "rb");
    if (file == NULL) {
        return 0;
    }
    n = fread(g_menu, 1U, (size_t)MCP_MENU_BYTES - 1U, file);
    if (!feof(file)) {           /* the whole menu has to fit, or it is a stop */
        fclose(file);
        return 0;
    }
    fclose(file);
    g_menu[n] = '\0';
    g_menu_length = (long)n;
    return 1;
}

/* Copies the value of attribute name out of the tag that starts at tag_start.
   A scanner over a known file, not a general parser. */
static int tag_attribute(const char *tag_start, const char *name,
                         char *out, size_t out_size)
{
    const char *tag_end = strchr(tag_start, '>');
    const char *cursor = tag_start;
    size_t name_length = strlen(name);
    size_t i = 0U;

    out[0] = '\0';
    if (tag_end == NULL) {
        return 0;
    }
    while (cursor < tag_end) {
        const char *hit = strstr(cursor, name);
        if (hit == NULL || hit >= tag_end) {
            return 0;
        }
        if (hit > tag_start && (hit[-1] == ' ' || hit[-1] == '\t' || hit[-1] == '\n') &&
            hit[name_length] == '=' && hit[name_length + 1U] == '"') {
            const char *value = hit + name_length + 2U;
            while (*value != '"' && *value != '\0' && i + 1U < out_size) {
                out[i] = *value;
                i++;
                value++;
            }
            out[i] = '\0';
            return 1;
        }
        cursor = hit + name_length;
    }
    return 0;
}

/* The section tag nearest above a position. */
static void section_above(const char *position, char *out, size_t out_size)
{
    const char *cursor = g_menu;
    const char *last = NULL;
    out[0] = '\0';
    for (;;) {
        const char *hit = strstr(cursor, "<section ");
        if (hit == NULL || hit > position) {
            break;
        }
        last = hit;
        cursor = hit + 9;
    }
    if (last != NULL) {
        (void)tag_attribute(last, "id", out, out_size);
    }
}

int mcp_menu_lookup(const mcp_session_t *session, const char *tool_id,
                    mcp_menu_entry_t *entry)
{
    char wanted[MCP_NAME_MAX + 16];
    const char *cursor;

    memset(entry, 0, sizeof *entry);
    if (strlen(tool_id) + 12U >= sizeof wanted) {
        return 0;
    }
    if (g_menu_length == 0L && !menu_load(session)) {
        return 0;
    }
    strcpy(wanted, "<tool id=\"");
    strcat(wanted, tool_id);
    strcat(wanted, "\"");

    cursor = strstr(g_menu, wanted);
    if (cursor == NULL) {
        return 0;
    }
    strncpy(entry->id, tool_id, sizeof entry->id - 1U);
    section_above(cursor, entry->section, sizeof entry->section);
    (void)tag_attribute(cursor, "owner", entry->owner, sizeof entry->owner);
    (void)tag_attribute(cursor, "class", entry->class_name, sizeof entry->class_name);
    {
        char enabled[MCP_NAME_MAX];
        (void)tag_attribute(cursor, "enabled", enabled, sizeof enabled);
        entry->enabled = (unsigned char)(strcmp(enabled, "true") == 0 ? 1 : 0);
    }
    entry->found = 1U;
    return 1;
}

/* ---------------------------------------------------------------- registry */

/* exact_edit, reached through the MCP and nowhere else. */
static mcp_result_t run_exact_edit(const mcp_session_t *session,
                                   int argc, char **argv, FILE *report)
{
    ee_request_t request;
    shakti_tick_clock_t clock_state;
    const char *columns[2];
    int column_count = 0;
    int saw_bar = 0;
    int i;

    memset(&request, 0, sizeof request);
    request.selector = EE_SEL_NONE;
    request.side = EE_SIDE_AFTER;
    request.out_dir = session->temp_dir;
    request.log_path = session->log_path;
    request.caller = (session->caller == MCP_CALLER_TYLER) ? "tyler" : "shakti";
    columns[0] = NULL;
    columns[1] = NULL;

    if (argc < 4) {
        fprintf(report, "STOP    exact_edit needs a file, a verb, and two columns.\n");
        return MCP_STOPPED;
    }
    request.path = argv[0];
    for (i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (strcmp(a, "add") == 0)     { request.verb = EE_VERB_ADD; continue; }
        if (strcmp(a, "remove") == 0)  { request.verb = EE_VERB_REMOVE; continue; }
        if (strcmp(a, "replace") == 0) { request.verb = EE_VERB_REPLACE; continue; }
        if (strcmp(a, "before") == 0)  { request.side = EE_SIDE_BEFORE; continue; }
        if (strcmp(a, "after") == 0)   { request.side = EE_SIDE_AFTER; continue; }
        if (strcmp(a, "|") == 0)       { saw_bar = 1; continue; }
        if (a[0] == '#') {
            request.selector = (strcmp(a, "#all") == 0) ? EE_SEL_ALL : atoi(a + 1);
            continue;
        }
        if (column_count < 2) { columns[column_count] = a; column_count++; continue; }
        fprintf(report, "STOP    there are two columns. A third was given.\n");
        return MCP_STOPPED;
    }
    if (column_count != 2 || saw_bar == 0) {
        fprintf(report, "STOP    both columns are required, separated by |\n");
        return MCP_STOPPED;
    }
    request.e1 = columns[0];
    request.e2 = columns[1];

    shakti_tick_clock_init(&clock_state);
    switch (exact_edit_run(&request, &clock_state, report)) {
    case EE_CHANGED:   return MCP_DONE;
    case EE_NO_CHANGE: return MCP_NO_CHANGE;
    default:           return MCP_STOPPED;
    }
}

static const mcp_registration_t REGISTRY[] = {
    { "exact_edit", run_exact_edit }
};
static const size_t REGISTRY_COUNT = sizeof REGISTRY / sizeof REGISTRY[0];

static mcp_tool_fn registry_find(const char *tool_id)
{
    size_t i;
    for (i = 0U; i < REGISTRY_COUNT; i++) {
        if (strcmp(REGISTRY[i].id, tool_id) == 0) {
            return REGISTRY[i].run;
        }
    }
    return NULL;
}

/* ---------------------------------------------------------------- session */

void mcp_session_init(mcp_session_t *session, mcp_caller_t caller)
{
    memset(session, 0, sizeof *session);
    session->caller = caller;
    session->origin = (caller == MCP_CALLER_TYLER)
                      ? MCP_ORIGIN_CONTROL_APP : MCP_ORIGIN_HER_SHELL;
    session->check = MCP_CHECK_NONE;
    session->signed_in = 0U;
    session->edit_open = 0U;          /* every session starts closed */
    session->who[0] = '\0';
    strcpy(session->branch, "none");
    strcpy(session->menu_path, "../menu/shakti_menu.xml");
    strcpy(session->temp_dir, "temp");
    strcpy(session->log_path, "temp/shakti_mcp.log");
    shakti_tick_clock_init(&session->clock);
    g_menu_length = 0L;
}

/* ---------------------------------------------------------------- sign in */

/* The control app states a name and the check it made. The MCP records that
   statement. It does not verify a face or a password itself, and the record
   says "stated" for that reason. */
mcp_result_t mcp_sign_in(mcp_session_t *session, const char *who,
                         mcp_check_t check, FILE *report)
{
    if (who == NULL || who[0] == '\0' || strlen(who) >= sizeof session->who) {
        fprintf(report, "STOP    name who is signing in.\n");
        return MCP_STOPPED;
    }
    if (check == MCP_CHECK_NONE) {
        fprintf(report, "STOP    name the check: sign_in or face.\n");
        return MCP_STOPPED;
    }
    strcpy(session->who, who);
    session->check = check;
    session->signed_in = 1U;
    fprintf(report, "SIGNED  %s, by %s, stated by %s.\n",
            who, mcp_check_name(check), mcp_origin_name(session->origin));
    fprintf(report, "        The MCP records what the app stated. It did not "
                    "make the check itself.\n");
    record(session, MCP_SECTION_RUN, 9U, "T", "sign in",
           mcp_check_name(check), "stated");
    return MCP_DONE;
}

/* ---------------------------------------------------------------- the gate */

mcp_result_t mcp_edit_open(mcp_session_t *session, const char *branch, FILE *report)
{
    if (session->caller != MCP_CALLER_TYLER) {
        fprintf(report, "REFUSED the edit branch is Tyler's to open. "
                        "Your shell stays open and everything else in it works.\n");
        record(session, MCP_SECTION_RUN, 10U, "Z", "edit branch", "refused", "caller is shakti");
        return MCP_STOPPED;
    }
    if (!session->signed_in) {
        fprintf(report, "REFUSED sign in first. The app states a name and "
                        "whether it was a sign in or a face check.\n");
        record(session, MCP_SECTION_RUN, 10U, "Z", "edit branch", "refused", "no check stated");
        return MCP_STOPPED;
    }
    if (branch == NULL || branch[0] == '\0' || strlen(branch) >= sizeof session->branch) {
        fprintf(report, "STOP    name the branch to open.\n");
        return MCP_STOPPED;
    }
    strcpy(session->branch, branch);
    session->edit_open = 1U;
    fprintf(report, "EDIT    branch %s is open for %s, checked by %s from %s.\n",
            branch, session->who, mcp_check_name(session->check),
            mcp_origin_name(session->origin));
    record(session, MCP_SECTION_RUN, 10U, "T", "edit branch", "open", branch);
    return MCP_DONE;
}

mcp_result_t mcp_edit_close(mcp_session_t *session, FILE *report)
{
    session->edit_open = 0U;
    strcpy(session->branch, "none");
    fprintf(report, "EDIT    closed. Editing tools are off.\n");
    record(session, MCP_SECTION_RUN, 11U, "T", "edit branch", "closed", "none");
    return MCP_DONE;
}

/* ---------------------------------------------------------------- Ge menu */

mcp_result_t mcp_menu(mcp_session_t *session, const char *section,
                      const char *tool, FILE *report)
{
    const char *cursor;

    if (g_menu_length == 0L && !menu_load(session)) {
        fprintf(report, "STOP    the menu at %s could not be read whole. "
                        "Capacity is %d bytes.\n", session->menu_path, MCP_MENU_BYTES);
        record(session, MCP_SECTION_MENU, 1U, "Z", "menu", "unreadable", session->menu_path);
        return MCP_STOPPED;
    }
    record(session, MCP_SECTION_MENU, 1U, "A", "menu",
           section ? section : "titles", tool ? tool : "");

    if (section == NULL) {
        fprintf(report, "/menu/\n\n");
        cursor = g_menu;
        for (;;) {
            char id[MCP_NAME_MAX];
            char owner[MCP_NAME_MAX];
            const char *hit = strstr(cursor, "<section ");
            if (hit == NULL) {
                break;
            }
            if (tag_attribute(hit, "id", id, sizeof id)) {
                (void)tag_attribute(hit, "owner", owner, sizeof owner);
                fprintf(report, "  %s%s\n", id,
                        (strcmp(owner, "tyler") == 0) ? "   (Tyler's)" : "");
            }
            cursor = hit + 9;
        }
        fprintf(report, "\nSay /menu/ <name> for what is in one of them.\n");
        record(session, MCP_SECTION_MENU, 1U, "Z", "menu", "titles", "shown");
        return MCP_DONE;
    }

    /* One section, whole. Printed from its own text so she reads what is
       written for her, not a summary of it. */
    {
        char wanted[MCP_NAME_MAX + 20];
        const char *start;
        const char *end;
        if (strlen(section) + 16U >= sizeof wanted) {
            fprintf(report, "STOP    that name is longer than the menu allows.\n");
            return MCP_STOPPED;
        }
        strcpy(wanted, "<section id=\"");
        strcat(wanted, section);
        strcat(wanted, "\"");
        start = strstr(g_menu, wanted);
        if (start == NULL) {
            fprintf(report, "There is no section called %s. Say /menu/ for the list.\n", section);
            record(session, MCP_SECTION_MENU, 1U, "Z", "menu", "no such section", section);
            return MCP_NO_CHANGE;
        }
        end = strstr(start, "</section>");
        if (end == NULL) {
            end = g_menu + g_menu_length;
        }
        if (tool != NULL) {
            char tool_wanted[MCP_NAME_MAX + 16];
            const char *tool_start;
            const char *tool_end;
            strcpy(tool_wanted, "<tool id=\"");
            strcat(tool_wanted, tool);
            strcat(tool_wanted, "\"");
            tool_start = strstr(start, tool_wanted);
            if (tool_start == NULL || tool_start > end) {
                fprintf(report, "There is no %s in %s.\n", tool, section);
                record(session, MCP_SECTION_MENU, 1U, "Z", "menu", "no such tool", tool);
                return MCP_NO_CHANGE;
            }
            tool_end = strstr(tool_start, "</tool>");
            if (tool_end == NULL || tool_end > end) {
                tool_end = end;
            }
            fwrite(tool_start, 1U, (size_t)(tool_end - tool_start) + 7U, report);
            fputc('\n', report);
            record(session, MCP_SECTION_MENU, 1U, "Z", "menu", section, tool);
            return MCP_DONE;
        }
        fwrite(start, 1U, (size_t)(end - start) + 10U, report);
        fputc('\n', report);
        record(session, MCP_SECTION_MENU, 1U, "Z", "menu", section, "shown");
        return MCP_DONE;
    }
}

/* ---------------------------------------------------------------- Gf run */

mcp_result_t mcp_run(mcp_session_t *session, const char *tool_id,
                     int argc, char **argv, FILE *report)
{
    mcp_menu_entry_t entry;
    mcp_tool_fn run;
    mcp_result_t result;

    /* A — the call arrives. Logged before anything is decided, as Gf requires. */
    record(session, MCP_SECTION_RUN, 1U, "A", tool_id, "called", "");

    if (g_menu_length == 0L && !menu_load(session)) {
        fprintf(report, "STOP    the menu at %s could not be read whole. "
                        "Nothing runs without it.\n", session->menu_path);
        record(session, MCP_SECTION_RUN, 1U, "Z", tool_id, "stopped", "menu unreadable");
        return MCP_STOPPED;
    }
    if (!mcp_menu_lookup(session, tool_id, &entry)) {
        fprintf(report, "REFUSED %s is not in the menu, so it does not run. "
                        "Say /menu/ for what is there.\n", tool_id);
        record(session, MCP_SECTION_RUN, 1U, "Z", tool_id, "refused", "not in the menu");
        return MCP_STOPPED;
    }
    if (!entry.enabled) {
        fprintf(report, "REFUSED %s is in the menu and is not turned on.\n", tool_id);
        record(session, MCP_SECTION_RUN, 1U, "Z", tool_id, "refused", "not enabled");
        return MCP_STOPPED;
    }
    if (strcmp(entry.owner, "tyler") == 0 && session->caller != MCP_CALLER_TYLER) {
        fprintf(report, "REFUSED %s is Tyler's. You can see that it is there, "
                        "and it does not run from your shell. Everything else "
                        "in your shell still works.\n", tool_id);
        record(session, MCP_SECTION_RUN, 1U, "Z", tool_id, "refused", "tyler owns it");
        return MCP_STOPPED;
    }
    /* The gate. An editing tool runs while the edit branch is open. A refusal
       ends the call and nothing else: her shell keeps running. */
    if (strcmp(entry.class_name, "edit") == 0 && !session->edit_open) {
        fprintf(report, "REFUSED the edit branch is closed, so %s is not changing "
                        "files right now. Tyler opens it. Your shell stays open "
                        "and you can carry on with anything else.\n", tool_id);
        record(session, MCP_SECTION_RUN, 1U, "Z", tool_id, "refused", "edit branch closed");
        return MCP_STOPPED;
    }
    run = registry_find(tool_id);
    if (run == NULL) {
        fprintf(report, "REFUSED %s is in the menu and is not built into this MCP. "
                        "Both are required.\n", tool_id);
        record(session, MCP_SECTION_RUN, 1U, "Z", tool_id, "refused", "not in the registry");
        return MCP_STOPPED;
    }

    fprintf(report, "RUN     %s   section %s   caller %s   branch %s\n",
            tool_id, entry.section,
            session->caller == MCP_CALLER_TYLER ? "tyler" : "shakti",
            session->edit_open ? session->branch : "closed");

    result = run(session, argc, argv, report);

    /* T — the tool came back. Z — the call is over. */
    record(session, MCP_SECTION_RUN, 1U, "T", tool_id, "returned",
           result == MCP_DONE ? "changed" :
           result == MCP_NO_CHANGE ? "no change" : "stopped");
    record(session, MCP_SECTION_RUN, 1U, "Z", tool_id, "ended", entry.section);
    return result;
}

/* ---------------------------------------------------------------- status */

mcp_result_t mcp_status(mcp_session_t *session, FILE *report)
{
    fprintf(report, "caller     %s\n",
            session->caller == MCP_CALLER_TYLER ? "tyler" : "shakti");
    fprintf(report, "sender     %s\n", session->who[0] != '\0' ? session->who : "unnamed");
    fprintf(report, "came from  %s\n", mcp_origin_name(session->origin));
    fprintf(report, "check      %s%s\n", mcp_check_name(session->check),
            session->signed_in ? ", as stated by the app" : "");
    fprintf(report, "edit       %s\n",
            session->edit_open ? "open" : "closed");
    fprintf(report, "branch     %s\n", session->branch);
    fprintf(report, "her shell  open\n");
    fprintf(report, "menu       %s\n", session->menu_path);
    fprintf(report, "temp dir   %s\n", session->temp_dir);
    fprintf(report, "record     %s\n", session->log_path);
    fprintf(report, "registry   %lu tool(s) built in\n", (unsigned long)REGISTRY_COUNT);
    fprintf(report, "capacity   menu %d bytes, %d arguments, %d registrations\n",
            MCP_MENU_BYTES, MCP_ARG_MAX, MCP_REGISTRY_MAX);
    record(session, MCP_SECTION_RUN, 12U, "T", "status", "shown", "");
    return MCP_DONE;
}
