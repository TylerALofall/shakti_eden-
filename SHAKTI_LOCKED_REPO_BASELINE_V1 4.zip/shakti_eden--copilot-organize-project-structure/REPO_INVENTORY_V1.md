# SHAKTI REPOSITORY INVENTORY V1

**Inspection mode:** read-only archive inspection  
**Archive:** `shakti_eden--copilot-organize-project-structure 2.zip`  
**SHA-256:** `35a715cfdec595f3c8eea0a73341188858543583a2096d54564703cf784fd8ee`  
**Archive entries:** `613`  
**Code executed from archive:** none

## Candidate baseline

```text
copilot/organize-project-structure
```

This is the working candidate. GitHub `main` is not the build base and must remain untouched.

## Project structure found

```text
src/       14 C source files
include/   16 headers
tests/      6 test/build scripts or sources
tools/      3 C builders
docs/       8 architecture/review documents
data/      control, Eden, Learned, School, source tables
eden_out/  large generated artifact/output tree
backup/    nested source archives
```

## Source files found

```text
src/main.c
src/shakti_artifact.c
src/shakti_asset.c
src/shakti_handwriting.c
src/shakti_log.c
src/shakti_loop.c
src/shakti_manifest.c
src/shakti_memory.c
src/shakti_reason.c
src/shakti_report.c
src/shakti_school.c
src/shakti_score.c
src/shakti_tablet.c
src/shakti_time.c
```

## Status by area

### KEEP AS CANDIDATE

```text
src/main.c
src/shakti_artifact.c
src/shakti_asset.c
src/shakti_log.c
src/shakti_loop.c
src/shakti_manifest.c
src/shakti_memory.c
src/shakti_reason.c
src/shakti_report.c
src/shakti_score.c
src/shakti_tablet.c
src/shakti_time.c
include/
tests/
tools/
```

These are not approved merely because they exist. They require contract comparison and a fresh build in an isolated branch.

### CONFIRMED USEFUL EVIDENCE

- `src/shakti_loop.c` contains the thirteen reflection questions.
- `src/shakti_handwriting.c` and its header use 8x8 rows.
- `src/shakti_artifact.c` contains validators for the 8x8 written-text format, SVG, and WAV.
- The repository is structured as a C project rather than only nested ZIP files.

### REJECT OR REPLACE BEFORE ADMISSION

- `src/shakti_school.c` contains four-pass behavior and mastery/streak targets.
- `include/shakti_config.h` defines `SHAKTI_DEFAULT_MASTERY_TARGET`.
- This conflicts with the current no-mastery/no-four-pass decision.

### CONTROLLED REMOVAL CANDIDATES

The following `.tsv` paths conflict with the current hard-coded-table direction:

```text
data/eden/manifest_ledger.tsv
data/source/MISSING_FOUNDATION_SOUNDS.tsv
data/source/counting_zero_to_ten.tsv
data/source/foundation_ascii_32_126.tsv
data/source/sound_stage_manifest.tsv
```

They are marked for review and later one-section-at-a-time removal. They have not been deleted.

### QUARANTINE

```text
backup/
eden_out/
docs/MASTER_ARCHITECTURE.md
docs/REVISION_5_REVIEW.md
docs/SHAKTI_MCP_REVIEW_AND_BLUEPRINT.md
existing generated XML lessons under data/eden/XML_text/
```

Reasons:

- nested archives can conceal duplicate or older trees;
- generated output must not be mistaken for source truth;
- old architecture documents contain known drift;
- generated XML may encode obsolete naming, mastery, or artifact rules.

### UNKNOWN / ABSENT FROM TOP-LEVEL TREE

- No validated final actuator implementation has been admitted.
- No Swift iOS host target is present in this C99 baseline.
- No final MCP capability/permission implementation has been admitted.
- No final two-tier word/character dictionary implementation has been admitted.
- No final four-panel sound-timed lesson player has been admitted.
- No final anti-skip journal/checkpoint implementation has been validated against the current contract.

## First safe implementation sequence

```text
1. Commit SHAKTI_LOCK_V1.md and this inventory only.
2. Add a read-only contract validator.
3. Replace the obsolete School mastery/pass contract as one complete module.
4. Implement the two-tier token dictionary as one complete module.
5. Implement the sound-timed four-panel lesson player as one complete module.
6. Add the local append-only journal/checkpoint recovery module.
7. Integrate optional Swift capabilities only after the C99 boundary is stable.
```

No source edit should begin until its module contract, allowed paths, and validators are named.
