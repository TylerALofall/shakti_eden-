# Shakti Runnable MVP — C99

This package is a single-process, fixed-memory C99 implementation of Shakti's runnable beginning.

## What runs now

- Restores Eden, School, Goal, Notebook, Menu, Learned memory, and reflection routes.
- Produces an exact startup self-report from the XML manifest ledger.
- Runs the nine-stage loop:
  1. Epoch
  2. Heartbeat
  3. Goal/system message
  4. `/notebook/`
  5. `/menu/`
  6. `/shakti_run/`
  7. `/message_tyler/` and `/note_tyler/`
  8. `/message_shakti/` and `/note_shakti/`
  9. `/reflection/`
- Accepts an external interrupt that stops MCP tools while leaving Shakti awake.
- Loads `<text>` from the curriculum list and the three exact artifact channels: `written_text`, `sound_art`, and `visual_art`.
- Runs Pass 1 as observation without changing School mastery.
- Runs Pass 2–4 actuator drills.
- Requires a ten-correct consecutive streak for symbol mastery.
- Preserves every correct and incorrect attempt in readable append-only logs.
- Reports unknown answers as `I do not know`.
- Uses creative candidates only after independent logic authorization.

## Process boundary

The runtime is one C process and one `shakti_runtime_t` state.

It does not invoke:

- another language runtime,
- another language model,
- a subprocess,
- a shell command,
- `system`, `popen`, `fork`, `exec`, or `spawn`,
- dynamic allocation.

`/shakti_run/` is an internal MCP dispatcher to approved C functions.

## Current curriculum scope

The MVP is limited to the first five levels while the nine-stage loop and three-stage memory model are proven:

1. Foundation ASCII — implemented.
2. Counting — implemented through zero–ten; later counting is planned.
3. Alphabet — implemented.
4. Colors — planned.
5. Shapes — planned.

Math is deferred and is not present in the active manifest.

`<text>` is the source value from the curriculum list. The artifact directories match the XML channel names exactly:

```text
eden_out/written_text/
eden_out/sound_art/
eden_out/visual_art/
```

Eden remains `OPEN`. Runnable means the implemented beginning validates; it does not mean Eden is final or locked.

## Bulk migration

Legacy collections should be scanned before they are copied into Eden:

```sh
python3 tools/migrate_curriculum.py /path/to/incoming \
  --output migration_out \
  --report migration_report.json
```

After the report is clean, add `--apply`. The tool converts `name` to `text`, converts `glyph` or `visual_text` to `written_text`, deduplicates identical assets, and quarantines filename conflicts. See `docs/IMPORT_PIPELINE.md`.

## Build

```sh
make clean
make
```

## Verify

```sh
make test
./shakti --check
./shakti --demo
```

`--check` validates the startup boundary and exits.

`--demo` runs a read-only Pass 1 presentation of the first staged tablet. It writes the startup anchor but does not change School mastery.

## Run interactively

```sh
./shakti
```

Useful commands:

```text
/help/
/status/
/heartbeat/ 0
/menu/
/shakti_run/ status
/shakti_run/ pass 4
/shakti_run/ school +
/interrupt/
/resume/
/quit/
```

During a drill, enter `/stop` to stop without changing the current pass.

## Exact current validation

```text
Implemented data: 1033/1033 checks = 100%
Verified stones: 282/282
Complete tablets: 7
Required channel gaps: 0
Optional Foundation spoken punctuation sounds deferred: 33
Future planned tablets: 7
Eden lock ready: NO
Runnable beginning: YES
```

See:

- `CHECK_RUN_OUTPUT.txt`
- `DEMO_RUN_OUTPUT.txt`
- `DRILL_RUN_OUTPUT.txt`
- `BUILD_TEST_REPORT.txt`
