# tools/exact_edit — the exact line changer

## Every file in this section

| File | Purpose |
|---|---|
| `README.md` | This file. Names every file in the section. |
| `exact_edit.h` | The request, the three verbs, the side, the selector, the capacities, the outcome, and the one entry point. |
| `exact_edit.c` | The four passes: find, act, show, write and log. |
| `exact_edit_shell.c` | The argument line only. Builds one request and calls `exact_edit_run`. |
| `exact_edit_test.c` | Thirteen cases with the exit each must produce. Writes `temp/exact_edit_test_record.xml`. |
| `Makefile` | `make` builds both. `make check` runs the record. `make perimeter` runs the two greps. |

## What it does

Changes one line of one file that you can quote exactly.

```
exact_edit <file> add     "new line" | "line you know" [before|after] [#n|#all]
exact_edit <file> remove  "line"     | "line"                        [#n|#all]
exact_edit <file> replace "old line" | "new line"                    [#n|#all]

  [--out <dir>]  the temp dir every copy goes to. Default temp
```

A line matches when its bytes match, trailing whitespace excluded. Capitalization is part of the line. The spaces inside a line are part of the line. There is no pattern syntax and no similarity anywhere in the source.

`add` puts the new line after the anchor unless `before` is given. `remove` takes the line twice so a slip cannot delete the wrong line.

## The original does not move

The file named on the call is read and left where it is, as it is. The changed copy is written into the temp dir as `<name>.new`, and nothing is written beside the original. The MCP names the temp dir and owns it. Called with no temp dir, the tool stops and says so.

## The four passes

```
PASS 1  find every match, count it, print each with its number
        nothing matches      -> print what it looked for, exit 2
        several match        -> list them, wait for #n or #all, exit 2
PASS 2  act from the bottom of the file upward, so the line number of an
        edit not yet made stays correct
PASS 3  print the changed lines and only those
PASS 4  write the copy into the temp dir, then one log row per acted line
```

The file you name is opened for reading and stays where it is. The copy is `temp/<name>.new`. Tyler puts it in place.

Exit `0` changed, `1` stopped, `2` nothing changed.

## Where it sits

Section `Gf` — major `G` the loop and internal MCP, minor `f` `/shakti_run/`. Function order inside Gf: `01` add, `02` remove, `03` replace. Shakti reads about it at `/menu/ files exact_edit`; it runs at `/shakti_run/ exact_edit`.

`exact_edit_run` is a plain C function. The internal shell dispatches it directly. `exact_edit_shell.c` exists so the same function can be driven from a terminal, and it starts no child process either.

## The log

Uses the writer already in the repository: `shakti_log_append` with `shakti_tick_next` and `shakti_event_id_format`. Row form per Revision 5 §VII.

```
[1793920107:0042]-[Gf]-[02]
```

The timing letter rides in the existing `phase` field, so no signature changed:

| Phase | Written when |
|---|---|
| `A` | the run begins, before any work |
| `T` | one acted line |
| `Z` | the run ends, with the reason when it stopped |

A run that stops still writes `A` and `Z`. A refusal is in the log, not just on the screen.

## Perimeter

Working memory is fixed arrays sized at compile time. The whole run happens in one process. Files are readable text. A full capacity is an explicit stop, and exact text is carried through byte for byte.

```
make perimeter
```

Two greps, each matching a call rather than prose, so a comment can neither pass nor fail the check. Both must print nothing.

## Capacities, printed on every run

| Capacity | Value |
|---|---|
| Lines in a file | 4096 |
| Bytes in a line | 1023 |
| Matches in a run | 512 |
| Bytes in a path | 511 |

## Status

**Written, not compiled, not run.** No build or test output from this section exists. The Makefile expects `$(ROOT)/src/shakti_log.c` and `$(ROOT)/src/shakti_time.c` at the repository root; it has not been run against them, so the include path and the two function signatures are unverified by any compiler. Every `PASS` and `FAIL` line, and `temp/exact_edit_test_record.xml`, comes from `make check` on your machine.
