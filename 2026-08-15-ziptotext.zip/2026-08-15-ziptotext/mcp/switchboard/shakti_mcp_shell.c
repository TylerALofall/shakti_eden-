/* shakti_mcp_shell.c — the line in, the answer back.
   A line that starts with / is Tyler's control plane and is answered at once.
   Any other line is a tool call. The run stays in this process. */

#include "shakti_mcp.h"

#include <stdio.h>
#include <string.h>

/* Splits a line on spaces, keeping "quoted runs" whole. */
static int split_line(char *line, char **argv, int argv_max)
{
    int count = 0;
    char *cursor = line;
    while (*cursor != '\0' && count < argv_max) {
        while (*cursor == ' ' || *cursor == '\t') {
            cursor++;
        }
        if (*cursor == '\0') {
            break;
        }
        if (*cursor == '"') {
            cursor++;
            argv[count] = cursor;
            count++;
            while (*cursor != '"' && *cursor != '\0') {
                cursor++;
            }
        } else {
            argv[count] = cursor;
            count++;
            while (*cursor != ' ' && *cursor != '\t' && *cursor != '\0') {
                cursor++;
            }
        }
        if (*cursor != '\0') {
            *cursor = '\0';
            cursor++;
        }
    }
    return count;
}

static void help(FILE *out)
{
    fprintf(out,
"  /menu/                      the sections\n"
"  /menu/ <section>            that section, whole\n"
"  /menu/ <section> <tool>     that tool: how to call it and what comes back\n"
"  /shakti_run/ <tool> ...     run a registered tool\n"
"  /status/                    sender, door, check, gate, branch, capacities\n"
"  /sign_in/ <who> sign_in|face   the app states who it is and its check\n"
"  /edit/ open <branch>        Tyler opens editing for this session\n"
"  /edit/ close                Tyler closes it\n"
"  /quit/                      leave\n");
}

int main(int argc, char **argv)
{
    mcp_session_t session;
    mcp_caller_t caller = MCP_CALLER_SHAKTI;
    char line[MCP_LINE_MAX];
    char *parts[MCP_ARG_MAX];
    int i;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--tyler") == 0) {
            caller = MCP_CALLER_TYLER;
        } else if (strcmp(argv[i], "--menu") == 0 && i + 1 < argc) {
            i++;
        }
    }
    mcp_session_init(&session, caller);
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--menu") == 0 && i + 1 < argc) {
            strncpy(session.menu_path, argv[i + 1], sizeof session.menu_path - 1U);
            session.menu_path[sizeof session.menu_path - 1U] = '\0';
        }
        if (strcmp(argv[i], "--temp") == 0 && i + 1 < argc) {
            strncpy(session.temp_dir, argv[i + 1], sizeof session.temp_dir - 1U);
            session.temp_dir[sizeof session.temp_dir - 1U] = '\0';
        }
        if (strcmp(argv[i], "--from") == 0 && i + 1 < argc) {
            if (strcmp(argv[i + 1], "app") == 0) {
                session.origin = MCP_ORIGIN_CONTROL_APP;
            } else if (strcmp(argv[i + 1], "terminal") == 0) {
                session.origin = MCP_ORIGIN_TERMINAL;
            } else {
                session.origin = MCP_ORIGIN_HER_SHELL;
            }
        }
    }

    printf("shakti_mcp   caller %s   came from %s   editing closed\n",
           caller == MCP_CALLER_TYLER ? "tyler" : "shakti",
           mcp_origin_name(session.origin));
    help(stdout);

    for (;;) {
        int count;
        printf("\n> ");
        fflush(stdout);
        if (fgets(line, (int)sizeof line, stdin) == NULL) {
            break;
        }
        {
            size_t n = strlen(line);
            while (n > 0U && (line[n - 1U] == '\n' || line[n - 1U] == '\r')) {
                line[n - 1U] = '\0';
                n--;
            }
        }
        count = split_line(line, parts, MCP_ARG_MAX);
        if (count == 0) {
            continue;
        }
        if (strcmp(parts[0], "/quit/") == 0) {
            break;
        }
        if (strcmp(parts[0], "/status/") == 0) {
            (void)mcp_status(&session, stdout);
            continue;
        }
        if (strcmp(parts[0], "/menu/") == 0) {
            (void)mcp_menu(&session,
                           count > 1 ? parts[1] : NULL,
                           count > 2 ? parts[2] : NULL,
                           stdout);
            continue;
        }
        if (strcmp(parts[0], "/sign_in/") == 0) {
            mcp_check_t check = MCP_CHECK_NONE;
            if (count > 2 && strcmp(parts[2], "sign_in") == 0) {
                check = MCP_CHECK_SIGN_IN;
            } else if (count > 2 && strcmp(parts[2], "face") == 0) {
                check = MCP_CHECK_FACE;
            }
            (void)mcp_sign_in(&session, count > 1 ? parts[1] : NULL, check, stdout);
            continue;
        }
        if (strcmp(parts[0], "/edit/") == 0) {
            if (count > 1 && strcmp(parts[1], "open") == 0) {
                (void)mcp_edit_open(&session, count > 2 ? parts[2] : NULL, stdout);
            } else if (count > 1 && strcmp(parts[1], "close") == 0) {
                (void)mcp_edit_close(&session, stdout);
            } else {
                printf("STOP    /edit/ open <branch>, or /edit/ close\n");
            }
            continue;
        }
        if (strcmp(parts[0], "/shakti_run/") == 0) {
            if (count < 2) {
                printf("STOP    name the tool. /menu/ shows what is there.\n");
                continue;
            }
            (void)mcp_run(&session, parts[1], count - 2, &parts[2], stdout);
            continue;
        }
        printf("STOP    %s is not a route here.\n", parts[0]);
        help(stdout);
    }
    return (int)MCP_DONE;
}
