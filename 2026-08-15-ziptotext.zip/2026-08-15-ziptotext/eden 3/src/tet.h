#ifndef TET_H
#define TET_H

/*
 * tet: the prime tetrahedron of the wheel.
 *
 * The wheel is 15120 = 2^4 x 3^3 x 5^1 x 7^1. Four primes, four
 * vertices, six sides, four faces. Every divisor of the wheel is one
 * cell of a four-axis tensor indexed by the prime exponents:
 *
 *     cell(a,b,c,d) = 2^a x 3^b x 5^c x 7^d
 *     a in [0,4]  b in [0,3]  c in [0,1]  d in [0,1]
 *     5 x 4 x 2 x 2 = 80 cells = exactly 80 divisors. A bijection.
 *
 * The mirror (part and remainder, overtone and undertone) is index
 * subtraction, not a lookup table:
 *
 *     mirror(a,b,c,d) = (4-a, 3-b, 1-c, 1-d)
 *     cell x mirror   = 15120, always, every cell.
 *
 * The wheel halves with no shared prime: 432 = 2^4 x 3^3 carries the
 * twos and threes (octaves and fifths, the Pythagorean side); 35 = 5x7
 * carries the fives and sevens (thirds and sevenths, the just side).
 * 432 x 35 = 15120. [LOCKED 2026-08-15, Tyler: "432x35".]
 *
 * A cell read as a PERIOD is rhythm: it fires when slice % period == 0.
 * The same cell read as a RATIO against another cell is pitch. Rhythm
 * and pitch are one number at two scales. Nothing here converts to Hz;
 * nothing here is a float. Ratios stay ratios.
 *
 * No heap, no clock, no subprocess, no floating point. The caller
 * supplies every buffer. Deterministic from the exponents alone.
 */

#define TET_WHEEL    15120UL              /* 2^4 x 3^3 x 5 x 7          */
#define TET_E2       5U                   /* exponents of 2: 0..4       */
#define TET_E3       4U                   /* exponents of 3: 0..3       */
#define TET_E5       2U                   /* exponents of 5: 0..1       */
#define TET_E7       2U                   /* exponents of 7: 0..1       */
#define TET_CELLS    (TET_E2 * TET_E3 * TET_E5 * TET_E7)   /* 80        */
#define TET_CLASSES  (TET_E3 * TET_E5 * TET_E7)            /* 16        */

#define TET_PYTHAGOREAN 432UL             /* 2^4 x 3^3, the 2-3 half    */
#define TET_JUST        35UL              /* 5 x 7,     the 5-7 half    */
#define TET_WOMB        22982400UL        /* seconds of the gestation   */
#define TET_SLICE_GRID  302400UL          /* the slice grid             */

/*
 * Every function returns 1 on success and 0 on rejection (out-of-range
 * exponents, NULL pointers, short buffers). Nothing partially succeeds.
 */

/* Flatten exponents to a cell index in [0, TET_CELLS). */
int tet_index(
    unsigned int a,
    unsigned int b,
    unsigned int c,
    unsigned int d,
    unsigned int *out
);

/* The period (divisor) at those exponents: 2^a x 3^b x 5^c x 7^d. */
int tet_period(
    unsigned int a,
    unsigned int b,
    unsigned int c,
    unsigned int d,
    unsigned long *out
);

/* The mirror cell: (4-a, 3-b, 1-c, 1-d). Its period times the original
 * period is always exactly TET_WHEEL. */
int tet_mirror(
    unsigned int a,
    unsigned int b,
    unsigned int c,
    unsigned int d,
    unsigned int *ma,
    unsigned int *mb,
    unsigned int *mc,
    unsigned int *md
);

/* Fill table[0 .. TET_CELLS-1] with the period of every cell, in index
 * order. capacity must be at least TET_CELLS. */
int tet_build(unsigned long *table, unsigned long capacity);

/*
 * Self-check. Returns 0 when every law holds, otherwise the number of
 * the FIRST law that failed. Never a partial pass, never a guess:
 *
 *   1  index is a bijection onto [0,80)
 *   2  every cell divides the wheel
 *   3  all 80 periods are distinct
 *   4  the 80 periods are exactly the 80 divisors of the wheel
 *   5  cell x mirror == wheel, for every cell
 *   6  432 sits at (4,3,0,0)
 *   7  35 sits at (0,0,1,1)
 *   8  432 x 35 == wheel
 *   9  the wheel tiles the womb with zero remainder
 *  10  the wheel tiles the slice grid with zero remainder
 *  11  exactly 16 pitch classes (a == 0), every one of them odd
 */
int tet_verify(void);

/* 1 when a cell of this period fires on this slice. */
int tet_fires(unsigned long period, unsigned long slice);

/* How many of the given cells fire together on one slice — the stack
 * depth, which is the amplitude. */
int tet_depth(
    const unsigned long *periods,
    unsigned long count,
    unsigned long slice,
    unsigned long *out
);

#endif
