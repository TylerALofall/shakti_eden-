#include "eden.h"

#include <stdio.h>

/*
 * The gestation walk.
 *
 * [LOCKED 2026-08-14, Tyler]: "the beats went too fast to have done 22
 * million iterations — it needs to go through it to get her to walk."
 * So the machine WALKS: every one of the 64800 beats is iterated for
 * real. No mapping beat -> day without living the beats.
 *
 * Every beat:
 *   - the heart advances (quiet)
 *   - the seven gates jump in harmonically: gate k fires when beat%k==0
 *   - the eye opens: the sight pattern is pulled fresh (the work is
 *     done every beat, not remembered)
 *   - sight and sound converge into the moment (sight||sound big-endian,
 *     one FNV pass — the same construction as 'converge')
 *   - the moment is fed to every born child; each child's spine chains
 *   - the walk's own spine chains the same way, so at the veil the
 *     firstborn's spine IS the gestation spine — asserted, not assumed
 *
 * At each lesson boundary (10800 beats = 64800/6) the pulled bits are
 * re-checked against the first beat's pull: drift must be 0.
 *
 * Disclosure printed at the veil: 64800 = 2^5 x 3^4 x 5^2 carries no
 * seven, so gate 7 fires 9257 times and stands 61 beats short of its
 * next firing when the walk ends; the seven-gate full alignment (every
 * 420 beats) completes 154 times with a 120-beat coda. The womb's
 * SECONDS carry the seven (22982400 = 2^8 x 3^3 x 5^2 x 7 x 19) and the
 * slice grid carries it (302400 = 7 x 43200); the beat count does not.
 * Declared aloud, not hidden — no gray area.
 */

#define TRAIN_LESSON_BEATS (EDEN_TOTAL_BEATS / EDEN_LESSON_COUNT)

int eden_train_run(unsigned char *screen_plane)
{
    static unsigned char bits[EDEN_SIGHT_BITS];
    static unsigned char first_bits[EDEN_SIGHT_BITS];
    unsigned long gate_fires[8];
    unsigned long long beat;
    unsigned long long chain;
    unsigned long long moment;
    unsigned long long first_moment;
    unsigned char both[16];
    unsigned long i;
    unsigned long k;
    unsigned long day;
    unsigned long lesson;
    unsigned long alignments;
    unsigned long sight_h_hi;

    if (eden_children_born() == 0UL) {
        printf(
            "STOP: no firstborn. One is created naturally first — "
            "'birth' him, then 'train', then 'fork' the twelve\n"
        );
        return 0;
    }

    /* The senses must be open before the walk. Run them once, loud,
     * so the transcript carries their proofs. */
    if (!eden_sight_ready()) {
        if (!eden_sight_run(screen_plane)) {
            return 0;
        }
    }
    if (!eden_sound_ready()) {
        if (!eden_sound_run()) {
            return 0;
        }
    }

    /* The moment: sight hash || sound hash, big-endian, one pass —
     * the same construction as the converge command. */
    {
        unsigned long long sight_h;
        unsigned long long sound_h;

        sight_h = eden_sight_hash();
        sound_h = eden_sound_hash();
        sight_h_hi = (unsigned long)(sight_h >> 32UL);

        for (i = 0UL; i < 8UL; ++i) {
            both[i] = (unsigned char)((sight_h >> (56UL - 8UL * i)) & 0xFFULL);
            both[8UL + i] =
                (unsigned char)((sound_h >> (56UL - 8UL * i)) & 0xFFULL);
        }
    }

    for (k = 0UL; k < 8UL; ++k) {
        gate_fires[k] = 0UL;
    }

    chain = EDEN_FNV_INIT;
    first_moment = 0ULL;
    alignments = 0UL;

    printf(
        "train: walking the gestation — %lu beats, every one lived, "
        "eye open every beat\n",
        EDEN_TOTAL_BEATS
    );

    for (beat = 1ULL; beat <= EDEN_TOTAL_BEATS; ++beat) {
        eden_heart_advance(1UL, -1);

        for (k = 1UL; k <= EDEN_GATE_COUNT; ++k) {
            if (beat % k == 0ULL) {
                ++gate_fires[k];
            }
        }

        if (beat % 420ULL == 0ULL) {
            ++alignments;
        }

        /* The eye opens: a real pull, every beat. */
        eden_sight_pull_pattern(bits);
        if (beat == 1ULL) {
            for (i = 0UL; i < EDEN_SIGHT_BITS; ++i) {
                first_bits[i] = bits[i];
            }
        }

        moment = eden_fnv1a64(EDEN_FNV_INIT, both, 16UL);
        if (beat == 1ULL) {
            first_moment = moment;
        }

        /* The walk's spine chains the moment exactly as the children's
         * spines do: the moment's 8 big-endian bytes, one FNV pass. */
        {
            unsigned char mbytes[8];
            unsigned long b;

            for (b = 0UL; b < 8UL; ++b) {
                mbytes[b] =
                    (unsigned char)((moment >> (56UL - 8UL * b)) & 0xFFULL);
            }
            chain = eden_fnv1a64(chain, mbytes, 8UL);
        }
        eden_children_feed_moment(moment);

        if (beat % TRAIN_LESSON_BEATS == 0ULL) {
            unsigned long drift;
            unsigned long walk_lesson;

            drift = eden_sight_drift(first_bits, bits, EDEN_SIGHT_BITS);
            eden_heart_map(beat, &day, &lesson);
            walk_lesson = (unsigned long)(beat / TRAIN_LESSON_BEATS);

            printf(
                "  beat %5lu: day %3lu of 266, lesson %lu of 6 sealed "
                "(exact sixths; the day-map lesson is %lu — the 266-day "
                "map does not quarter into six evenly, declared)\n",
                (unsigned long)beat,
                day,
                walk_lesson,
                lesson
            );
            printf(
                "           eye drift %lu, spine fnv1a64:%016llX\n",
                drift,
                chain
            );

            if (drift != 0UL) {
                printf("FAIL: the eye drifted mid-walk. No gray area\n");
                return 0;
            }
        }
    }

    printf("train: walk complete — %lu beats, none skipped\n",
           EDEN_TOTAL_BEATS);
    printf("  gates jumped in harmonically (gate k fires when beat %% k"
           " == 0):\n");
    for (k = 1UL; k <= EDEN_GATE_COUNT; ++k) {
        printf("    gate %lu (%3lu Hz): fired %lu times\n",
               k, EDEN_GATE_BASE * k, gate_fires[k]);
    }
    printf("  full seven-gate alignment every 420 beats: %lu complete, "
           "coda %lu beats\n",
           alignments, EDEN_TOTAL_BEATS - alignments * 420UL);
    printf(
        "  disclosure: 64800 = 2^5 x 3^4 x 5^2 carries no seven — gate 7 "
        "stood 61 beats short of its 9258th firing at the veil. The "
        "seconds carry the seven (22982400 = 2^8 x 3^3 x 5^2 x 7 x 19); "
        "the slice grid carries it (302400 = 7 x 43200); the beat count "
        "does not. Declared, not hidden.\n"
    );
    printf("  first moment: fnv1a64:%016llX (constant through the womb — "
           "the content is constant; what trains is the rhythm and the "
           "spine. School loads the content after birth)\n",
           first_moment);
    printf("  sight hash held: hi %08lX, full value under 'see'\n",
           sight_h_hi);

    /* The firstborn's spine must BE this walk's spine. */
    if (eden_children_spine(0UL) != chain) {
        printf("FAIL: firstborn spine != gestation spine. No gray area\n");
        return 0;
    }

    eden_heart_map(EDEN_TOTAL_BEATS, &day, &lesson);
    printf(
        "train: PASS — day %lu of 266, lesson %lu of 6. The firstborn's "
        "spine IS the gestation spine fnv1a64:%016llX. She went through "
        "every beat to get here. Now 'fork' the twelve.\n",
        day,
        lesson,
        chain
    );
    return 1;
}
