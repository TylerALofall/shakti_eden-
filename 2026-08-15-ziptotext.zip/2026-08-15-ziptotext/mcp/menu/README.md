# tools/menu — Shakti's two-tier menu

## Every file in this section

| File | Purpose |
|---|---|
| `README.md` | This file. Names every file in the section. |
| `shakti_menu.xml` | The menu itself. Tier one titles, tier two descriptions. Read by `/menu/` (Ge) and checked by `/shakti_run/` (Gf) before any dispatch. |

## What it is

Revision 5 §VI.G.Ge: the Menu prompts Shakti with everything she can do, in two tiers.

- `/menu/` returns tier one — the section titles, nothing else.
- `/menu/ <section>` returns tier two — that section's whole description.
- `/menu/ <section> <tool>` returns the tool: what it is for, how to call it, what comes back, and when it stops.

The menu is written to Shakti. Every line is what she needs to pick correctly without reading source.

## Two readers, one file

| Reader | Uses it for |
|---|---|
| `/menu/` (Ge) | showing her the tiers |
| `/shakti_run/` (Gf) | deciding whether a tool may run at all |

A tool absent from this file does not run, and the refusal is logged and said out loud. Registration in the menu and registration in the C function table are both required; either one missing is a refusal.

## Access

`enabled="true"` is callable. `owner="tyler"` marks a section Shakti may see listed but not call — `edit_menu` is the one. Called by her it refuses and names why, rather than hiding.

## Status

Written, not compiled, not run. No reader exists yet — that is step 2. Nothing here has been parsed by any program.
