# Publish to GitHub

This repository is prepared for a clean first commit.

## From the source folder

Create an empty GitHub repository without adding a README, license, or `.gitignore`, then run:

```sh
git init -b main
git add .
git commit -m "Prepare Shakti first-five-level MVP"
git remote add origin https://github.com/YOUR_ACCOUNT/YOUR_REPOSITORY.git
git push -u origin main
```

For SSH:

```sh
git remote set-url origin git@github.com:YOUR_ACCOUNT/YOUR_REPOSITORY.git
git push -u origin main
```

## From the supplied Git bundle

```sh
git clone SHAKTI_GITHUB_READY.bundle shakti
cd shakti
git remote add origin https://github.com/YOUR_ACCOUNT/YOUR_REPOSITORY.git
git push -u origin main
```

## Before each curriculum batch

```sh
python3 tools/migrate_curriculum.py /path/to/incoming   --output migration_out   --report migration_report.json
```

Resolve all errors, apply into a fresh staging directory, run the ledger and tests, then commit one coherent level or lesson batch. Do not copy the full 30,000-file collection directly into the repository.

Future audio growth may justify Git LFS. Make that decision from the staged batch-size report before committing large WAV collections.
