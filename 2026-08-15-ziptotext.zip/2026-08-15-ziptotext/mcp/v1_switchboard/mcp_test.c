/* mcp_test.c — the intentional-error record for the switchboard.
   Every case states the result it must produce. mcp_run is called directly in
   this process. Writes temp/mcp_test_record.xml. */

#include "shakti_mcp.h"

#include <stdio.h>
#include <string.h>

#define TEMPDIR "temp"
#define RECORD  "temp/mcp_test_record.xml"
#define FIXTURE "temp/mcp_fixture.txt"
#define MENU    "../menu/shakti_menu.xml"

static const char *FIXTURE_BODY = "alpha\nbravo\ncharlie\n";

static int write_fixture(void)
{
    FILE *f = fopen(FIXTURE, "wb");
    if (f == NULL) {
        return 0;
    }
    fputs(FIXTURE_BODY, f);
    return fclose(f) == 0;
}

static int fixture_untouched(void)
{
    char buffer[256];
    size_t n;
    FILE *f = fopen(FIXTURE, "rb");
    if (f == NULL) {
        return 0;
    }
    n = fread(buffer, 1U, sizeof buffer - 1U, f);
    fclose(f);
    buffer[n] = '\0';
    return strcmp(buffer, FIXTURE_BODY) == 0;
}

int main(void)
{
    FILE *record;
    unsigned passed = 0U;
    unsigned failed = 0U;

    struct {
        const char *name;
        mcp_caller_t caller;
        int open_edit;
        const char *tool;
        int argc;
        char *argv[8];
        mcp_result_t want;
        const char *why;
    } cases[] = {
        { "unknown_tool", MCP_CALLER_TYLER, 1, "delete_everything", 0, {NULL},
          MCP_STOPPED, "a tool absent from the menu does not run" },
        { "not_enabled", MCP_CALLER_TYLER, 1, "read", 0, {NULL},
          MCP_STOPPED, "a menu entry that is off does not run" },
        { "tylers_tool_from_shakti", MCP_CALLER_SHAKTI, 0, "edit_menu", 0, {NULL},
          MCP_STOPPED, "she sees it and it does not run from her shell" },
        { "edit_closed", MCP_CALLER_SHAKTI, 0, "exact_edit", 4,
          { (char *)FIXTURE, (char *)"replace", (char *)"bravo", (char *)"|" },
          MCP_STOPPED, "editing is off while the branch is closed" },
        { "edit_open_no_match", MCP_CALLER_TYLER, 1, "exact_edit", 5,
          { (char *)FIXTURE, (char *)"replace", (char *)"zulu", (char *)"|", (char *)"x" },
          MCP_NO_CHANGE, "the branch is open and nothing matches" },
        { "edit_open_changes", MCP_CALLER_TYLER, 1, "exact_edit", 5,
          { (char *)FIXTURE, (char *)"replace", (char *)"bravo", (char *)"|", (char *)"BRAVO" },
          MCP_DONE, "the branch is open and one line matches" }
    };
    size_t count = sizeof cases / sizeof cases[0];
    size_t k;

    record = fopen(RECORD, "wb");
    if (record == NULL) {
        printf("STOP    %s could not be opened. The temp dir has to exist.\n", RECORD);
        return (int)MCP_STOPPED;
    }
    fprintf(record, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    fprintf(record, "<mcp_test_record schema=\"MCP_TEST_V1\">\n");

    for (k = 0U; k < count; k++) {
        mcp_session_t session;
        mcp_result_t got;
        int untouched;

        if (!write_fixture()) {
            printf("STOP    the fixture could not be written.\n");
            fclose(record);
            return (int)MCP_STOPPED;
        }
        mcp_session_init(&session, cases[k].caller);
        strcpy(session.menu_path, MENU);
        strcpy(session.temp_dir, TEMPDIR);
        strcpy(session.log_path, "temp/mcp_test.log");
        if (cases[k].open_edit) {
            session.edit_open = 1U;
            strcpy(session.branch, "edit");
        }

        printf("\n=== %s ===\n", cases[k].name);
        got = mcp_run(&session, cases[k].tool, cases[k].argc, cases[k].argv, stdout);
        untouched = fixture_untouched();

        if (got == cases[k].want && untouched) {
            passed++;
            printf("PASS  %s  result %d  the file it read is unchanged\n",
                   cases[k].name, (int)got);
        } else {
            failed++;
            printf("FAIL  %s  wanted %d, got %d. the file it read is unchanged: %s\n",
                   cases[k].name, (int)cases[k].want, (int)got, untouched ? "yes" : "no");
        }
        fprintf(record, "  <case name=\"%s\">\n", cases[k].name);
        fprintf(record, "    <caller>%s</caller>\n",
                cases[k].caller == MCP_CALLER_TYLER ? "tyler" : "shakti");
        fprintf(record, "    <edit_branch>%s</edit_branch>\n",
                cases[k].open_edit ? "open" : "closed");
        fprintf(record, "    <tool><![CDATA[%s]]></tool>\n", cases[k].tool);
        fprintf(record, "    <wanted>%d</wanted>\n", (int)cases[k].want);
        fprintf(record, "    <got>%d</got>\n", (int)got);
        fprintf(record, "    <source_unchanged>%s</source_unchanged>\n",
                untouched ? "yes" : "no");
        fprintf(record, "    <result>%s</result>\n",
                (got == cases[k].want && untouched) ? "PASS" : "FAIL");
        fprintf(record, "    <why><![CDATA[%s]]></why>\n", cases[k].why);
        fprintf(record, "  </case>\n");
    }
    fprintf(record, "  <totals passed=\"%u\" failed=\"%u\" cases=\"%lu\"/>\n",
            passed, failed, (unsigned long)count);
    fprintf(record, "</mcp_test_record>\n");
    fclose(record);

    printf("\n%u passed, %u failed, %lu cases. Record written to %s\n",
           passed, failed, (unsigned long)count, RECORD);
    return failed == 0U ? (int)MCP_DONE : (int)MCP_STOPPED;
}
