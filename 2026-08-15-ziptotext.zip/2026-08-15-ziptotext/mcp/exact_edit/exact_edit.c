/* exact_edit.c — change one exact line of one file.
   C99 and the standard library. Working memory is the fixed arrays declared
   below, sized at compile time. The whole run happens in this process. Reads
   the source file; writes a new file beside it. Carries exact text through
   byte for byte. */

#include "exact_edit.h"
#include "shakti_log.h"
#include "shakti_time.h"

#include <stdio.h>
#include <string.h>

/* Working memory. Fixed at compile time. */
static char g_lines[EE_MAX_LINES][EE_MAX_LINE];
static int  g_line_count;
static int  g_crlf;
static int  g_final_newline;
static int  g_hits[EE_MAX_HITS];
static int  g_hit_count;
static int  g_acted[EE_MAX_HITS];
static int  g_acted_count;

const char *exact_edit_verb_name(ee_verb_t verb)
{
    if (verb == EE_VERB_ADD)     return "add";
    if (verb == EE_VERB_REMOVE)  return "remove";
    if (verb == EE_VERB_REPLACE) return "replace";
    return "none";
}

static unsigned int verb_function_order(ee_verb_t verb)
{
    if (verb == EE_VERB_ADD)     return EE_FN_ADD;
    if (verb == EE_VERB_REMOVE)  return EE_FN_REMOVE;
    if (verb == EE_VERB_REPLACE) return EE_FN_REPLACE;
    return 0U;
}

/* ---------------------------------------------------------------- matching */

/* Length of s with trailing spaces, tabs and carriage returns excluded. */
static size_t trimmed_length(const char *s)
{
    size_t n = strlen(s);
    while (n > 0U && (s[n - 1U] == ' ' || s[n - 1U] == '\t' || s[n - 1U] == '\r')) {
        n--;
    }
    return n;
}

/* Two lines are the same when their bytes are the same, trailing whitespace
   excluded. Capitalization is part of the text. The spaces inside a line are
   part of the text. There is no pattern syntax and no similarity anywhere. */
static int line_is_exactly(const char *line, const char *wanted)
{
    size_t a = trimmed_length(line);
    size_t b = trimmed_length(wanted);
    if (a != b) {
        return 0;
    }
    return memcmp(line, wanted, a) == 0;
}

/* ---------------------------------------------------------------- logging */

/* The working-system row per Revision 5 VII. The timing letter rides in the
   phase field: A a run starting, T one acted line, Z the run ending. */
static void log_row(const ee_request_t *request,
                    shakti_tick_clock_t *clock_state,
                    const char *timing,
                    const char *subject,
                    const char *property,
                    const char *value)
{
    shakti_tick_t tick;
    if (request->log_path == NULL) {
        return;
    }
    if (!shakti_tick_next(clock_state, &tick)) {
        return;
    }
    (void)shakti_log_append(request->log_path, "LRN1", &tick, EE_SECTION,
                            verb_function_order(request->verb), timing,
                            "/shakti_run/", subject, property, value);
}

/* ---------------------------------------------------------------- loading */

static ee_result_t load_file(const char *path, FILE *report)
{
    FILE *file;
    int c;
    int column = 0;

    g_line_count = 0;
    g_crlf = 0;
    g_final_newline = 0;
    g_lines[0][0] = '\0';

    file = fopen(path, "rb");
    if (file == NULL) {
        fprintf(report, "STOP    the file could not be read: %s\n", path);
        return EE_ERROR;
    }
    while ((c = fgetc(file)) != EOF) {
        if (c == '\n') {
            if (column > 0 && g_lines[g_line_count][column - 1] == '\r') {
                g_crlf = 1;
                column--;
            }
            g_lines[g_line_count][column] = '\0';
            g_line_count++;
            if (g_line_count >= EE_MAX_LINES) {
                fclose(file);
                fprintf(report, "STOP    the file holds more than %d lines, "
                                "which is this tool's capacity. Nothing changed.\n",
                        EE_MAX_LINES);
                return EE_ERROR;
            }
            g_lines[g_line_count][0] = '\0';
            column = 0;
            g_final_newline = 1;
            continue;
        }
        if (column >= EE_MAX_LINE - 1) {
            fclose(file);
            fprintf(report, "STOP    line %d is longer than %d bytes, which is "
                            "this tool's capacity. Nothing changed.\n",
                    g_line_count + 1, EE_MAX_LINE - 1);
            return EE_ERROR;
        }
        g_lines[g_line_count][column] = (char)c;
        column++;
        g_lines[g_line_count][column] = '\0';
        g_final_newline = 0;
    }
    fclose(file);
    if (column > 0) {
        g_line_count++;   /* the last line carried no newline */
    }
    return EE_CHANGED;
}

/* ---------------------------------------------------------------- writing */

/* The part of a path after the last separator. The original path is read, not
   altered; this only chooses the name a copy is given. */
static const char *file_name_of(const char *path)
{
    const char *slash = strrchr(path, '/');
    const char *back = strrchr(path, '\\');
    if (back != NULL && (slash == NULL || back > slash)) {
        slash = back;
    }
    return (slash != NULL) ? slash + 1 : path;
}

/* The changed copy goes to the temp dir the MCP named. The file that was read
   stays where it is, as it is, and nothing is written beside it. */
static ee_result_t write_copy(const ee_request_t *request, FILE *report)
{
    char destination[EE_MAX_PATH];
    const char *name = file_name_of(request->path);
    const char *eol = g_crlf ? "\r\n" : "\n";
    size_t eol_length = g_crlf ? 2U : 1U;
    FILE *file;
    int i;

    if (request->out_dir == NULL || request->out_dir[0] == '\0') {
        fprintf(report, "STOP    no temp dir was given. The MCP names it, and "
                        "every copy goes there. Nothing changed.\n");
        return EE_ERROR;
    }
    if (strlen(request->out_dir) + strlen(name) + 6U >= (size_t)EE_MAX_PATH) {
        fprintf(report, "STOP    the temp dir and file name together pass %d "
                        "bytes, which is this tool's capacity.\n", EE_MAX_PATH);
        return EE_ERROR;
    }
    strcpy(destination, request->out_dir);
    strcat(destination, "/");
    strcat(destination, name);
    strcat(destination, ".new");

    file = fopen(destination, "wb");
    if (file == NULL) {
        fprintf(report, "STOP    %s could not be written. The temp dir has to "
                        "exist before the call.\n", destination);
        return EE_ERROR;
    }
    for (i = 0; i < g_line_count; i++) {
        size_t n = strlen(g_lines[i]);
        if (n > 0U) {
            fwrite(g_lines[i], 1U, n, file);
        }
        if (i < g_line_count - 1 || g_final_newline) {
            fwrite(eol, 1U, eol_length, file);
        }
    }
    if (fclose(file) != 0) {
        fprintf(report, "STOP    %s did not close cleanly.\n", destination);
        return EE_ERROR;
    }
    fprintf(report, "COPY    %s\n", destination);
    fprintf(report, "        %s is where it was and as it was.\n", request->path);
    return EE_CHANGED;
}

/* ---------------------------------------------------------------- the run */

ee_result_t exact_edit_run(const ee_request_t *request,
                           shakti_tick_clock_t *clock_state,
                           FILE *report)
{
    char event_id[64];
    shakti_tick_t tick;
    const char *wanted;
    int k;
    int i;
    ee_result_t rc;

    if (request == NULL || clock_state == NULL || report == NULL) {
        return EE_ERROR;
    }
    if (request->path == NULL || request->e1 == NULL || request->e2 == NULL ||
        request->e1[0] == '\0' || request->e2[0] == '\0') {
        fprintf(report, "STOP    a file, column one and column two are all required.\n");
        return EE_ERROR;
    }
    if (request->verb == EE_VERB_NONE) {
        fprintf(report, "STOP    the verb is add, remove, or replace.\n");
        return EE_ERROR;
    }

    /* A — the run begins. Logged before any work, as Gf requires. */
    log_row(request, clock_state, "A", request->path,
            exact_edit_verb_name(request->verb), request->e1);

    event_id[0] = '\0';
    if (shakti_tick_next(clock_state, &tick)) {
        (void)shakti_event_id_format(&tick, EE_SECTION,
                                     verb_function_order(request->verb),
                                     event_id, sizeof event_id);
    }

    rc = load_file(request->path, report);
    if (rc != EE_CHANGED) {
        log_row(request, clock_state, "Z", request->path, "stopped", "capacity");
        return EE_ERROR;
    }

    fprintf(report, "%s exact_edit\n", event_id);
    fprintf(report, "  asked by  %s\n", request->caller ? request->caller : "unnamed");
    fprintf(report, "  file      %s\n", request->path);
    fprintf(report, "  temp dir  %s\n", request->out_dir ? request->out_dir : "none given");
    fprintf(report, "  lines     %d, ending %s\n", g_line_count, g_crlf ? "CRLF" : "LF");
    fprintf(report, "  capacity  %d lines of %d bytes, %d matches\n",
            EE_MAX_LINES, EE_MAX_LINE - 1, EE_MAX_HITS);
    fprintf(report, "  verb      %s\n", exact_edit_verb_name(request->verb));
    fprintf(report, "  column 1  [%s]\n", request->e1);
    fprintf(report, "  column 2  [%s]\n", request->e2);
    if (request->verb == EE_VERB_ADD) {
        fprintf(report, "  side      %s the anchor\n",
                request->side == EE_SIDE_BEFORE ? "before" : "after");
    }

    /* Column two repeats column one for remove, so a slip cannot delete the
       wrong line. */
    if (request->verb == EE_VERB_REMOVE &&
        !line_is_exactly(request->e1, request->e2)) {
        fprintf(report, "STOP    remove needs the same line twice. "
                        "Column one and column two are not the same. Nothing changed.\n");
        log_row(request, clock_state, "Z", request->path, "stopped", "confirm differs");
        return EE_ERROR;
    }

    /* PASS 1 — find every match, count it, and show it. */
    wanted = (request->verb == EE_VERB_ADD) ? request->e2 : request->e1;
    g_hit_count = 0;
    for (i = 0; i < g_line_count; i++) {
        if (line_is_exactly(g_lines[i], wanted)) {
            if (g_hit_count >= EE_MAX_HITS) {
                fprintf(report, "STOP    more than %d lines match, which is this "
                                "tool's capacity. Nothing changed.\n", EE_MAX_HITS);
                log_row(request, clock_state, "Z", request->path, "stopped", "match capacity");
                return EE_ERROR;
            }
            g_hits[g_hit_count] = i;
            g_hit_count++;
        }
    }
    fprintf(report, "PASS 1  %d line(s) match\n", g_hit_count);
    for (k = 0; k < g_hit_count; k++) {
        fprintf(report, "        #%d  line %d  [%s]\n",
                k + 1, g_hits[k] + 1, g_lines[g_hits[k]]);
    }
    if (g_hit_count == 0) {
        fprintf(report, "PASS 1  nothing matches [%s]. Nothing changed.\n", wanted);
        log_row(request, clock_state, "Z", request->path, "no match", wanted);
        return EE_NO_CHANGE;
    }
    if (g_hit_count > 1 && request->selector == EE_SEL_NONE) {
        fprintf(report, "PASS 1  say which one: #1 through #%d, or #all. Nothing changed.\n",
                g_hit_count);
        log_row(request, clock_state, "Z", request->path, "several match", wanted);
        return EE_NO_CHANGE;
    }
    if (request->selector > 0) {
        if (request->selector > g_hit_count) {
            fprintf(report, "STOP    there is no #%d. %d line(s) match.\n",
                    request->selector, g_hit_count);
            log_row(request, clock_state, "Z", request->path, "stopped", "no such occurrence");
            return EE_ERROR;
        }
        g_hits[0] = g_hits[request->selector - 1];
        g_hit_count = 1;
    }

    /* PASS 2 — act from the bottom of the file upward, so the line number of
       an edit not yet made stays correct. */
    g_acted_count = 0;
    for (k = g_hit_count - 1; k >= 0; k--) {
        i = g_hits[k];
        if (request->verb == EE_VERB_ADD) {
            int at = (request->side == EE_SIDE_BEFORE) ? i : i + 1;
            if (g_line_count + 1 >= EE_MAX_LINES) {
                fprintf(report, "STOP    adding would pass %d lines, which is this "
                                "tool's capacity. Nothing changed.\n", EE_MAX_LINES);
                log_row(request, clock_state, "Z", request->path, "stopped", "capacity");
                return EE_ERROR;
            }
            memmove(g_lines[at + 1], g_lines[at],
                    (size_t)(g_line_count - at) * (size_t)EE_MAX_LINE);
            strncpy(g_lines[at], request->e1, (size_t)EE_MAX_LINE - 1U);
            g_lines[at][EE_MAX_LINE - 1] = '\0';
            g_line_count++;
            g_acted[g_acted_count] = at + 1;
            g_acted_count++;
        } else if (request->verb == EE_VERB_REMOVE) {
            memmove(g_lines[i], g_lines[i + 1],
                    (size_t)(g_line_count - i - 1) * (size_t)EE_MAX_LINE);
            g_line_count--;
            g_acted[g_acted_count] = i + 1;
            g_acted_count++;
        } else {
            strncpy(g_lines[i], request->e2, (size_t)EE_MAX_LINE - 1U);
            g_lines[i][EE_MAX_LINE - 1] = '\0';
            g_acted[g_acted_count] = i + 1;
            g_acted_count++;
        }
    }
    fprintf(report, "PASS 2  %d line(s) acted on, lowest first, "
                    "so no line number moved under a later one\n", g_acted_count);
    if (g_acted_count != g_hit_count) {
        fprintf(report, "STOP    %d acted on and %d matched. Those must agree. "
                        "Nothing written.\n", g_acted_count, g_hit_count);
        log_row(request, clock_state, "Z", request->path, "stopped", "counts disagree");
        return EE_ERROR;
    }

    /* PASS 3 — the changed lines, and only those. */
    fprintf(report, "PASS 3  what changed\n");
    for (k = g_acted_count - 1; k >= 0; k--) {
        int line_number = g_acted[k];
        if (request->verb == EE_VERB_ADD) {
            fprintf(report, "        +%5d  [%s]\n", line_number, request->e1);
        } else if (request->verb == EE_VERB_REMOVE) {
            fprintf(report, "        -%5d  [%s]\n", line_number, request->e1);
        } else {
            fprintf(report, "        -%5d  [%s]\n", line_number, request->e1);
            fprintf(report, "        +%5d  [%s]\n", line_number, request->e2);
        }
    }

    /* PASS 4 — write the copy into the temp dir, then one T row per acted line. */
    if (write_copy(request, report) != EE_CHANGED) {
        log_row(request, clock_state, "Z", request->path, "stopped", "write failed");
        return EE_ERROR;
    }
    for (k = g_acted_count - 1; k >= 0; k--) {
        char where[32];
        sprintf(where, "line %d", g_acted[k]);
        log_row(request, clock_state, "T", request->path, where,
                request->verb == EE_VERB_REMOVE ? request->e1 : request->e2);
    }
    log_row(request, clock_state, "Z", request->path, "changed", request->path);

    fprintf(report, "DONE    %d line(s) changed.\n", g_acted_count);
    return EE_CHANGED;
}
