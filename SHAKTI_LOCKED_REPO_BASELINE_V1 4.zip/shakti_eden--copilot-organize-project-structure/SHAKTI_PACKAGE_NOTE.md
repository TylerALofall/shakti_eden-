# SHAKTI LOCKED REPOSITORY BASELINE V1

This archive contains the complete candidate repository from
`copilot/organize-project-structure` plus the clean authority and
read-only baseline documents.

No source file from the candidate repository was edited, deleted,
renamed, generated, or executed while creating this archive.

Authority file:
- `SHAKTI_LOCK_V1_1_CLEAN.md`

Supporting records:
- `REPO_INVENTORY_V1.md`
- `SHAKTI_BASELINE_RECEIPT_V1.md`
- `SHAKTI_DOCS_ONLY_COMMIT_PLAN_V1.md`

GitHub `main` remains untouched.
