#ifndef SHAKTI_EXACT_EDIT_H
#define SHAKTI_EXACT_EDIT_H

#include <stdio.h>

#include "shakti_types.h"

/* Section Gf — /shakti_run/. Ordered function inside Gf. */
#define EE_SECTION "Gf"
#define EE_FN_ADD     1U
#define EE_FN_REMOVE  2U
#define EE_FN_REPLACE 3U

/* Declared capacities. Printed on every run. A full capacity is an explicit
   stop, never a truncation. */
#define EE_MAX_LINES 4096
#define EE_MAX_LINE  1024
#define EE_MAX_HITS   512
#define EE_MAX_PATH   512

/* The verb set is closed at three. */
typedef enum {
    EE_VERB_NONE = 0,
    EE_VERB_ADD = 1,
    EE_VERB_REMOVE = 2,
    EE_VERB_REPLACE = 3
} ee_verb_t;

/* Where /add places the new line relative to the anchor. Absent means after. */
typedef enum {
    EE_SIDE_AFTER = 0,
    EE_SIDE_BEFORE = 1
} ee_side_t;

/* Occurrence selector. 0 none given, -1 all, n>0 the nth match. */
#define EE_SEL_NONE 0
#define EE_SEL_ALL  (-1)

/* Outcome. Also the process exit code of the standalone entry. */
typedef enum {
    EE_CHANGED = 0,
    EE_ERROR = 1,
    EE_NO_CHANGE = 2
} ee_result_t;

typedef struct {
    const char *path;      /* file read; stays exactly where it is          */
    const char *e1;        /* column one                                   */
    const char *e2;        /* column two                                   */
    const char *out_dir;   /* the MCP's temp dir; every copy lands here    */
    const char *log_path;  /* append-only working record                   */
    const char *caller;    /* who asked: shakti, tyler, test               */
    ee_verb_t verb;
    ee_side_t side;
    int selector;
} ee_request_t;

/* Runs the four passes. Writes <path>.new on a change. Appends the log.
   report receives every printed line. Returns the outcome. */
ee_result_t exact_edit_run(const ee_request_t *request,
                           shakti_tick_clock_t *clock_state,
                           FILE *report);

const char *exact_edit_verb_name(ee_verb_t verb);

#endif
