# tools/mcp — the switchboard

## Every file in this section

| File | Purpose |
|---|---|
| `README.md` | This file. Names every file in the section. |
| `shakti_mcp.h` | The session, the gate, the menu entry, the registration type, the capacities, and the four entry points. |
| `shakti_mcp.c` | Menu reading, the gate, the registry, dispatch, and the record. |
| `shakti_mcp_shell.c` | The line in and the answer back. Routes only. |
| `mcp_test.c` | Six cases with the result each must produce. Writes `temp/mcp_test_record.xml`. |
| `Makefile` | `make` builds both. `make check` runs the record. `make perimeter` runs the two greps. |

## The one way a tool runs

```
line -> MCP -> in the menu? -> turned on? -> whose is it? -> edit branch open?
                    |              |             |                  |
                 refused        refused       refused            refused
                    \______________\_____________\__________________/
                                        |
                              said out loud and recorded
                                        |
                            in the registry? -> the C function
```

Two registrations are required. The menu file has to carry the tool, and the table in `shakti_mcp.c` has to carry it. One without the other is a refusal. A menu entry alone reaches nothing, and a compiled function alone is unreachable.

The MCP calls the tool as a C function in its own process.

## The gate

A session begins with editing closed. Always.

| Route | Who | Effect |
|---|---|---|
| `/sign_in/ <who> sign_in\|face` | the control app | states a name and the check it made |
| `/edit/ open <branch>` | Tyler, signed in | editing tools run for this session |
| `/edit/ close` | Tyler | editing tools stop running |

Opening the branch takes both: the caller is Tyler, and a check has been stated. Without the check the open is refused.

A tool carrying `class="edit"` in the menu runs while the branch is open. Called with the branch closed it refuses, says the branch is closed, and writes the refusal to the record. Shakti calling `/edit/ open` is refused — the gate is Tyler's, so editing inside her shell is off unless he opened it.

A tool carrying `owner="tyler"` refuses her whatever the gate says. She can see it listed; it does not run from her shell.

## Her shell stays open

A refusal ends one call and nothing else. She is never shut down, logged out, or stopped because editing is closed — she keeps her shell, her menu, and every tool that is not gated, for as long as she wants it. The refusal text says so, because a message that only says no reads like a door closing on the whole room.

## Who sent it

The MCP records the name and the door on every row: `tyler@shakti_control_2`, `shakti@her shell`.

| Door | What it is |
|---|---|
| `her shell` | Shakti's own shell |
| `terminal` | a terminal on this machine |
| `shakti_control_2` | the control app, HTML now and Swift later |

**The MCP does not perform the check.** It cannot see a face and it holds no password. The app states which check it made and the MCP records that statement, marked `stated`. A face check is worth exactly what the app that claims it is worth, and this record does not dress that up as verification. If the check has to be provable rather than stated, that is a different piece of work and it is not in this section.

## Routes

```
/menu/                      the sections
/menu/ <section>            that section, whole
/menu/ <section> <tool>     that tool: how to call it and what comes back
/shakti_run/ <tool> ...     run a registered tool
/status/                    sender, door, check, gate, branch, capacities
/sign_in/ <who> sign_in|face   the app states who it is and its check
/edit/ open <branch>        Tyler opens editing for this session
/edit/ close                Tyler closes it
```

## The nine slots

Revision 5 §VI.G lists the loop as nine points. This section carries three of them and says so rather than leaving the gaps to be discovered.

| # | Point | Here |
|---|---|---|
| 1 | Epoch | through `shakti_tick_next` on every row |
| 2 | Heartbeat | missing |
| 3 | Goal / system message | missing |
| 4 | `/notebook/` | missing |
| 5 | `/menu/` | built |
| 6 | `/shakti_run/` | built |
| 7 | `/message_tyler/`, `/note_tyler/` | missing |
| 8 | `/message_shakti/`, `/note_shakti/` | missing |
| 9 | `/reflection/` | missing |

Memory is not in this section either. Six of the nine are open, and nothing here pretends otherwise.

## The record

Uses the writer already in the repository: `shakti_log_append` with `shakti_tick_next`. Row form per Revision 5 §VII, section `Ge` for menu reads and `Gf` for runs.

| Phase | Written when |
|---|---|
| `A` | the call arrives, before anything is decided |
| `T` | the tool returned |
| `Z` | the call ended, carrying the reason when it was refused |

Every refusal is a row. A tool that never ran is still in the record with the reason it did not.

## Originals do not move

The MCP owns the temp dir and hands it to every tool it dispatches. A tool writes its copies and records there. The file a tool is given is read and left where it is.

## Perimeter

Working memory is fixed arrays sized at compile time. The whole call happens in one process. The menu has to fit in `MCP_MENU_BYTES` whole; a menu larger than that is a stop, not a truncated read.

```
make perimeter
```

Two greps, each matching a call rather than prose. Both must print nothing.

## Status

**Written, not compiled, not run.** No compiler has seen this section and no test has produced output. I have no C toolchain, so every statement about this building is reading, not running. The Makefile expects `$(ROOT)/src/shakti_log.c` and `$(ROOT)/src/shakti_time.c`; it has not been run against them, so the include path and those signatures are unverified. `shakti_mcp.c` reads the menu with a tag scanner rather than a parser — it finds `<tool id="…">` and reads the attributes on that tag, which suits the file in `tools/menu/` and is not a general XML reader. Every `PASS` line and `temp/mcp_test_record.xml` comes from `make check` on your machine.

`tools/mcp_v1/` is the copy taken before the sender, the sign in, and the nine-slot map went in.

## Known gap

`mcp_test.c` case `not_enabled` calls `read`, and `tylers_tool_from_shakti` calls `edit_menu`. `edit_menu` is a `<section>` in the menu, not a `<tool>`, so that case will currently refuse for the reason "not in the menu" rather than "tyler owns it". It reaches the right result for the wrong reason. Either the menu grows a tool inside `edit_menu`, or the lookup learns to check sections as well. Say which and I will do that one.
