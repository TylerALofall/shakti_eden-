# 30,000-File Import Plan

Organize imports by curriculum meaning, not by arbitrary filename ranges.

## Batch boundary

Each batch should contain one level, lesson family, or other reviewable curriculum unit. A batch is ready only when:

- every XML stone has exactly `text`, `written_text`, `sound_art`, and `visual_art`,
- `text` matches the source list,
- all required artifacts resolve to canonical filenames,
- conflicts are empty or explicitly quarantined,
- the manifest ledger reports no required gaps,
- the full test suite passes.

## Sequence

1. Preserve the incoming collection unchanged.
2. Run a dry migration scan.
3. Resolve tag conflicts and duplicate basenames.
4. Apply to a new staging directory.
5. Review the JSON report and quarantine.
6. Promote only the intended first-five-level files.
7. Regenerate the ledger and checksums.
8. Commit the batch with its report.

Suggested commit subjects:

```text
curriculum(colors): add solo color words
curriculum(colors): add count and separation bridge
curriculum(shapes): add 2D solo shapes
```

Math remains outside the import allowlist until the first five levels prove the nine-stage loop and three-stage memory model.
