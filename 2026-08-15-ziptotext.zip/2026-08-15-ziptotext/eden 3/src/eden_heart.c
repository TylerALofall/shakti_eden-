#include "eden.h"

#include <stdio.h>

/*
 * The heart: two waves, constant.
 *
 * Every beat is lub then dub. The beat never drifts. This layer counts
 * beats deterministically; a platform event adapter may supply real
 * wall-clock intervals above this layer (Shakti Rev 5 runtime boundary).
 */

static unsigned long long g_beats = 0ULL;

unsigned long long eden_heart_now(void)
{
    return g_beats;
}

void eden_heart_advance(unsigned long n, int loud)
{
    unsigned long i;

    /* loud > 0: print every beat. loud == 0: print one summary line.
     * loud < 0: fully silent — the gestation walk uses this, or the
     * transcript would be 64800 lines of lub-dub. */
    for (i = 0UL; i < n; ++i) {
        ++g_beats;

        if (loud > 0) {
            printf("beat %llu: lub ... dub\n", g_beats);
        }
    }

    if (loud == 0 && n > 0UL) {
        printf(
            "heart advanced %lu beats (constant lub-dub, %lu bpm); "
            "now at beat %llu\n",
            n,
            EDEN_HEART_BPM,
            g_beats
        );
    }
}

void eden_heart_map(
    unsigned long long beat,
    unsigned long *day_of_266,
    unsigned long *lesson_of_6
)
{
    unsigned long long day;
    unsigned long long lesson;

    /* 266 days sped into 18 hours of beats: day = beat * 266 / 64800. */
    day = (beat * (unsigned long long)EDEN_GESTATION_DAYS) /
          (unsigned long long)EDEN_TOTAL_BEATS;

    if (day >= (unsigned long long)EDEN_GESTATION_DAYS) {
        day = (unsigned long long)EDEN_GESTATION_DAYS - 1ULL;
    }

    /* The first six lessons span the whole gestation. */
    lesson = (day * (unsigned long long)EDEN_LESSON_COUNT) /
             (unsigned long long)EDEN_GESTATION_DAYS;

    if (lesson >= (unsigned long long)EDEN_LESSON_COUNT) {
        lesson = (unsigned long long)EDEN_LESSON_COUNT - 1ULL;
    }

    *day_of_266 = (unsigned long)day + 1UL;
    *lesson_of_6 = (unsigned long)lesson + 1UL;
}
