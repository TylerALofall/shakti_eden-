#include "eden.h"

#include <stdio.h>
#include <string.h>

/*
 * The arena: the only memory the shell ever has.
 *
 * One fixed block, owned by the shell, carved into named partitions at
 * boot. No heap. A full capacity returns NULL and the caller stops
 * explicitly — no silent truncation, no gray area.
 */

#define EDEN_PARTITION_MAX 32UL
#define EDEN_LABEL_CAP 24UL
#define EDEN_FNV_PRIME 0x100000001B3ULL

typedef struct {
    char label[EDEN_LABEL_CAP];
    unsigned long offset;
    unsigned long size;
} eden_partition_t;

static unsigned char g_arena[EDEN_ARENA_BYTES];
static eden_partition_t g_partitions[EDEN_PARTITION_MAX];
static unsigned long g_partition_count = 0UL;
static unsigned long g_used = 0UL;

void *eden_alloc(const char *label, unsigned long size)
{
    unsigned long aligned;
    unsigned long i;
    void *block;

    aligned = (size + 7UL) & ~7UL;

    if (g_partition_count >= EDEN_PARTITION_MAX ||
        g_used + aligned > EDEN_ARENA_BYTES) {
        /* Explicit stop. */
        return NULL;
    }

    block = g_arena + g_used;
    memset(block, 0, aligned);

    for (i = 0UL; i < EDEN_LABEL_CAP - 1UL && label[i] != '\0'; ++i) {
        g_partitions[g_partition_count].label[i] = label[i];
    }
    g_partitions[g_partition_count].label[i] = '\0';
    g_partitions[g_partition_count].offset = g_used;
    g_partitions[g_partition_count].size = aligned;
    ++g_partition_count;

    g_used += aligned;
    return block;
}

unsigned long eden_memory_used(void)
{
    return g_used;
}

unsigned long eden_memory_remaining(void)
{
    return EDEN_ARENA_BYTES - g_used;
}

void eden_memory_report(void)
{
    unsigned long i;

    printf(
        "arena: %lu bytes total, %lu used, %lu remaining\n",
        EDEN_ARENA_BYTES,
        g_used,
        EDEN_ARENA_BYTES - g_used
    );

    for (i = 0UL; i < g_partition_count; ++i) {
        printf(
            "  [%06lu..%06lu] %-16s %lu bytes\n",
            g_partitions[i].offset,
            g_partitions[i].offset + g_partitions[i].size,
            g_partitions[i].label,
            g_partitions[i].size
        );
    }
}

unsigned long long eden_fnv1a64(
    unsigned long long hash,
    const unsigned char *data,
    unsigned long length
)
{
    unsigned long index;

    for (index = 0UL; index < length; ++index) {
        hash ^= (unsigned long long)data[index];
        hash *= EDEN_FNV_PRIME;
    }

    return hash;
}
